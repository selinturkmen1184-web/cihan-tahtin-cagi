using System;
using System.Linq;
using Cihan.Battle;
using Cihan.Domain;
using UnityEditor;
using UnityEditor.Build;
using UnityEngine;

namespace Cihan.Editor
{
    public static class CihanV11SmokeTests
    {
        [MenuItem("Cihan/V11 Duman Testlerini Çalıştır")]
        public static void Run()
        {
            ValidateCoreProgression();
            ValidateDailyOrder();
            ValidateCannonBarrage();
            ValidateRequiredAssets();
            Debug.Log("CIHAN_V11_SMOKE_TESTS_PASSED");
        }

        private static void ValidateCoreProgression()
        {
            const double now = 12000d;
            var state = GameState.CreateNew(now);
            var initialFood = state.food;
            state.Advance(now + 60d);
            Require(state.food > initialFood, "Kaynak üretimi ilerlemiyor.");

            state.campaignProgress = 1;
            Require(state.IsMissionComplete(2), "İlk fetih görevi tamamlanmadı.");
            Require(state.ClaimMissionReward(2), "Görev ödülü alınamadı.");
            Require(!state.ClaimMissionReward(2), "Görev ödülü iki kez alınabildi.");
        }

        private static void ValidateDailyOrder()
        {
            const double now = 22000d;
            var state = GameState.CreateNew(now);
            state.EnsureDailyOrder(now);
            state.dailyOrderIndex = 2;
            var initialGold = state.gold;
            state.ApplyBattleResult(false, 2, 5);

            Require(state.IsDailyOrderComplete(), "Günlük savaş emri tamamlanmadı.");
            Require(state.ClaimDailyOrderReward(now), "Günlük emir ödülü alınamadı.");
            Require(state.gold > initialGold, "Günlük emir ödülü kaynak eklemedi.");
            Require(!state.ClaimDailyOrderReward(now), "Günlük emir iki kez alınabildi.");
        }

        private static void ValidateCannonBarrage()
        {
            var battle = BattleSimulation.Create(GameState.CreateNew(32000d));
            Require(
                battle.ApplyFormation(BattleFormation.Crescent),
                "Savaş formasyonu seçilemedi.");
            var initialHealth = battle.Units
                .Where(item => item.team == BattleTeam.Enemy)
                .Sum(item => item.hp);

            Require(battle.LaunchCannonBarrage(), "Şahi ateşi başlatılamadı.");
            Require(
                battle.Units.Where(item => item.team == BattleTeam.Enemy).Sum(item => item.hp) <
                initialHealth,
                "Şahi ateşi düşmana hasar vermedi.");
            Require(battle.CannonBarrageCooldown > 0f, "Şahi bekleme süresi başlamadı.");
            Require(!battle.LaunchCannonBarrage(), "Şahi ateşi beklemeden tekrar kullanıldı.");
        }

        private static void ValidateRequiredAssets()
        {
            Require(
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-siege-keyart-v11.png") != null,
                "V11 kuşatma görseli bulunamadı.");
            Require(
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-app-icon-v11.png") != null,
                "V11 uygulama ikonu bulunamadı.");
            Require(
                AssetDatabase.LoadAssetAtPath<GameObject>(
                    "Assets/Cihan/Resources/KayKit/Characters/Knight.fbx") != null,
                "Animasyonlu asker modeli bulunamadı.");
            Require(
                AssetDatabase.LoadAssetAtPath<RuntimeAnimatorController>(
                    "Assets/Cihan/Resources/KayKit/KayKitBattle.controller") != null,
                "Asker animasyon denetleyicisi bulunamadı.");
        }

        private static void Require(bool condition, string message)
        {
            if (!condition)
            {
                throw new BuildFailedException($"CİHAN V11 testi başarısız: {message}");
            }
        }
    }
}
