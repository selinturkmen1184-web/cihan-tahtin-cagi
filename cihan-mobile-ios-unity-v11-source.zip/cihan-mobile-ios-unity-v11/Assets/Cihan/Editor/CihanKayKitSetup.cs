using System;
using System.Linq;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;

namespace Cihan.Editor
{
    public static class CihanKayKitSetup
    {
        private const string Root = "Assets/Cihan/Resources/KayKit";
        private const string CharacterRoot = Root + "/Characters";
        private const string AnimationRoot = Root + "/Animations";
        private const string ControllerPath = Root + "/KayKitBattle.controller";

        private static readonly string[] CharacterPaths =
        {
            CharacterRoot + "/Knight.fbx",
            CharacterRoot + "/Ranger.fbx",
            CharacterRoot + "/Barbarian.fbx",
            CharacterRoot + "/Rogue_Hooded.fbx"
        };

        [MenuItem("Cihan/KayKit Askerlerini Hazırla")]
        public static void EnsureConfigured()
        {
            foreach (var characterPath in CharacterPaths)
            {
                ConfigureCharacter(characterPath);
            }

            var sourceAvatar = AssetDatabase
                .LoadAllAssetsAtPath(CharacterPaths[0])
                .OfType<Avatar>()
                .FirstOrDefault();
            if (sourceAvatar == null)
            {
                throw new InvalidOperationException(
                    "KayKit Knight avatarı Unity tarafından oluşturulamadı.");
            }

            ConfigureAnimation(
                AnimationRoot + "/Rig_Medium_General.fbx",
                sourceAvatar);
            ConfigureAnimation(
                AnimationRoot + "/Rig_Medium_MovementBasic.fbx",
                sourceAvatar);
            ConfigureAnimation(
                AnimationRoot + "/Rig_Medium_CombatMelee.fbx",
                sourceAvatar);
            ConfigureAnimation(
                AnimationRoot + "/Rig_Medium_CombatRanged.fbx",
                sourceAvatar);

            BuildController();
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
        }

        private static void ConfigureCharacter(string path)
        {
            if (AssetImporter.GetAtPath(path) is not ModelImporter importer)
            {
                throw new InvalidOperationException(
                    $"KayKit karakteri bulunamadı: {path}");
            }

            var requiresImport =
                importer.animationType != ModelImporterAnimationType.Generic ||
                importer.avatarSetup != ModelImporterAvatarSetup.CreateFromThisModel ||
                !importer.importAnimation;
            if (!requiresImport)
            {
                return;
            }

            importer.animationType = ModelImporterAnimationType.Generic;
            importer.avatarSetup = ModelImporterAvatarSetup.CreateFromThisModel;
            importer.importAnimation = true;
            importer.importCameras = false;
            importer.importLights = false;
            importer.SaveAndReimport();
        }

        private static void ConfigureAnimation(string path, Avatar sourceAvatar)
        {
            if (AssetImporter.GetAtPath(path) is not ModelImporter importer)
            {
                throw new InvalidOperationException(
                    $"KayKit animasyonu bulunamadı: {path}");
            }

            var requiresImport =
                importer.animationType != ModelImporterAnimationType.Generic ||
                importer.avatarSetup != ModelImporterAvatarSetup.CopyFromOther ||
                importer.sourceAvatar != sourceAvatar ||
                !importer.importAnimation;
            if (!requiresImport)
            {
                return;
            }

            importer.animationType = ModelImporterAnimationType.Generic;
            importer.avatarSetup = ModelImporterAvatarSetup.CopyFromOther;
            importer.sourceAvatar = sourceAvatar;
            importer.importAnimation = true;
            importer.importCameras = false;
            importer.importLights = false;
            importer.SaveAndReimport();
        }

        private static void BuildController()
        {
            if (AssetDatabase.LoadAssetAtPath<AnimatorController>(ControllerPath) != null)
            {
                AssetDatabase.DeleteAsset(ControllerPath);
            }

            var controller =
                AnimatorController.CreateAnimatorControllerAtPath(ControllerPath);
            var stateMachine = controller.layers[0].stateMachine;

            var idle = AddState(
                stateMachine,
                "Idle",
                FindClip(AnimationRoot + "/Rig_Medium_General.fbx", "Idle_A"),
                1f);
            stateMachine.defaultState = idle;
            AddState(
                stateMachine,
                "Run",
                FindClip(
                    AnimationRoot + "/Rig_Medium_MovementBasic.fbx",
                    "Running_A"),
                1.08f);
            AddState(
                stateMachine,
                "AttackMelee",
                FindClip(
                    AnimationRoot + "/Rig_Medium_CombatMelee.fbx",
                    "Melee_1H_Attack_Slice_Diagonal"),
                1.18f);
            AddState(
                stateMachine,
                "AttackRanged",
                FindClip(
                    AnimationRoot + "/Rig_Medium_CombatRanged.fbx",
                    "Ranged_Bow_Release"),
                1.12f);
            AddState(
                stateMachine,
                "Hit",
                FindClip(AnimationRoot + "/Rig_Medium_General.fbx", "Hit_A"),
                1.12f);
            AddState(
                stateMachine,
                "Death",
                FindClip(AnimationRoot + "/Rig_Medium_General.fbx", "Death_A"),
                1f);
        }

        private static AnimatorState AddState(
            AnimatorStateMachine stateMachine,
            string name,
            AnimationClip clip,
            float speed)
        {
            var state = stateMachine.AddState(name);
            state.motion = clip;
            state.speed = speed;
            state.writeDefaultValues = true;
            return state;
        }

        private static AnimationClip FindClip(string assetPath, string name)
        {
            var clips = AssetDatabase
                .LoadAllAssetsAtPath(assetPath)
                .OfType<AnimationClip>()
                .Where(clip => !clip.name.StartsWith("__preview__"))
                .ToArray();
            var clip = clips.FirstOrDefault(item =>
                string.Equals(item.name, name, StringComparison.OrdinalIgnoreCase));
            if (clip != null)
            {
                return clip;
            }

            var available = string.Join(", ", clips.Select(item => item.name));
            throw new InvalidOperationException(
                $"KayKit animasyon klibi bulunamadı: {name}. Mevcut: {available}");
        }
    }
}
