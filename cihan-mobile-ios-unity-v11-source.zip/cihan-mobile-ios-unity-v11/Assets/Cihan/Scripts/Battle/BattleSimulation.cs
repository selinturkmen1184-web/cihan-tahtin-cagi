using System;
using System.Collections.Generic;
using System.Linq;
using Cihan.Domain;

namespace Cihan.Battle
{
    public enum BattleTeam
    {
        Friendly,
        Enemy
    }

    public enum BattleUnitKind
    {
        Infantry,
        Archer,
        Cavalry,
        Siege,
        Commander
    }

    public enum BattleFormation
    {
        Crescent,
        ShieldWall,
        LightningRaid
    }

    public enum BattleCommand
    {
        None,
        Charge,
        ShieldWall,
        ArrowVolley,
        CannonBarrage,
        Rally,
        EnemyReinforcement,
        EnemyShieldWall,
        EnemyArrowVolley,
        EnemyCharge
    }

    public sealed class BattleUnit
    {
        public int id;
        public BattleTeam team;
        public BattleUnitKind kind;
        public float x;
        public float y;
        public float hp;
        public float maxHp;
        public float damage;
        public float speed;
        public float range;
        public float attackDelay;
        public float attackTimer;
        public int kills;
        public int targetId;

        public bool Alive => hp > 0f;
        public float HealthRatio => maxHp <= 0f ? 0f : Math.Max(0f, hp / maxHp);
    }

    public sealed class BattleSimulation
    {
        private const float MaximumDuration = 68f;
        private const float ChargeDuration = 5.5f;
        private const float ShieldWallDuration = 6.5f;
        private const float ChargeCooldownDuration = 14f;
        private const float ShieldWallCooldownDuration = 15f;
        private const float ArrowVolleyCooldownDuration = 12f;
        private const float CannonBarrageCooldownDuration = 22f;
        private readonly List<BattleUnit> units = new();
        private int nextId = 1;

        public IReadOnlyList<BattleUnit> Units => units;
        public float Elapsed { get; private set; }
        public bool IsFinished { get; private set; }
        public bool Victory { get; private set; }
        public int FriendlyKills { get; private set; }
        public int FriendlyCasualties { get; private set; }
        public int Clashes { get; private set; }
        public float FriendlyMorale { get; private set; } = 82f;
        public float EnemyMorale { get; private set; } = 78f;
        public float ChargeSeconds { get; private set; }
        public float ShieldWallSeconds { get; private set; }
        public float EnemyChargeSeconds { get; private set; }
        public float EnemyShieldWallSeconds { get; private set; }
        public float ChargeCooldown { get; private set; }
        public float ShieldWallCooldown { get; private set; }
        public float ArrowVolleyCooldown { get; private set; }
        public float CannonBarrageCooldown { get; private set; }
        public BattleCommand LastCommand { get; private set; }
        public int CommandRevision { get; private set; }
        public bool EnemyReinforcementsDeployed { get; private set; }
        public bool FormationChosen { get; private set; }
        public BattleFormation SelectedFormation { get; private set; }
        public bool RallyUsed { get; private set; }
        private bool enemyShieldWallUsed;
        private bool enemyArrowVolleyUsed;
        private bool enemyChargeUsed;
        public int StarRating =>
            !Victory
                ? 0
                : 1 +
                  (FriendlyCasualties <= 5 ? 1 : 0) +
                  (Elapsed <= 45f ? 1 : 0);

        public float EnemyCommanderHealthRatio
        {
            get
            {
                var commander = units.FirstOrDefault(item =>
                    item.team == BattleTeam.Enemy &&
                    item.kind == BattleUnitKind.Commander);
                return commander?.HealthRatio ?? 0f;
            }
        }

        public bool CanIssueCharge =>
            FormationChosen &&
            !IsFinished &&
            ChargeCooldown <= 0f &&
            FriendlyAlive > 0;

        public bool CanRaiseShieldWall =>
            FormationChosen &&
            !IsFinished &&
            ShieldWallCooldown <= 0f &&
            units.Any(item =>
                item.team == BattleTeam.Friendly &&
                item.kind == BattleUnitKind.Infantry &&
                item.Alive);

        public bool CanLaunchArrowVolley =>
            FormationChosen &&
            !IsFinished &&
            ArrowVolleyCooldown <= 0f &&
            units.Any(item =>
                item.team == BattleTeam.Friendly &&
                item.kind == BattleUnitKind.Archer &&
                item.Alive);

        public bool CanRally =>
            FormationChosen &&
            !IsFinished &&
            !RallyUsed &&
            FriendlyAlive > 0;

        public bool CanLaunchCannonBarrage =>
            FormationChosen &&
            !IsFinished &&
            CannonBarrageCooldown <= 0f &&
            units.Any(item =>
                item.team == BattleTeam.Friendly &&
                item.kind == BattleUnitKind.Siege &&
                item.Alive);

        public int FriendlyAlive =>
            units.Count(item => item.team == BattleTeam.Friendly && item.Alive);

        public int EnemyAlive =>
            units.Count(item => item.team == BattleTeam.Enemy && item.Alive);

        public static BattleSimulation Create(GameState state, int enemyTier = 0)
        {
            var simulation = new BattleSimulation();
            enemyTier = Math.Max(0, Math.Min(2, enemyTier));
            simulation.EnemyMorale = Math.Min(94f, 78f + enemyTier * 5f);
            var aybars = state.GetHero("aybars").assigned;
            var nizam = state.GetHero("nizam").assigned;
            var leyla = state.GetHero("leyla").assigned;

            simulation.SpawnFormation(
                BattleTeam.Friendly,
                BattleUnitKind.Infantry,
                aybars ? 9 : 8,
                0.22f,
                0.15f,
                aybars ? 1.12f : 1f,
                1f);
            simulation.SpawnFormation(
                BattleTeam.Friendly,
                BattleUnitKind.Archer,
                5,
                0.12f,
                0.23f,
                1f,
                nizam ? 1.10f : 1f);
            simulation.SpawnFormation(
                BattleTeam.Friendly,
                BattleUnitKind.Cavalry,
                3,
                0.18f,
                0.12f);
            simulation.SpawnFormation(
                BattleTeam.Friendly,
                BattleUnitKind.Siege,
                1,
                0.08f,
                0.50f);

            if (leyla)
            {
                simulation.SpawnFormation(
                    BattleTeam.Friendly,
                    BattleUnitKind.Infantry,
                    2,
                    0.15f,
                    0.70f);
            }

            simulation.SpawnFormation(
                BattleTeam.Enemy,
                BattleUnitKind.Infantry,
                9 + enemyTier * 2,
                0.78f,
                0.15f,
                1.04f + enemyTier * 0.08f);
            simulation.SpawnFormation(
                BattleTeam.Enemy,
                BattleUnitKind.Archer,
                5 + enemyTier,
                0.88f,
                0.23f,
                1f + enemyTier * 0.06f);
            simulation.SpawnFormation(
                BattleTeam.Enemy,
                BattleUnitKind.Cavalry,
                3 + (enemyTier > 0 ? 1 : 0),
                0.82f,
                0.12f,
                1f + enemyTier * 0.08f);
            simulation.SpawnFormation(
                BattleTeam.Enemy,
                BattleUnitKind.Siege,
                1,
                0.92f,
                0.50f);
            simulation.SpawnFormation(
                BattleTeam.Enemy,
                BattleUnitKind.Commander,
                1,
                0.90f,
                0.46f,
                1.08f + enemyTier * 0.18f);

            return simulation;
        }

        public void Step(float deltaTime)
        {
            if (!FormationChosen || IsFinished || deltaTime <= 0f)
            {
                return;
            }

            var step = Math.Min(deltaTime, 0.05f);
            Elapsed += step;
            ChargeSeconds = Math.Max(0f, ChargeSeconds - step);
            ShieldWallSeconds = Math.Max(0f, ShieldWallSeconds - step);
            EnemyChargeSeconds = Math.Max(0f, EnemyChargeSeconds - step);
            EnemyShieldWallSeconds = Math.Max(0f, EnemyShieldWallSeconds - step);
            ChargeCooldown = Math.Max(0f, ChargeCooldown - step);
            ShieldWallCooldown = Math.Max(0f, ShieldWallCooldown - step);
            ArrowVolleyCooldown = Math.Max(0f, ArrowVolleyCooldown - step);
            CannonBarrageCooldown = Math.Max(0f, CannonBarrageCooldown - step);

            if (!EnemyReinforcementsDeployed && Elapsed >= 18f)
            {
                EnemyReinforcementsDeployed = true;
                SpawnFormation(
                    BattleTeam.Enemy,
                    BattleUnitKind.Infantry,
                    3,
                    0.96f,
                    0.34f,
                    1.04f);
                SpawnFormation(
                    BattleTeam.Enemy,
                    BattleUnitKind.Archer,
                    2,
                    0.98f,
                    0.58f);
                EnemyMorale = Math.Min(100f, EnemyMorale + 12f);
                RegisterCommand(BattleCommand.EnemyReinforcement);
            }

            RunEnemyTactics();
            if (IsFinished)
            {
                return;
            }

            foreach (var unit in units.Where(item => item.Alive).ToArray())
            {
                unit.attackTimer = Math.Max(0f, unit.attackTimer - step);
                var target = FindNearestTarget(unit);
                if (target == null)
                {
                    unit.targetId = 0;
                    continue;
                }

                unit.targetId = target.id;
                var dx = target.x - unit.x;
                var dy = target.y - unit.y;
                var distance = (float)Math.Sqrt(dx * dx + dy * dy);
                if (distance > unit.range)
                {
                    var speedMultiplier = MovementMultiplier(unit);
                    var movement = Math.Min(
                        unit.speed * speedMultiplier * step,
                        distance - unit.range);
                    if (distance > 0.0001f)
                    {
                        unit.x += dx / distance * movement;
                        unit.y += dy / distance * movement;
                    }

                    continue;
                }

                if (unit.attackTimer > 0f)
                {
                    continue;
                }

                Clashes += 1;
                unit.attackTimer = unit.attackDelay;
                ApplyDamage(unit, target, DamageAgainst(unit, target));
            }

            EvaluateResult();
        }

        private void RunEnemyTactics()
        {
            if (!enemyShieldWallUsed && Elapsed >= 8f)
            {
                enemyShieldWallUsed = true;
                EnemyShieldWallSeconds = 5.5f;
                EnemyMorale = Math.Min(100f, EnemyMorale + 4f);
                RegisterCommand(BattleCommand.EnemyShieldWall);
            }

            if (!enemyArrowVolleyUsed && Elapsed >= 27f)
            {
                var source = units.FirstOrDefault(item =>
                    item.team == BattleTeam.Enemy &&
                    item.kind == BattleUnitKind.Archer &&
                    item.Alive);
                if (source != null)
                {
                    enemyArrowVolleyUsed = true;
                    var archerCount = units.Count(item =>
                        item.team == BattleTeam.Enemy &&
                        item.kind == BattleUnitKind.Archer &&
                        item.Alive);
                    var damage = 11f + Math.Min(archerCount, 8) * 1.85f;
                    var targets = units
                        .Where(item => item.team == BattleTeam.Friendly && item.Alive)
                        .OrderByDescending(item => item.x)
                        .ThenBy(item => item.hp)
                        .Take(7)
                        .ToArray();
                    foreach (var target in targets)
                    {
                        ApplyDamage(source, target, damage);
                    }

                    RegisterCommand(BattleCommand.EnemyArrowVolley);
                    EvaluateResult();
                }
            }

            if (!enemyChargeUsed && Elapsed >= 42f)
            {
                enemyChargeUsed = true;
                EnemyChargeSeconds = 5.5f;
                EnemyMorale = Math.Min(100f, EnemyMorale + 7f);
                RegisterCommand(BattleCommand.EnemyCharge);
            }
        }

        public bool DeployReinforcement(BattleUnitKind kind)
        {
            if (IsFinished || !FormationChosen)
            {
                return false;
            }

            var count = kind == BattleUnitKind.Cavalry ? 2 : 3;
            SpawnFormation(
                BattleTeam.Friendly,
                kind,
                count,
                0.04f,
                0.30f + (int)kind * 0.11f);
            return true;
        }

        public bool ApplyFormation(BattleFormation formation)
        {
            if (FormationChosen || Elapsed > 0f || IsFinished)
            {
                return false;
            }

            SelectedFormation = formation;
            FormationChosen = true;
            switch (formation)
            {
                case BattleFormation.Crescent:
                    foreach (var unit in units.Where(item =>
                                 item.team == BattleTeam.Friendly &&
                                 item.kind == BattleUnitKind.Archer))
                    {
                        unit.range *= 1.26f;
                        unit.damage *= 1.14f;
                        unit.y = Math.Min(0.91f, unit.y + 0.035f);
                    }

                    FriendlyMorale = Math.Min(100f, FriendlyMorale + 3f);
                    break;
                case BattleFormation.ShieldWall:
                    foreach (var unit in units.Where(item =>
                                 item.team == BattleTeam.Friendly &&
                                 item.kind == BattleUnitKind.Infantry))
                    {
                        unit.maxHp *= 1.22f;
                        unit.hp = unit.maxHp;
                        unit.range *= 1.06f;
                    }

                    ShieldWallSeconds = 5f;
                    ShieldWallCooldown = 8f;
                    FriendlyMorale = Math.Min(100f, FriendlyMorale + 4f);
                    break;
                case BattleFormation.LightningRaid:
                    foreach (var unit in units.Where(item =>
                                 item.team == BattleTeam.Friendly &&
                                 item.kind == BattleUnitKind.Cavalry))
                    {
                        unit.speed *= 1.34f;
                        unit.damage *= 1.18f;
                        unit.x = Math.Min(0.42f, unit.x + 0.045f);
                    }

                    FriendlyMorale = Math.Min(100f, FriendlyMorale + 7f);
                    break;
                default:
                    throw new ArgumentOutOfRangeException(
                        nameof(formation),
                        formation,
                        null);
            }

            return true;
        }

        public bool IssueCharge()
        {
            if (!FormationChosen || !CanIssueCharge)
            {
                return false;
            }

            ChargeSeconds = ChargeDuration;
            ChargeCooldown = ChargeCooldownDuration;
            FriendlyMorale = Math.Min(100f, FriendlyMorale + 7f);
            RegisterCommand(BattleCommand.Charge);
            return true;
        }

        public bool RaiseShieldWall()
        {
            if (!FormationChosen || !CanRaiseShieldWall)
            {
                return false;
            }

            ShieldWallSeconds = ShieldWallDuration;
            ShieldWallCooldown = ShieldWallCooldownDuration;
            FriendlyMorale = Math.Min(100f, FriendlyMorale + 4f);
            RegisterCommand(BattleCommand.ShieldWall);
            return true;
        }

        public bool LaunchArrowVolley()
        {
            if (!FormationChosen || !CanLaunchArrowVolley)
            {
                return false;
            }

            ArrowVolleyCooldown = ArrowVolleyCooldownDuration;
            var archers = units.Count(item =>
                item.team == BattleTeam.Friendly &&
                item.kind == BattleUnitKind.Archer &&
                item.Alive);
            var damage = 13f + Math.Min(archers, 8) * 2.25f;
            var targets = units
                .Where(item => item.team == BattleTeam.Enemy && item.Alive)
                .OrderBy(item => item.x)
                .ThenBy(item => item.hp)
                .Take(8)
                .ToArray();
            var source = units.First(item =>
                item.team == BattleTeam.Friendly &&
                item.kind == BattleUnitKind.Archer &&
                item.Alive);
            foreach (var target in targets)
            {
                ApplyDamage(source, target, damage);
            }

            RegisterCommand(BattleCommand.ArrowVolley);
            EvaluateResult();
            return true;
        }

        public bool RallyTheArmy()
        {
            if (!FormationChosen || !CanRally)
            {
                return false;
            }

            RallyUsed = true;
            FriendlyMorale = Math.Min(100f, FriendlyMorale + 18f);
            foreach (var unit in units.Where(item =>
                         item.team == BattleTeam.Friendly && item.Alive))
            {
                unit.hp = Math.Min(
                    unit.maxHp,
                    unit.hp + unit.maxHp * 0.20f);
            }

            RegisterCommand(BattleCommand.Rally);
            return true;
        }

        public bool LaunchCannonBarrage()
        {
            if (!FormationChosen || !CanLaunchCannonBarrage)
            {
                return false;
            }

            CannonBarrageCooldown = CannonBarrageCooldownDuration;
            var siegeUnits = units.Where(item =>
                    item.team == BattleTeam.Friendly &&
                    item.kind == BattleUnitKind.Siege &&
                    item.Alive)
                .ToArray();
            var source = siegeUnits[0];
            var damage = 40f + Math.Min(3, siegeUnits.Length) * 8f;
            var targets = units
                .Where(item => item.team == BattleTeam.Enemy && item.Alive)
                .OrderByDescending(item => item.kind == BattleUnitKind.Commander)
                .ThenBy(item => item.hp)
                .Take(5)
                .ToArray();
            foreach (var target in targets)
            {
                ApplyDamage(source, target, damage);
            }

            EnemyMorale = Math.Max(8f, EnemyMorale - 12f);
            FriendlyMorale = Math.Min(100f, FriendlyMorale + 5f);
            RegisterCommand(BattleCommand.CannonBarrage);
            EvaluateResult();
            return true;
        }

        public bool TryGetUnit(int id, out BattleUnit unit)
        {
            unit = units.FirstOrDefault(item => item.id == id);
            return unit != null;
        }

        public void Retreat()
        {
            if (IsFinished)
            {
                return;
            }

            Victory = false;
            IsFinished = true;
        }

        private void SpawnFormation(
            BattleTeam team,
            BattleUnitKind kind,
            int count,
            float x,
            float startY,
            float healthMultiplier = 1f,
            float rangeMultiplier = 1f)
        {
            for (var index = 0; index < count; index++)
            {
                var row = index / 5;
                var column = index % 5;
                var direction = team == BattleTeam.Friendly ? 1f : -1f;
                var baseStats = Stats(kind);
                var maxHealth = baseStats.health * healthMultiplier;
                units.Add(new BattleUnit
                {
                    id = nextId++,
                    team = team,
                    kind = kind,
                    x = x - direction * row * 0.035f,
                    y = Math.Min(0.88f, startY + column * 0.115f),
                    hp = maxHealth,
                    maxHp = maxHealth,
                    damage = baseStats.damage,
                    speed = baseStats.speed,
                    range = baseStats.range * rangeMultiplier,
                    attackDelay = baseStats.delay,
                    attackTimer = index * 0.035f
                });
            }
        }

        private BattleUnit FindNearestTarget(BattleUnit source)
        {
            BattleUnit selected = null;
            var nearestDistance = float.MaxValue;
            foreach (var target in units)
            {
                if (!target.Alive || target.team == source.team)
                {
                    continue;
                }

                var dx = target.x - source.x;
                var dy = target.y - source.y;
                var weightedDistance = dx * dx + dy * dy;
                if (weightedDistance < nearestDistance)
                {
                    nearestDistance = weightedDistance;
                    selected = target;
                }
            }

            return selected;
        }

        private float DamageAgainst(BattleUnit attacker, BattleUnit target)
        {
            var damage = BaseDamageAgainst(attacker, target);
            var morale = attacker.team == BattleTeam.Friendly
                ? FriendlyMorale
                : EnemyMorale;
            damage *= 0.78f + morale * 0.0034f;

            if (attacker.team == BattleTeam.Friendly && ChargeSeconds > 0f)
            {
                damage *= 1.28f;
            }

            if (attacker.team == BattleTeam.Enemy && EnemyChargeSeconds > 0f)
            {
                damage *= 1.24f;
            }

            if (target.team == BattleTeam.Friendly &&
                target.kind == BattleUnitKind.Infantry &&
                ShieldWallSeconds > 0f)
            {
                damage *= 0.54f;
            }

            if (target.team == BattleTeam.Enemy &&
                target.kind == BattleUnitKind.Infantry &&
                EnemyShieldWallSeconds > 0f)
            {
                damage *= 0.60f;
            }

            return damage;
        }

        private static float BaseDamageAgainst(
            BattleUnit attacker,
            BattleUnit target)
        {
            var multiplier = 1f;
            if (attacker.kind == BattleUnitKind.Cavalry &&
                target.kind == BattleUnitKind.Archer)
            {
                multiplier = 1.35f;
            }
            else if (attacker.kind == BattleUnitKind.Infantry &&
                     target.kind == BattleUnitKind.Cavalry)
            {
                multiplier = 1.18f;
            }
            else if (attacker.kind == BattleUnitKind.Archer &&
                     target.kind == BattleUnitKind.Infantry)
            {
                multiplier = 1.16f;
            }
            else if (attacker.kind == BattleUnitKind.Siege)
            {
                multiplier = 1.28f;
            }

            return attacker.damage * multiplier;
        }

        private float MovementMultiplier(BattleUnit unit)
        {
            var multiplier = 0.82f +
                             (unit.team == BattleTeam.Friendly
                                 ? FriendlyMorale
                                 : EnemyMorale) *
                             0.0024f;
            if (unit.team == BattleTeam.Friendly && ChargeSeconds > 0f)
            {
                multiplier *= 1.48f;
            }

            if (unit.team == BattleTeam.Enemy && EnemyChargeSeconds > 0f)
            {
                multiplier *= 1.42f;
            }

            if (unit.team == BattleTeam.Friendly &&
                unit.kind == BattleUnitKind.Infantry &&
                ShieldWallSeconds > 0f)
            {
                multiplier *= 0.58f;
            }

            if (unit.team == BattleTeam.Enemy &&
                unit.kind == BattleUnitKind.Infantry &&
                EnemyShieldWallSeconds > 0f)
            {
                multiplier *= 0.62f;
            }

            return multiplier;
        }

        private void ApplyDamage(
            BattleUnit attacker,
            BattleUnit target,
            float damage)
        {
            if (target == null || !target.Alive)
            {
                return;
            }

            var wasAlive = target.Alive;
            target.hp = Math.Max(0f, target.hp - Math.Max(0f, damage));
            if (!wasAlive || target.Alive)
            {
                return;
            }

            attacker.kills += 1;
            if (attacker.team == BattleTeam.Friendly)
            {
                FriendlyKills += 1;
                FriendlyMorale = Math.Min(100f, FriendlyMorale + 2.6f);
                EnemyMorale = Math.Max(8f, EnemyMorale - 4.4f);
            }
            else
            {
                FriendlyCasualties += 1;
                EnemyMorale = Math.Min(100f, EnemyMorale + 2.4f);
                FriendlyMorale = Math.Max(8f, FriendlyMorale - 4.8f);
            }
        }

        private void RegisterCommand(BattleCommand command)
        {
            LastCommand = command;
            CommandRevision += 1;
        }

        private void EvaluateResult()
        {
            var friendlyAlive = FriendlyAlive;
            var enemyAlive = EnemyAlive;
            if (friendlyAlive > 0 && enemyAlive > 0 && Elapsed < MaximumDuration)
            {
                return;
            }

            if (friendlyAlive == enemyAlive && friendlyAlive > 0)
            {
                var friendlyHealth = units
                    .Where(item => item.team == BattleTeam.Friendly && item.Alive)
                    .Sum(item => item.HealthRatio);
                var enemyHealth = units
                    .Where(item => item.team == BattleTeam.Enemy && item.Alive)
                    .Sum(item => item.HealthRatio);
                Victory = friendlyHealth >= enemyHealth;
            }
            else
            {
                Victory = friendlyAlive > enemyAlive;
            }

            IsFinished = true;
        }

        private static (
            float health,
            float damage,
            float speed,
            float range,
            float delay) Stats(BattleUnitKind kind)
        {
            return kind switch
            {
                BattleUnitKind.Infantry => (130f, 24f, 0.058f, 0.032f, 0.78f),
                BattleUnitKind.Archer => (82f, 21f, 0.043f, 0.185f, 0.96f),
                BattleUnitKind.Cavalry => (112f, 34f, 0.088f, 0.045f, 0.86f),
                BattleUnitKind.Siege => (175f, 52f, 0.025f, 0.255f, 1.65f),
                BattleUnitKind.Commander => (285f, 39f, 0.052f, 0.052f, 0.82f),
                _ => throw new ArgumentOutOfRangeException(nameof(kind), kind, null)
            };
        }
    }
}
