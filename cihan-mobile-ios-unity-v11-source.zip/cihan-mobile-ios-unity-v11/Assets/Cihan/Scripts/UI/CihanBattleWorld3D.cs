using System;
using System.Collections.Generic;
using System.Linq;
using Cihan.Battle;
using Cihan.Services;
using UnityEngine;
using UnityEngine.Rendering;

namespace Cihan.UI
{
    public sealed class CihanBattleWorld3D : MonoBehaviour
    {
        private sealed class Actor
        {
            public GameObject root;
            public Transform model;
            public Transform[] weapons;
            public Animator[] animators;
            public Quaternion[] weaponRestRotations;
            public Vector3 lastWorldPosition;
            public float lastAttackTimer;
            public float lastHealth;
            public float nextDustTime;
            public float phase;
            public float animationLockUntil;
            public string animationState;
            public bool fallen;
        }

        private sealed class TimedEffect
        {
            public GameObject root;
            public Vector3 velocity;
            public Vector3 baseScale;
            public float life;
            public float duration;
            public float spin;
            public bool expanding;
        }

        private sealed class AmbientMotion
        {
            public Transform root;
            public Vector3 basePosition;
            public Vector3 baseScale;
            public Quaternion baseRotation;
            public float phase;
            public float speed;
            public float amount;
            public bool flag;
        }

        private readonly Dictionary<int, Actor> actors = new();
        private readonly List<TimedEffect> effects = new();
        private readonly List<AmbientMotion> ambientMotions = new();
        private readonly List<Material> materials = new();
        private readonly List<Texture2D> textures = new();

        private BattleSimulation simulation;
        private int lastCommandRevision;
        private GameObject worldRoot;
        private Camera battleCamera;
        private float cameraShake;
        private Vector3 cameraTarget = new(0.5f, 0.3f, 0.4f);
        private readonly Vector3 cameraOffset = new(-1.7f, 15.5f, -17.2f);
        private Material friendlyArmor;
        private Material friendlyCloth;
        private Material enemyArmor;
        private Material enemyCloth;
        private Material gold;
        private Material iron;
        private Material leather;
        private Material skin;
        private Material wood;
        private Material stone;
        private Material ground;
        private Material healthFlash;
        private Material chainMail;
        private Material obsidian;
        private Material fire;
        private Material smoke;
        private Material dust;
        private Material unitShadow;
        private Material backdrop;
        private RuntimeAnimatorController kayKitBattleController;
        private GameObject kayKitKnight;
        private GameObject kayKitRanger;
        private GameObject kayKitBarbarian;
        private GameObject kayKitRogue;
        private GameObject kayKitSword;
        private GameObject kayKitBow;
        private GameObject kayKitShield;

        public void Initialize(BattleSimulation value, RenderTexture target)
        {
            simulation = value;
            worldRoot = new GameObject("CİHAN 3B Kuşatma Dünyası");
            LoadKayKitAssets();
            BuildMaterials();
            BuildLighting(target);
            BuildBackdrop();
            BuildEnvironment();
            Sync();
        }

        private void LoadKayKitAssets()
        {
            kayKitBattleController =
                Resources.Load<RuntimeAnimatorController>("KayKit/KayKitBattle");
            kayKitKnight =
                Resources.Load<GameObject>("KayKit/Characters/Knight");
            kayKitRanger =
                Resources.Load<GameObject>("KayKit/Characters/Ranger");
            kayKitBarbarian =
                Resources.Load<GameObject>("KayKit/Characters/Barbarian");
            kayKitRogue =
                Resources.Load<GameObject>("KayKit/Characters/Rogue_Hooded");
            kayKitSword =
                Resources.Load<GameObject>("KayKit/Props/sword_1handed");
            kayKitBow =
                Resources.Load<GameObject>("KayKit/Props/bow_withString");
            kayKitShield =
                Resources.Load<GameObject>("KayKit/Props/shield_round_color");
        }

        private void Update()
        {
            HandleCameraGesture();
            AnimateAtmosphere();
            if (cameraShake > 0f && battleCamera != null)
            {
                cameraShake = Mathf.Max(
                    0f,
                    cameraShake - Time.unscaledDeltaTime);
                ApplyCameraTransform();
                battleCamera.transform.position +=
                    UnityEngine.Random.insideUnitSphere *
                    cameraShake *
                    0.32f;
            }
        }

        public void Sync()
        {
            if (simulation == null || worldRoot == null)
            {
                return;
            }

            foreach (var unit in simulation.Units)
            {
                if (!actors.TryGetValue(unit.id, out var actor))
                {
                    actor = CreateActor(unit);
                    actors[unit.id] = actor;
                }

                UpdateActor(actor, unit);
            }

            if (simulation.CommandRevision != lastCommandRevision)
            {
                lastCommandRevision = simulation.CommandRevision;
                PlayCommandEffect(simulation.LastCommand);
            }

            UpdateEffects(Time.unscaledDeltaTime);
        }

        public bool TryGetViewportPosition(int unitId, out Vector2 position)
        {
            position = Vector2.zero;
            if (battleCamera == null || !actors.TryGetValue(unitId, out var actor))
            {
                return false;
            }

            var point = battleCamera.WorldToViewportPoint(
                actor.root.transform.position + Vector3.up * 1.65f);
            if (point.z <= 0f)
            {
                return false;
            }

            position = new Vector2(
                Mathf.Clamp01(point.x),
                Mathf.Clamp01(point.y));
            return true;
        }

        private void BuildMaterials()
        {
            friendlyArmor = CreateMaterial(
                new Color32(38, 126, 116, 255),
                0.55f,
                0.38f);
            friendlyCloth = CreateMaterial(
                new Color32(23, 66, 67, 255),
                0.05f,
                0.2f);
            enemyArmor = CreateMaterial(
                new Color32(145, 52, 45, 255),
                0.5f,
                0.32f);
            enemyCloth = CreateMaterial(
                new Color32(73, 26, 28, 255),
                0.04f,
                0.18f);
            gold = CreateMaterial(new Color32(217, 170, 75, 255), 0.72f, 0.55f);
            iron = CreateMaterial(new Color32(103, 111, 114, 255), 0.82f, 0.5f);
            leather = CreateMaterial(new Color32(77, 48, 30, 255), 0.03f, 0.16f);
            skin = CreateMaterial(new Color32(180, 127, 91, 255), 0.02f, 0.2f);
            wood = CreateMaterial(new Color32(82, 54, 31, 255), 0.02f, 0.12f);
            stone = CreateMaterial(new Color32(107, 101, 87, 255), 0.02f, 0.16f);
            ground = CreateMaterial(new Color32(95, 86, 56, 255), 0.01f, 0.08f);
            healthFlash = CreateMaterial(
                new Color32(255, 207, 100, 255),
                0.25f,
                0.65f);
            chainMail = CreateMaterial(
                new Color32(67, 75, 78, 255),
                0.88f,
                0.42f);
            obsidian = CreateMaterial(
                new Color32(16, 18, 19, 255),
                0.18f,
                0.38f);
            fire = CreateMaterial(
                new Color32(255, 126, 35, 255),
                0.05f,
                0.82f);
            smoke = CreateMaterial(
                new Color32(61, 58, 51, 255),
                0.01f,
                0.02f);
            dust = CreateMaterial(
                new Color32(151, 125, 78, 255),
                0.01f,
                0.04f);
            unitShadow = CreateMaterial(
                new Color32(29, 25, 20, 255),
                0.01f,
                0.02f);

            var groundTexture = CreateGroundTexture();
            ground.mainTexture = groundTexture;
            ground.mainTextureScale = new Vector2(6.5f, 4.5f);
        }

        private void BuildBackdrop()
        {
            var texture = Resources.Load<Texture2D>("Art/cihan-battlefield-v2");
            if (texture == null)
            {
                return;
            }

            var shader = Shader.Find("Unlit/Texture");
            if (shader == null)
            {
                return;
            }

            backdrop = new Material(shader)
            {
                mainTexture = texture,
                color = new Color32(205, 190, 159, 255)
            };
            materials.Add(backdrop);

            var backdropObject = Primitive(
                "Sinematik Karacahisar Ufku",
                PrimitiveType.Quad,
                worldRoot.transform,
                new Vector3(0f, 6.3f, 8.8f),
                new Vector3(23f, 17f, 1f),
                backdrop);
            backdropObject.transform.rotation = Quaternion.identity;
            var renderer = backdropObject.GetComponent<MeshRenderer>();
            renderer.shadowCastingMode = ShadowCastingMode.Off;
            renderer.receiveShadows = false;
        }

        private void BuildLighting(RenderTexture target)
        {
            var cameraObject = new GameObject("İzometrik Savaş Kamerası");
            cameraObject.transform.SetParent(worldRoot.transform, false);
            battleCamera = cameraObject.AddComponent<Camera>();
            battleCamera.targetTexture = target;
            battleCamera.clearFlags = CameraClearFlags.SolidColor;
            battleCamera.backgroundColor = new Color32(71, 72, 62, 255);
            battleCamera.fieldOfView = 40f;
            battleCamera.nearClipPlane = 0.15f;
            battleCamera.farClipPlane = 80f;
            battleCamera.allowHDR = false;
            battleCamera.allowMSAA = true;
            ApplyCameraTransform();

            var sunObject = new GameObject("Akşam Güneşi");
            sunObject.transform.SetParent(worldRoot.transform, false);
            var sun = sunObject.AddComponent<Light>();
            sun.type = LightType.Directional;
            sun.color = new Color32(255, 216, 159, 255);
            sun.intensity = 1.3f;
            sun.shadows = LightShadows.Soft;
            sun.shadowStrength = 0.78f;
            sun.cullingMask &= ~(1 << 30);
            sunObject.transform.rotation = Quaternion.Euler(43f, -38f, 0f);

            var fillObject = new GameObject("Soğuk Dolgu Işığı");
            fillObject.transform.SetParent(worldRoot.transform, false);
            var fill = fillObject.AddComponent<Light>();
            fill.type = LightType.Directional;
            fill.color = new Color32(112, 151, 171, 255);
            fill.intensity = 0.42f;
            fill.shadows = LightShadows.None;
            fill.cullingMask &= ~(1 << 30);
            fillObject.transform.rotation = Quaternion.Euler(58f, 132f, 0f);

            RenderSettings.ambientMode = AmbientMode.Trilight;
            RenderSettings.ambientSkyColor = new Color32(117, 120, 109, 255);
            RenderSettings.ambientEquatorColor = new Color32(81, 80, 68, 255);
            RenderSettings.ambientGroundColor = new Color32(43, 40, 31, 255);
        }

        private void HandleCameraGesture()
        {
            if (battleCamera == null)
            {
                return;
            }

            if (Input.touchCount == 1)
            {
                var touch = Input.GetTouch(0);
                var normalizedY = touch.position.y / Mathf.Max(1f, Screen.height);
                if (touch.phase == TouchPhase.Moved &&
                    normalizedY > 0.17f &&
                    normalizedY < 0.87f)
                {
                    cameraTarget.x = Mathf.Clamp(
                        cameraTarget.x - touch.deltaPosition.x * 0.006f,
                        -2.2f,
                        2.2f);
                    cameraTarget.z = Mathf.Clamp(
                        cameraTarget.z - touch.deltaPosition.y * 0.006f,
                        -2.1f,
                        2.1f);
                    ApplyCameraTransform();
                }
            }
            else if (Input.touchCount == 2)
            {
                var first = Input.GetTouch(0);
                var second = Input.GetTouch(1);
                var previousFirst = first.position - first.deltaPosition;
                var previousSecond = second.position - second.deltaPosition;
                var previousDistance = Vector2.Distance(previousFirst, previousSecond);
                var currentDistance = Vector2.Distance(first.position, second.position);
                battleCamera.fieldOfView = Mathf.Clamp(
                    battleCamera.fieldOfView -
                    (currentDistance - previousDistance) * 0.018f,
                    31f,
                    52f);
            }

            var wheel = Input.mouseScrollDelta.y;
            if (Mathf.Abs(wheel) > 0.01f)
            {
                battleCamera.fieldOfView = Mathf.Clamp(
                    battleCamera.fieldOfView - wheel * 2f,
                    31f,
                    52f);
            }
        }

        private void ApplyCameraTransform()
        {
            battleCamera.transform.position = cameraTarget + cameraOffset;
            battleCamera.transform.LookAt(cameraTarget);
        }

        private void AnimateAtmosphere()
        {
            var time = Time.unscaledTime;
            for (var index = ambientMotions.Count - 1; index >= 0; index -= 1)
            {
                var motion = ambientMotions[index];
                if (motion.root == null)
                {
                    ambientMotions.RemoveAt(index);
                    continue;
                }

                var wave = Mathf.Sin(time * motion.speed + motion.phase);
                if (motion.flag)
                {
                    motion.root.localRotation = motion.baseRotation *
                        Quaternion.Euler(0f, wave * motion.amount, wave * motion.amount * 0.22f);
                    motion.root.localScale = new Vector3(
                        motion.baseScale.x * (1f + wave * 0.045f),
                        motion.baseScale.y,
                        motion.baseScale.z);
                }
                else
                {
                    motion.root.localPosition = motion.basePosition +
                        new Vector3(wave * motion.amount * 0.12f, (wave + 1f) * motion.amount, 0f);
                    motion.root.localScale = motion.baseScale *
                        (1f + (wave + 1f) * 0.08f);
                    motion.root.Rotate(0f, Time.unscaledDeltaTime * 7f, 0f, Space.Self);
                }
            }
        }

        private Texture2D CreateGroundTexture()
        {
            const int size = 128;
            var texture = new Texture2D(size, size, TextureFormat.RGB24, true)
            {
                name = "CİHAN Prosedürel Toprak Dokusu",
                wrapMode = TextureWrapMode.Repeat,
                filterMode = FilterMode.Bilinear
            };

            for (var y = 0; y < size; y += 1)
            {
                for (var x = 0; x < size; x += 1)
                {
                    var broad = Mathf.PerlinNoise(x * 0.045f, y * 0.045f);
                    var grit = Mathf.PerlinNoise(x * 0.19f + 17f, y * 0.19f + 9f);
                    var value = Mathf.Clamp01(0.53f + broad * 0.25f + grit * 0.12f);
                    var color = Color.Lerp(
                        new Color32(67, 56, 34, 255),
                        new Color32(139, 119, 74, 255),
                        value);
                    if ((x * 17 + y * 31) % 97 == 0)
                    {
                        color *= 0.58f;
                    }

                    texture.SetPixel(x, y, color);
                }
            }

            texture.Apply(true, false);
            textures.Add(texture);
            return texture;
        }

        private void RegisterAmbientMotion(
            Transform value,
            float speed,
            float amount,
            bool flag)
        {
            ambientMotions.Add(new AmbientMotion
            {
                root = value,
                basePosition = value.localPosition,
                baseScale = value.localScale,
                baseRotation = value.localRotation,
                phase = ambientMotions.Count * 1.37f,
                speed = speed,
                amount = amount,
                flag = flag
            });
        }

        private void BuildEnvironment()
        {
            var terrain = Primitive(
                "Kurumuş Savaş Ovası",
                PrimitiveType.Cube,
                worldRoot.transform,
                new Vector3(0f, -0.32f, 0f),
                new Vector3(21f, 0.55f, 13.5f),
                ground);
            terrain.transform.rotation = Quaternion.Euler(0f, -2f, 0f);

            for (var index = 0; index < 18; index += 1)
            {
                var z = -5.4f + index * 0.63f;
                var trench = Primitive(
                    $"Savunma Kazığı {index + 1}",
                    PrimitiveType.Cube,
                    worldRoot.transform,
                    new Vector3(5.55f + Mathf.Sin(index) * 0.12f, 0.06f, z),
                    new Vector3(0.1f, 0.48f, 0.1f),
                    wood);
                trench.transform.rotation = Quaternion.Euler(
                    index % 2 == 0 ? 18f : -18f,
                    0f,
                    index % 2 == 0 ? 21f : -21f);
            }

            BuildFortress();
            BuildCamp();
            BuildRocks();
            BuildSiegeAtmosphere();
        }

        private void BuildFortress()
        {
            var fortress = new GameObject("Karacahisar Kalesi");
            fortress.transform.SetParent(worldRoot.transform, false);
            fortress.transform.position = new Vector3(8.55f, 0f, 0.4f);

            Primitive(
                "Ana Sur",
                PrimitiveType.Cube,
                fortress.transform,
                new Vector3(0f, 1.15f, 0f),
                new Vector3(0.72f, 2.8f, 10.8f),
                stone);

            for (var z = -4.8f; z <= 4.8f; z += 1.2f)
            {
                Primitive(
                    "Sur Mazgalı",
                    PrimitiveType.Cube,
                    fortress.transform,
                    new Vector3(-0.02f, 2.82f, z),
                    new Vector3(0.88f, 0.42f, 0.52f),
                    stone);
            }

            BuildTower(fortress.transform, -4.95f, 1.25f);
            BuildTower(fortress.transform, 4.95f, 1.25f);
            BuildTower(fortress.transform, 0f, 1.55f);

            Primitive(
                "Kale Kapısı",
                PrimitiveType.Cube,
                fortress.transform,
                new Vector3(-0.42f, 0.72f, 0f),
                new Vector3(0.18f, 1.55f, 1.35f),
                wood);

            var flagPole = Primitive(
                "Hisar Sancağı Direği",
                PrimitiveType.Cylinder,
                fortress.transform,
                new Vector3(0f, 4.7f, 0f),
                new Vector3(0.07f, 1.5f, 0.07f),
                iron);
            flagPole.transform.rotation = Quaternion.identity;
            var fortressFlag = Primitive(
                "Hisar Sancağı",
                PrimitiveType.Cube,
                fortress.transform,
                new Vector3(-0.38f, 5.18f, 0f),
                new Vector3(0.75f, 0.52f, 0.06f),
                enemyArmor);
            RegisterAmbientMotion(fortressFlag.transform, 2.6f, 12f, true);
        }

        private void BuildTower(Transform parent, float z, float extraHeight)
        {
            Primitive(
                "Sur Kulesi",
                PrimitiveType.Cylinder,
                parent,
                new Vector3(-0.02f, 1.35f + extraHeight * 0.25f, z),
                new Vector3(1.45f, 1.4f + extraHeight * 0.22f, 1.45f),
                stone,
                8);
            Primitive(
                "Kule Tacı",
                PrimitiveType.Cylinder,
                parent,
                new Vector3(-0.02f, 3.04f + extraHeight * 0.25f, z),
                new Vector3(1.65f, 0.25f, 1.65f),
                stone,
                8);
        }

        private void BuildCamp()
        {
            var camp = new GameObject("CİHAN Sefer Kampı");
            camp.transform.SetParent(worldRoot.transform, false);
            camp.transform.position = new Vector3(-8.3f, 0f, -0.4f);

            for (var index = 0; index < 3; index += 1)
            {
                var tent = Primitive(
                    $"Sefer Çadırı {index + 1}",
                    PrimitiveType.Cylinder,
                    camp.transform,
                    new Vector3(0f, 0.58f, -3.1f + index * 3.1f),
                    new Vector3(1.2f, 0.7f, 1.2f),
                    friendlyCloth,
                    4);
                tent.transform.rotation = Quaternion.Euler(0f, 45f, 0f);
            }

            Primitive(
                "Ordu Sancağı Direği",
                PrimitiveType.Cylinder,
                camp.transform,
                new Vector3(0.3f, 1.65f, 0f),
                new Vector3(0.05f, 1.65f, 0.05f),
                wood);
            var campFlag = Primitive(
                "Ordu Sancağı",
                PrimitiveType.Cube,
                camp.transform,
                new Vector3(0.7f, 2.55f, 0f),
                new Vector3(0.82f, 0.58f, 0.06f),
                friendlyArmor);
            RegisterAmbientMotion(campFlag.transform, 2.25f, 11f, true);
        }

        private void BuildRocks()
        {
            for (var index = 0; index < 24; index += 1)
            {
                var angle = index * 1.91f;
                var x = Mathf.Lerp(-7.6f, 7.1f, Mathf.Repeat(index * 0.37f, 1f));
                var z = index % 2 == 0 ? -5.5f : 5.5f;
                var rock = Primitive(
                    $"Saha Taşı {index + 1}",
                    PrimitiveType.Sphere,
                    worldRoot.transform,
                    new Vector3(x, -0.02f, z + Mathf.Sin(angle) * 0.4f),
                    new Vector3(
                        0.28f + index % 3 * 0.08f,
                        0.16f,
                        0.22f + index % 4 * 0.05f),
                    stone);
                rock.transform.rotation = Quaternion.Euler(
                    index * 13f,
                    index * 29f,
                    index * 7f);
            }
        }

        private void BuildSiegeAtmosphere()
        {
            var road = Primitive(
                "Kuşatma Yolu",
                PrimitiveType.Cube,
                worldRoot.transform,
                new Vector3(0f, -0.025f, 0.15f),
                new Vector3(18.6f, 0.045f, 3.35f),
                dust);
            road.transform.rotation = Quaternion.Euler(0f, 1.5f, 0f);

            foreach (var z in new[] { -4.65f, 4.65f })
            {
                for (var index = 0; index < 5; index += 1)
                {
                    var barricade = new GameObject("Çapraz Savunma Kazığı");
                    barricade.transform.SetParent(worldRoot.transform, false);
                    barricade.transform.localPosition = new Vector3(
                        -1.5f + index * 1.45f,
                        0.12f,
                        z);
                    Primitive(
                        "Kazık Sol",
                        PrimitiveType.Cube,
                        barricade.transform,
                        Vector3.zero,
                        new Vector3(0.12f, 0.95f, 0.12f),
                        darkWood()).transform.localRotation = Quaternion.Euler(0f, 0f, 47f);
                    Primitive(
                        "Kazık Sağ",
                        PrimitiveType.Cube,
                        barricade.transform,
                        Vector3.zero,
                        new Vector3(0.12f, 0.95f, 0.12f),
                        darkWood()).transform.localRotation = Quaternion.Euler(0f, 0f, -47f);
                }
            }

            BuildBrazier(new Vector3(-5.7f, 0f, -4.15f));
            BuildBrazier(new Vector3(-5.7f, 0f, 4.15f));
            BuildBrazier(new Vector3(6.25f, 0f, -3.75f));
            BuildBrazier(new Vector3(6.25f, 0f, 3.75f));
            BuildSmokeColumn(new Vector3(7.2f, 2.5f, -3.2f), 0.72f);
            BuildSmokeColumn(new Vector3(7.45f, 3.1f, 2.6f), 0.58f);
            BuildSmokeColumn(new Vector3(-6.7f, 1.3f, -3.6f), 0.42f);

            var tower = new GameObject("Ahşap Kuşatma Kulesi");
            tower.transform.SetParent(worldRoot.transform, false);
            tower.transform.localPosition = new Vector3(4.85f, 0f, -4.25f);
            Primitive(
                "Kule Gövdesi",
                PrimitiveType.Cube,
                tower.transform,
                new Vector3(0f, 1.35f, 0f),
                new Vector3(1.15f, 2.7f, 1.15f),
                wood);
            for (var level = 0; level < 3; level += 1)
            {
                Primitive(
                    "Kule Kuşağı",
                    PrimitiveType.Cube,
                    tower.transform,
                    new Vector3(0f, 0.45f + level * 0.85f, -0.59f),
                    new Vector3(1.32f, 0.12f, 0.12f),
                    iron);
            }

            foreach (var z in new[] { -0.62f, 0.62f })
            {
                var wheel = Primitive(
                    "Kuşatma Kulesi Tekeri",
                    PrimitiveType.Cylinder,
                    tower.transform,
                    new Vector3(-0.25f, 0.32f, z),
                    new Vector3(0.46f, 0.12f, 0.46f),
                    obsidian,
                    12);
                wheel.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
            }

            for (var index = 0; index < 6; index += 1)
            {
                Primitive(
                    "Şahi Güllesi",
                    PrimitiveType.Sphere,
                    worldRoot.transform,
                    new Vector3(
                        -6.75f + (index % 3) * 0.34f,
                        0.16f + (index / 3) * 0.25f,
                        3.55f + (index % 2) * 0.18f),
                    Vector3.one * 0.28f,
                    obsidian);
            }
        }

        private void BuildBrazier(Vector3 position)
        {
            var brazier = new GameObject("Kuşatma Meşalesi");
            brazier.transform.SetParent(worldRoot.transform, false);
            brazier.transform.localPosition = position;
            Primitive(
                "Meşale Direği",
                PrimitiveType.Cylinder,
                brazier.transform,
                new Vector3(0f, 0.72f, 0f),
                new Vector3(0.055f, 0.72f, 0.055f),
                wood);
            Primitive(
                "Kor Haznesi",
                PrimitiveType.Cylinder,
                brazier.transform,
                new Vector3(0f, 1.46f, 0f),
                new Vector3(0.22f, 0.12f, 0.22f),
                iron,
                10);
            var flameObject = Primitive(
                "Alev",
                PrimitiveType.Sphere,
                brazier.transform,
                new Vector3(0f, 1.68f, 0f),
                new Vector3(0.22f, 0.42f, 0.22f),
                fire);
            RegisterAmbientMotion(flameObject.transform, 7.5f, 0.06f, false);
            var smokeObject = Primitive(
                "Duman",
                PrimitiveType.Sphere,
                brazier.transform,
                new Vector3(0.05f, 2.15f, 0f),
                new Vector3(0.28f, 0.48f, 0.28f),
                smoke);
            RegisterAmbientMotion(smokeObject.transform, 1.35f, 0.12f, false);

            var glowObject = new GameObject("Alev Işığı");
            glowObject.transform.SetParent(brazier.transform, false);
            glowObject.transform.localPosition = new Vector3(0f, 1.72f, 0f);
            var glow = glowObject.AddComponent<Light>();
            glow.type = LightType.Point;
            glow.color = new Color32(255, 135, 52, 255);
            glow.range = 2.6f;
            glow.intensity = 1.05f;
            glow.shadows = LightShadows.None;
        }

        private void BuildSmokeColumn(Vector3 position, float scale)
        {
            var column = new GameObject("Uzak Kuşatma Dumanı");
            column.transform.SetParent(worldRoot.transform, false);
            column.transform.localPosition = position;
            for (var index = 0; index < 4; index += 1)
            {
                var puff = Primitive(
                    "Duman Katmanı",
                    PrimitiveType.Sphere,
                    column.transform,
                    new Vector3(
                        Mathf.Sin(index * 1.7f) * 0.18f,
                        index * 0.48f,
                        Mathf.Cos(index * 1.3f) * 0.12f),
                    Vector3.one * scale * (0.72f + index * 0.12f),
                    smoke);
                RegisterAmbientMotion(
                    puff.transform,
                    0.52f + index * 0.11f,
                    0.10f + index * 0.025f,
                    false);
            }
        }

        private Material darkWood()
        {
            return leather;
        }

        private Actor CreateActor(BattleUnit unit)
        {
            var root = new GameObject(
                $"{TeamName(unit.team)} {KindName(unit.kind)} Mangası {unit.id}");
            root.transform.SetParent(worldRoot.transform, false);
            var model = new GameObject("Hareketli Manga").transform;
            model.SetParent(root.transform, false);

            var weapons = new List<Transform>();
            switch (unit.kind)
            {
                case BattleUnitKind.Infantry:
                    BuildInfantrySquad(model, unit.team, weapons);
                    break;
                case BattleUnitKind.Archer:
                    BuildArcherSquad(model, unit.team, weapons);
                    break;
                case BattleUnitKind.Cavalry:
                    BuildCavalrySquad(model, unit.team, weapons);
                    break;
                case BattleUnitKind.Siege:
                    BuildCannon(model, unit.team, weapons);
                    break;
                case BattleUnitKind.Commander:
                    BuildCommander(model, unit.team, weapons);
                    break;
            }

            var shadowScale = unit.kind switch
            {
                BattleUnitKind.Cavalry => new Vector3(1.22f, 0.025f, 0.74f),
                BattleUnitKind.Siege => new Vector3(1.34f, 0.025f, 0.92f),
                BattleUnitKind.Commander => new Vector3(0.92f, 0.025f, 0.72f),
                _ => new Vector3(0.86f, 0.025f, 0.68f)
            };
            var squadShadow = Primitive(
                "Birlik Zemini Gölgesi",
                PrimitiveType.Cylinder,
                root.transform,
                new Vector3(0f, -0.01f, 0f),
                shadowScale,
                unitShadow,
                20);
            var shadowRenderer = squadShadow.GetComponent<MeshRenderer>();
            shadowRenderer.shadowCastingMode = ShadowCastingMode.Off;
            shadowRenderer.receiveShadows = false;

            if (unit.kind != BattleUnitKind.Cavalry &&
                unit.kind != BattleUnitKind.Siege)
            {
                BuildSquadStandard(model, unit.team, unit.kind);
            }

            var actor = new Actor
            {
                root = root,
                model = model,
                weapons = weapons.ToArray(),
                animators = model.GetComponentsInChildren<Animator>(true),
                lastWorldPosition = WorldPosition(unit),
                lastAttackTimer = unit.attackTimer,
                lastHealth = unit.hp,
                nextDustTime = Time.unscaledTime + 0.1f + unit.id % 4 * 0.04f,
                phase = unit.id * 0.79f
            };
            actor.weaponRestRotations = new Quaternion[actor.weapons.Length];
            for (var index = 0; index < actor.weapons.Length; index += 1)
            {
                actor.weaponRestRotations[index] = actor.weapons[index].localRotation;
            }

            root.transform.position = actor.lastWorldPosition;
            root.transform.rotation = Quaternion.Euler(
                0f,
                unit.team == BattleTeam.Friendly ? 0f : 180f,
                0f);
            PlayActorAnimation(actor, "Idle", 0f, true);
            return actor;
        }

        private void BuildSquadStandard(
            Transform parent,
            BattleTeam team,
            BattleUnitKind kind)
        {
            var primary = team == BattleTeam.Friendly ? friendlyArmor : enemyArmor;
            var standard = new GameObject("Hareketli Manga Sancağı");
            standard.transform.SetParent(parent, false);
            standard.transform.localPosition = new Vector3(-0.56f, 0f, -0.46f);

            Primitive(
                "Sancak Direği",
                PrimitiveType.Cylinder,
                standard.transform,
                new Vector3(0f, 1.12f, 0f),
                new Vector3(0.035f, 1.12f, 0.035f),
                wood);
            Primitive(
                "Sancak Alemi",
                PrimitiveType.Sphere,
                standard.transform,
                new Vector3(0f, 2.26f, 0f),
                Vector3.one * 0.095f,
                gold);
            var flag = Primitive(
                "Manga Sancağı",
                PrimitiveType.Cube,
                standard.transform,
                new Vector3(0.30f, 1.86f, 0f),
                new Vector3(0.58f, 0.46f, 0.045f),
                primary);
            Primitive(
                kind == BattleUnitKind.Archer ? "Okçu İşareti" : "Manga İşareti",
                kind == BattleUnitKind.Archer ? PrimitiveType.Cube : PrimitiveType.Sphere,
                flag.transform,
                new Vector3(0f, 0f, -0.62f),
                kind == BattleUnitKind.Archer
                    ? new Vector3(0.08f, 0.55f, 0.08f)
                    : Vector3.one * 0.22f,
                gold);
            RegisterAmbientMotion(flag.transform, 3.1f, 9f, true);
        }

        private void BuildInfantrySquad(
            Transform parent,
            BattleTeam team,
            ICollection<Transform> weapons)
        {
            var offsets = new[]
            {
                new Vector3(0f, 0f, 0f),
                new Vector3(-0.42f, 0f, -0.38f),
                new Vector3(-0.42f, 0f, 0.38f)
            };
            foreach (var offset in offsets)
            {
                BuildSoldier(parent, team, offset, true, false, weapons);
            }
        }

        private void BuildArcherSquad(
            Transform parent,
            BattleTeam team,
            ICollection<Transform> weapons)
        {
            BuildSoldier(
                parent,
                team,
                new Vector3(0f, 0f, -0.25f),
                false,
                true,
                weapons);
            BuildSoldier(
                parent,
                team,
                new Vector3(-0.42f, 0f, 0.28f),
                false,
                true,
                weapons);
        }

        private void BuildSoldier(
            Transform parent,
            BattleTeam team,
            Vector3 offset,
            bool shield,
            bool bow,
            ICollection<Transform> weapons)
        {
            if (TryBuildKayKitSoldier(parent, team, offset, shield, bow))
            {
                return;
            }

            var primary = team == BattleTeam.Friendly ? friendlyArmor : enemyArmor;
            var cloth = team == BattleTeam.Friendly ? friendlyCloth : enemyCloth;
            var soldier = new GameObject(bow ? "Zırhlı Okçu" : "Zırhlı Piyade");
            soldier.transform.SetParent(parent, false);
            soldier.transform.localPosition = offset;
            soldier.transform.localScale = Vector3.one * 0.72f;

            Primitive(
                "Kaftan",
                PrimitiveType.Capsule,
                soldier.transform,
                new Vector3(0f, 0.88f, 0f),
                new Vector3(0.5f, 0.62f, 0.42f),
                cloth);
            Primitive(
                "Göğüs Zırhı",
                PrimitiveType.Cube,
                soldier.transform,
                new Vector3(0.03f, 1.12f, 0f),
                new Vector3(0.48f, 0.46f, 0.38f),
                primary);
            Primitive(
                "Zırh Kemeri",
                PrimitiveType.Cube,
                soldier.transform,
                new Vector3(0.03f, 0.83f, 0f),
                new Vector3(0.54f, 0.10f, 0.42f),
                gold);
            Primitive(
                "Zincir Etek",
                PrimitiveType.Cylinder,
                soldier.transform,
                new Vector3(0f, 0.64f, 0f),
                new Vector3(0.43f, 0.24f, 0.37f),
                chainMail,
                10);
            Primitive(
                "Zincir Boyunluk",
                PrimitiveType.Cylinder,
                soldier.transform,
                new Vector3(0f, 1.43f, 0f),
                new Vector3(0.31f, 0.12f, 0.31f),
                chainMail,
                12);
            Primitive(
                "Sol Omuzluk",
                PrimitiveType.Sphere,
                soldier.transform,
                new Vector3(-0.31f, 1.30f, 0f),
                new Vector3(0.22f, 0.18f, 0.28f),
                primary);
            Primitive(
                "Sağ Omuzluk",
                PrimitiveType.Sphere,
                soldier.transform,
                new Vector3(0.33f, 1.30f, 0f),
                new Vector3(0.22f, 0.18f, 0.28f),
                primary);
            Primitive(
                "Sol Kol",
                PrimitiveType.Capsule,
                soldier.transform,
                new Vector3(-0.34f, 1.02f, 0f),
                new Vector3(0.16f, 0.37f, 0.16f),
                leather).transform.localRotation = Quaternion.Euler(0f, 0f, -9f);
            Primitive(
                "Sağ Kol",
                PrimitiveType.Capsule,
                soldier.transform,
                new Vector3(0.36f, 1.02f, 0f),
                new Vector3(0.16f, 0.37f, 0.16f),
                leather).transform.localRotation = Quaternion.Euler(0f, 0f, 9f);
            Primitive(
                "Baş",
                PrimitiveType.Sphere,
                soldier.transform,
                new Vector3(0f, 1.62f, 0f),
                new Vector3(0.32f, 0.34f, 0.32f),
                skin);
            Primitive(
                "Miğfer",
                PrimitiveType.Sphere,
                soldier.transform,
                new Vector3(0f, 1.75f, 0f),
                new Vector3(0.37f, 0.25f, 0.37f),
                iron);
            Primitive(
                "Miğfer Sorgucu",
                PrimitiveType.Cylinder,
                soldier.transform,
                new Vector3(0f, 1.97f, 0f),
                new Vector3(0.06f, 0.18f, 0.06f),
                gold);
            Primitive(
                "Yüz Siperi",
                PrimitiveType.Cube,
                soldier.transform,
                new Vector3(0.19f, 1.63f, 0f),
                new Vector3(0.05f, 0.12f, 0.34f),
                iron);
            foreach (var eyeZ in new[] { -0.105f, 0.105f })
            {
                Primitive(
                    "Göz",
                    PrimitiveType.Sphere,
                    soldier.transform,
                    new Vector3(0.292f, 1.65f, eyeZ),
                    Vector3.one * 0.035f,
                    obsidian);
            }
            Primitive(
                "Bıyık",
                PrimitiveType.Cube,
                soldier.transform,
                new Vector3(0.304f, 1.55f, 0f),
                new Vector3(0.025f, 0.04f, 0.18f),
                leather);
            Primitive(
                "Sol Bacak",
                PrimitiveType.Cube,
                soldier.transform,
                new Vector3(-0.13f, 0.29f, 0f),
                new Vector3(0.15f, 0.55f, 0.18f),
                leather);
            Primitive(
                "Sağ Bacak",
                PrimitiveType.Cube,
                soldier.transform,
                new Vector3(0.13f, 0.29f, 0f),
                new Vector3(0.15f, 0.55f, 0.18f),
                leather);
            Primitive(
                "Sol Çizme",
                PrimitiveType.Cube,
                soldier.transform,
                new Vector3(-0.13f, 0.07f, 0.055f),
                new Vector3(0.19f, 0.20f, 0.28f),
                obsidian);
            Primitive(
                "Sağ Çizme",
                PrimitiveType.Cube,
                soldier.transform,
                new Vector3(0.13f, 0.07f, 0.055f),
                new Vector3(0.19f, 0.20f, 0.28f),
                obsidian);

            if (shield)
            {
                var shieldObject = Primitive(
                    "Kabartmalı Kalkan",
                    PrimitiveType.Cylinder,
                    soldier.transform,
                    new Vector3(0.1f, 1.05f, 0.38f),
                    new Vector3(0.48f, 0.07f, 0.48f),
                    primary,
                    12);
                shieldObject.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
                Primitive(
                    "Kalkan Göbeği",
                    PrimitiveType.Sphere,
                    shieldObject.transform,
                    new Vector3(0f, 0.15f, 0f),
                    new Vector3(0.32f, 0.18f, 0.32f),
                    gold);
                Primitive(
                    "Kalkan Hilali",
                    PrimitiveType.Cylinder,
                    shieldObject.transform,
                    new Vector3(0f, 0.30f, 0f),
                    new Vector3(0.16f, 0.035f, 0.16f),
                    gold,
                    12);
            }

            if (bow)
            {
                var bowRoot = new GameObject("Yay").transform;
                bowRoot.SetParent(soldier.transform, false);
                bowRoot.localPosition = new Vector3(0.1f, 1.1f, 0.36f);
                Primitive(
                    "Yay Üst",
                    PrimitiveType.Cube,
                    bowRoot,
                    new Vector3(0f, 0.24f, 0f),
                    new Vector3(0.06f, 0.48f, 0.06f),
                    wood).transform.localRotation = Quaternion.Euler(0f, 0f, -18f);
                Primitive(
                    "Yay Alt",
                    PrimitiveType.Cube,
                    bowRoot,
                    new Vector3(0f, -0.24f, 0f),
                    new Vector3(0.06f, 0.48f, 0.06f),
                    wood).transform.localRotation = Quaternion.Euler(0f, 0f, 18f);
                var quiver = Primitive(
                    "Okluk",
                    PrimitiveType.Cylinder,
                    soldier.transform,
                    new Vector3(-0.22f, 1.04f, -0.31f),
                    new Vector3(0.15f, 0.44f, 0.15f),
                    leather,
                    10);
                quiver.transform.localRotation = Quaternion.Euler(9f, 0f, 22f);
                for (var arrowIndex = 0; arrowIndex < 3; arrowIndex += 1)
                {
                    Primitive(
                        "Okluktaki Ok",
                        PrimitiveType.Cube,
                        soldier.transform,
                        new Vector3(
                            -0.24f,
                            1.46f + arrowIndex * 0.025f,
                            -0.38f + arrowIndex * 0.07f),
                        new Vector3(0.035f, 0.62f, 0.035f),
                        wood).transform.localRotation = Quaternion.Euler(0f, 0f, 10f);
                }
                weapons.Add(bowRoot);
            }
            else
            {
                var swordRoot = new GameObject("Kılıç Eli").transform;
                swordRoot.SetParent(soldier.transform, false);
                swordRoot.localPosition = new Vector3(0.04f, 1.1f, -0.34f);
                swordRoot.localRotation = Quaternion.Euler(0f, 0f, -18f);
                Primitive(
                    "Kılıç",
                    PrimitiveType.Cube,
                    swordRoot,
                    new Vector3(0f, 0.42f, 0f),
                    new Vector3(0.08f, 0.84f, 0.08f),
                    iron);
                Primitive(
                    "Kılıç Kabzası",
                    PrimitiveType.Cube,
                    swordRoot,
                    new Vector3(0f, -0.02f, 0f),
                    new Vector3(0.32f, 0.07f, 0.08f),
                    gold);
                Primitive(
                    "Kılıç Kını",
                    PrimitiveType.Cube,
                    soldier.transform,
                    new Vector3(-0.08f, 0.62f, 0.33f),
                    new Vector3(0.08f, 0.72f, 0.10f),
                    leather).transform.localRotation = Quaternion.Euler(0f, 0f, 28f);
                weapons.Add(swordRoot);
            }
        }

        private bool TryBuildKayKitSoldier(
            Transform parent,
            BattleTeam team,
            Vector3 offset,
            bool shield,
            bool bow)
        {
            var characterPrefab = bow
                ? kayKitRanger
                : Mathf.Abs(offset.z) > 0.1f && kayKitRogue != null
                    ? kayKitRogue
                    : kayKitKnight;
            if (characterPrefab == null || kayKitBattleController == null)
            {
                return false;
            }

            var soldier = new GameObject(
                bow ? "KayKit Zırhlı Okçu" : "KayKit Zırhlı Piyade");
            soldier.transform.SetParent(parent, false);
            soldier.transform.localPosition = offset;
            soldier.transform.localScale = Vector3.one * 0.80f;

            var character = Instantiate(characterPrefab, soldier.transform);
            character.name = bow ? "Animasyonlu Okçu" : "Animasyonlu Piyade";
            character.transform.localPosition = Vector3.zero;
            character.transform.localRotation = Quaternion.Euler(0f, 90f, 0f);
            character.transform.localScale = Vector3.one;

            var animator = character.GetComponent<Animator>();
            if (animator == null)
            {
                animator = character.AddComponent<Animator>();
            }

            animator.runtimeAnimatorController = kayKitBattleController;
            animator.applyRootMotion = false;
            animator.cullingMode = AnimatorCullingMode.AlwaysAnimate;
            animator.updateMode = AnimatorUpdateMode.UnscaledTime;

            TintKayKitModel(character, team);
            var rightHand = FindDescendant(character.transform, "handslot.r");
            var leftHand = FindDescendant(character.transform, "handslot.l");
            AttachKayKitProp(
                bow ? kayKitBow : kayKitSword,
                rightHand,
                bow ? "Tarihî Yay" : "Çelik Kılıç");
            if (shield)
            {
                AttachKayKitProp(kayKitShield, leftHand, "Cihan Kalkanı");
            }

            var teamMarker = Primitive(
                "Birlik Renk Kuşağı",
                PrimitiveType.Cube,
                soldier.transform,
                new Vector3(-0.04f, 1.02f, -0.30f),
                new Vector3(0.10f, 0.62f, 0.08f),
                team == BattleTeam.Friendly ? friendlyArmor : enemyArmor);
            teamMarker.transform.localRotation = Quaternion.Euler(8f, 0f, 10f);

            if (team == BattleTeam.Friendly)
            {
                var headwear = Primitive(
                    bow ? "Serhat Sarığı" : "Kapıkulu Börkü",
                    PrimitiveType.Cylinder,
                    soldier.transform,
                    bow ? new Vector3(0f, 1.78f, 0f) : new Vector3(0f, 1.86f, 0f),
                    bow
                        ? new Vector3(0.34f, 0.12f, 0.34f)
                        : new Vector3(0.24f, 0.38f, 0.24f),
                    bow ? healthFlash : friendlyCloth,
                    14);
                headwear.transform.localRotation = Quaternion.Euler(0f, 0f, bow ? -5f : 0f);
                Primitive(
                    "Altın Birlik Mührü",
                    PrimitiveType.Sphere,
                    soldier.transform,
                    new Vector3(0.20f, bow ? 1.80f : 1.94f, -0.04f),
                    Vector3.one * 0.085f,
                    gold);
            }
            else
            {
                Primitive(
                    "Hisar Miğferi",
                    PrimitiveType.Sphere,
                    soldier.transform,
                    new Vector3(0f, 1.80f, 0f),
                    new Vector3(0.31f, 0.20f, 0.31f),
                    iron);
            }
            return true;
        }

        private static Transform FindDescendant(Transform parent, string name)
        {
            if (string.Equals(parent.name, name, StringComparison.OrdinalIgnoreCase))
            {
                return parent;
            }

            for (var index = 0; index < parent.childCount; index += 1)
            {
                var result = FindDescendant(parent.GetChild(index), name);
                if (result != null)
                {
                    return result;
                }
            }

            return null;
        }

        private static void AttachKayKitProp(
            GameObject prefab,
            Transform socket,
            string name)
        {
            if (prefab == null || socket == null)
            {
                return;
            }

            var prop = Instantiate(prefab, socket);
            prop.name = name;
            prop.transform.localPosition = Vector3.zero;
            prop.transform.localRotation = Quaternion.identity;
            prop.transform.localScale = Vector3.one;
            foreach (var renderer in prop.GetComponentsInChildren<Renderer>(true))
            {
                renderer.shadowCastingMode = ShadowCastingMode.On;
                renderer.receiveShadows = true;
            }
        }

        private static void TintKayKitModel(GameObject character, BattleTeam team)
        {
            var tint = team == BattleTeam.Friendly
                ? new Color(0.68f, 0.94f, 0.89f, 1f)
                : new Color(1f, 0.60f, 0.55f, 1f);
            foreach (var renderer in character.GetComponentsInChildren<Renderer>(true))
            {
                var properties = new MaterialPropertyBlock();
                renderer.GetPropertyBlock(properties);
                properties.SetColor("_BaseColor", tint);
                properties.SetColor("_Color", tint);
                renderer.SetPropertyBlock(properties);
                renderer.shadowCastingMode = ShadowCastingMode.On;
                renderer.receiveShadows = true;
            }
        }

        private void BuildCavalrySquad(
            Transform parent,
            BattleTeam team,
            ICollection<Transform> weapons)
        {
            var primary = team == BattleTeam.Friendly ? friendlyArmor : enemyArmor;
            var horse = new GameObject("Zırhlı Sipahi");
            horse.transform.SetParent(parent, false);
            horse.transform.localScale = Vector3.one * 0.78f;

            var body = Primitive(
                "At Gövdesi",
                PrimitiveType.Capsule,
                horse.transform,
                new Vector3(0f, 0.78f, 0f),
                new Vector3(0.62f, 0.88f, 0.62f),
                leather);
            body.transform.localRotation = Quaternion.Euler(0f, 0f, 90f);
            Primitive(
                "At Boynu",
                PrimitiveType.Capsule,
                horse.transform,
                new Vector3(0.56f, 1.08f, 0f),
                new Vector3(0.36f, 0.58f, 0.36f),
                leather).transform.localRotation = Quaternion.Euler(0f, 0f, -28f);
            Primitive(
                "At Başı",
                PrimitiveType.Capsule,
                horse.transform,
                new Vector3(0.82f, 1.34f, 0f),
                new Vector3(0.3f, 0.42f, 0.3f),
                leather).transform.localRotation = Quaternion.Euler(0f, 0f, 70f);
            Primitive(
                "At Yelesi",
                PrimitiveType.Cube,
                horse.transform,
                new Vector3(0.48f, 1.25f, 0f),
                new Vector3(0.58f, 0.46f, 0.10f),
                obsidian).transform.localRotation = Quaternion.Euler(0f, 0f, -28f);
            Primitive(
                "At Kuyruğu",
                PrimitiveType.Capsule,
                horse.transform,
                new Vector3(-0.78f, 0.80f, 0f),
                new Vector3(0.16f, 0.58f, 0.16f),
                obsidian).transform.localRotation = Quaternion.Euler(0f, 0f, 52f);
            foreach (var eyeZ in new[] { -0.19f, 0.19f })
            {
                Primitive(
                    "At Gözü",
                    PrimitiveType.Sphere,
                    horse.transform,
                    new Vector3(1.02f, 1.46f, eyeZ),
                    Vector3.one * 0.055f,
                    obsidian);
            }

            var legOffsets = new[]
            {
                new Vector3(-0.42f, 0.32f, -0.24f),
                new Vector3(-0.42f, 0.32f, 0.24f),
                new Vector3(0.42f, 0.32f, -0.24f),
                new Vector3(0.42f, 0.32f, 0.24f)
            };
            foreach (var offset in legOffsets)
            {
                Primitive(
                    "At Bacağı",
                    PrimitiveType.Cube,
                    horse.transform,
                    offset,
                    new Vector3(0.14f, 0.64f, 0.14f),
                    leather);
            }

            Primitive(
                "At Zırhı",
                PrimitiveType.Cube,
                horse.transform,
                new Vector3(0f, 1.02f, 0f),
                new Vector3(0.92f, 0.24f, 0.64f),
                primary);
            Primitive(
                "Sipahi Eyer Örtüsü",
                PrimitiveType.Cube,
                horse.transform,
                new Vector3(-0.08f, 1.18f, 0f),
                new Vector3(0.62f, 0.13f, 0.82f),
                team == BattleTeam.Friendly ? friendlyCloth : enemyCloth);
            Primitive(
                "At Alın Zırhı",
                PrimitiveType.Cube,
                horse.transform,
                new Vector3(0.93f, 1.43f, 0f),
                new Vector3(0.32f, 0.14f, 0.34f),
                iron).transform.localRotation = Quaternion.Euler(0f, 0f, -18f);

            var rider = new GameObject("Sipahi").transform;
            rider.SetParent(horse.transform, false);
            rider.localPosition = new Vector3(-0.1f, 1.02f, 0f);
            Primitive(
                "Sipahi Gövdesi",
                PrimitiveType.Capsule,
                rider,
                new Vector3(0f, 0.58f, 0f),
                new Vector3(0.46f, 0.62f, 0.4f),
                primary);
            Primitive(
                "Sipahi Başı",
                PrimitiveType.Sphere,
                rider,
                new Vector3(0f, 1.15f, 0f),
                new Vector3(0.31f, 0.32f, 0.31f),
                skin);
            Primitive(
                "Sipahi Miğferi",
                PrimitiveType.Sphere,
                rider,
                new Vector3(0f, 1.28f, 0f),
                new Vector3(0.36f, 0.24f, 0.36f),
                iron);
            Primitive(
                "Sipahi Pelerini",
                PrimitiveType.Cube,
                rider,
                new Vector3(-0.24f, 0.58f, 0f),
                new Vector3(0.08f, 0.74f, 0.62f),
                team == BattleTeam.Friendly ? friendlyCloth : enemyCloth);

            var spear = new GameObject("Mızrak Eli").transform;
            spear.SetParent(rider, false);
            spear.localPosition = new Vector3(0.15f, 0.7f, -0.34f);
            spear.localRotation = Quaternion.Euler(0f, 0f, -62f);
            Primitive(
                "Mızrak",
                PrimitiveType.Cylinder,
                spear,
                new Vector3(0f, 0.75f, 0f),
                new Vector3(0.045f, 1.5f, 0.045f),
                wood);
            Primitive(
                "Mızrak Ucu",
                PrimitiveType.Cylinder,
                spear,
                new Vector3(0f, 2.22f, 0f),
                new Vector3(0.11f, 0.19f, 0.11f),
                iron,
                4);
            weapons.Add(spear);
        }

        private void BuildCannon(
            Transform parent,
            BattleTeam team,
            ICollection<Transform> weapons)
        {
            var primary = team == BattleTeam.Friendly ? friendlyArmor : enemyArmor;
            var cannon = new GameObject("Ağır Kuşatma Topu");
            cannon.transform.SetParent(parent, false);
            cannon.transform.localScale = Vector3.one * 0.84f;

            Primitive(
                "Top Arabası",
                PrimitiveType.Cube,
                cannon.transform,
                new Vector3(0f, 0.46f, 0f),
                new Vector3(1.15f, 0.32f, 0.78f),
                wood);

            foreach (var z in new[] { -0.48f, 0.48f })
            {
                var wheel = Primitive(
                    "Demir Çemberli Teker",
                    PrimitiveType.Cylinder,
                    cannon.transform,
                    new Vector3(-0.05f, 0.42f, z),
                    new Vector3(0.62f, 0.13f, 0.62f),
                    wood,
                    12);
                wheel.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
                Primitive(
                    "Teker Göbeği",
                    PrimitiveType.Cylinder,
                    wheel.transform,
                    Vector3.zero,
                    new Vector3(0.24f, 1.15f, 0.24f),
                    iron,
                    12);
            }

            var barrelPivot = new GameObject("Top Namlusu Yatağı").transform;
            barrelPivot.SetParent(cannon.transform, false);
            barrelPivot.localPosition = new Vector3(0.2f, 0.88f, 0f);
            barrelPivot.localRotation = Quaternion.Euler(0f, 0f, -78f);
            Primitive(
                "Şahi Namlusu",
                PrimitiveType.Cylinder,
                barrelPivot,
                new Vector3(0f, 0.86f, 0f),
                new Vector3(0.25f, 0.9f, 0.25f),
                iron,
                16);
            Primitive(
                "Namlu Ağzı",
                PrimitiveType.Cylinder,
                barrelPivot,
                new Vector3(0f, 1.78f, 0f),
                new Vector3(0.34f, 0.13f, 0.34f),
                gold,
                16);
            weapons.Add(barrelPivot);

            Primitive(
                "Topçu Sancağı",
                PrimitiveType.Cube,
                cannon.transform,
                new Vector3(-0.52f, 1.32f, 0f),
                new Vector3(0.08f, 1.15f, 0.08f),
                primary);

            foreach (var z in new[] { -0.88f, 0.88f })
            {
                var crew = new GameObject("Şahi Topçusu");
                crew.transform.SetParent(cannon.transform, false);
                crew.transform.localPosition = new Vector3(-0.42f, 0f, z);
                crew.transform.localScale = Vector3.one * 0.68f;
                Primitive(
                    "Topçu Kaftanı",
                    PrimitiveType.Capsule,
                    crew.transform,
                    new Vector3(0f, 0.83f, 0f),
                    new Vector3(0.48f, 0.58f, 0.42f),
                    team == BattleTeam.Friendly ? friendlyCloth : enemyCloth);
                Primitive(
                    "Topçu Zırhı",
                    PrimitiveType.Cube,
                    crew.transform,
                    new Vector3(0.03f, 1.05f, 0f),
                    new Vector3(0.48f, 0.38f, 0.38f),
                    primary);
                Primitive(
                    "Topçu Başı",
                    PrimitiveType.Sphere,
                    crew.transform,
                    new Vector3(0f, 1.52f, 0f),
                    new Vector3(0.30f, 0.32f, 0.30f),
                    skin);
                Primitive(
                    "Topçu Miğferi",
                    PrimitiveType.Sphere,
                    crew.transform,
                    new Vector3(0f, 1.65f, 0f),
                    new Vector3(0.36f, 0.23f, 0.36f),
                    iron);
            }
        }

        private void BuildCommander(
            Transform parent,
            BattleTeam team,
            ICollection<Transform> weapons)
        {
            var commanderRoot = new GameObject("Karacahisar Kale Beyi");
            commanderRoot.transform.SetParent(parent, false);
            commanderRoot.transform.localScale = Vector3.one * 1.18f;
            BuildSoldier(
                commanderRoot.transform,
                team,
                Vector3.zero,
                true,
                false,
                weapons);

            Primitive(
                "Kale Beyi Altın Tacı",
                PrimitiveType.Cylinder,
                commanderRoot.transform,
                new Vector3(0f, 1.52f, 0f),
                new Vector3(0.34f, 0.11f, 0.34f),
                gold,
                8);
            Primitive(
                "Kale Beyi Sorgucu",
                PrimitiveType.Capsule,
                commanderRoot.transform,
                new Vector3(0f, 2.12f, 0f),
                new Vector3(0.12f, 0.42f, 0.12f),
                team == BattleTeam.Friendly ? friendlyArmor : enemyArmor)
                .transform.localRotation = Quaternion.Euler(0f, 0f, -16f);
            Primitive(
                "Komutan Pelerini",
                PrimitiveType.Cube,
                commanderRoot.transform,
                new Vector3(-0.20f, 0.93f, 0f),
                new Vector3(0.08f, 0.85f, 0.66f),
                team == BattleTeam.Friendly ? friendlyCloth : enemyCloth);

            var bannerPole = Primitive(
                "Kale Beyi Sancak Direği",
                PrimitiveType.Cylinder,
                commanderRoot.transform,
                new Vector3(-0.48f, 1.1f, 0.38f),
                new Vector3(0.045f, 1.35f, 0.045f),
                wood);
            bannerPole.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
            Primitive(
                "Kale Beyi Sancağı",
                PrimitiveType.Cube,
                commanderRoot.transform,
                new Vector3(-0.18f, 2.10f, 0.38f),
                new Vector3(0.66f, 0.48f, 0.06f),
                team == BattleTeam.Friendly ? friendlyArmor : enemyArmor);
        }

        private void UpdateActor(Actor actor, BattleUnit unit)
        {
            var desired = WorldPosition(unit);
            var delta = desired - actor.lastWorldPosition;
            actor.root.transform.position = Vector3.Lerp(
                actor.root.transform.position,
                desired,
                1f - Mathf.Exp(-Time.unscaledDeltaTime * 10f));

            var facingDirection = delta;
            if (simulation.TryGetUnit(unit.targetId, out var target) &&
                target.Alive)
            {
                facingDirection = WorldPosition(target) - desired;
            }

            if (unit.Alive && facingDirection.sqrMagnitude > 0.00001f)
            {
                var facing = Quaternion.LookRotation(
                    facingDirection.normalized,
                    Vector3.up) * Quaternion.Euler(0f, -90f, 0f);
                actor.root.transform.rotation = Quaternion.Slerp(
                    actor.root.transform.rotation,
                    facing,
                    1f - Mathf.Exp(-Time.unscaledDeltaTime * 8f));
            }

            var moving = delta.sqrMagnitude > 0.000002f;
            var attacking = unit.attackTimer >
                            Mathf.Max(0f, unit.attackDelay - 0.16f);
            var attackStarted =
                unit.attackTimer > actor.lastAttackTimer + unit.attackDelay * 0.55f;
            var tookDamage = unit.hp < actor.lastHealth - 0.05f;

            if (tookDamage && unit.Alive)
            {
                SpawnImpactEffect(actor.root.transform.position + Vector3.up * 1.05f);
                PlayActorAnimation(actor, "Hit", 0.30f, true);
            }

            if (unit.Alive)
            {
                var bob = moving
                    ? Mathf.Abs(Mathf.Sin(Time.unscaledTime * 10f + actor.phase)) * 0.09f
                    : Mathf.Sin(Time.unscaledTime * 2.2f + actor.phase) * 0.015f;
                var lunge = attacking
                    ? Mathf.Sin(Mathf.Clamp01(unit.attackTimer / unit.attackDelay) * Mathf.PI) * 0.16f
                    : 0f;
                actor.model.localPosition = new Vector3(lunge, bob, 0f);
                actor.model.localRotation = Quaternion.Slerp(
                    actor.model.localRotation,
                    Quaternion.identity,
                    1f - Mathf.Exp(-Time.unscaledDeltaTime * 9f));

                if (Time.unscaledTime >= actor.animationLockUntil)
                {
                    PlayActorAnimation(actor, moving ? "Run" : "Idle", 0f, false);
                }

                for (var index = 0; index < actor.weapons.Length; index += 1)
                {
                    var strike = attacking
                        ? Quaternion.Euler(0f, 0f, -58f)
                        : Quaternion.identity;
                    actor.weapons[index].localRotation = Quaternion.Slerp(
                        actor.weapons[index].localRotation,
                        actor.weaponRestRotations[index] * strike,
                        1f - Mathf.Exp(-Time.unscaledDeltaTime * 18f));
                }

                if (attackStarted)
                {
                    if (!tookDamage)
                    {
                        PlayActorAnimation(
                            actor,
                            unit.kind == BattleUnitKind.Archer
                                ? "AttackRanged"
                                : "AttackMelee",
                            unit.kind == BattleUnitKind.Archer ? 0.42f : 0.48f,
                            true);
                    }

                    SpawnAttackEffect(actor, unit);
                }

                if (moving && Time.unscaledTime >= actor.nextDustTime)
                {
                    actor.nextDustTime = Time.unscaledTime + 0.24f;
                    SpawnDustEffect(
                        actor.root.transform.position -
                        actor.root.transform.right * 0.18f);
                }
            }
            else if (!actor.fallen)
            {
                actor.fallen = true;
                PlayActorAnimation(actor, "Death", 999f, true);
                SpawnDeathEffect(actor.root.transform.position, unit.team);
            }

            if (actor.fallen)
            {
                if (actor.animators == null || actor.animators.Length == 0)
                {
                    actor.model.localRotation = Quaternion.Slerp(
                        actor.model.localRotation,
                        Quaternion.Euler(
                            0f,
                            0f,
                            unit.team == BattleTeam.Friendly ? -78f : 78f),
                        1f - Mathf.Exp(-Time.unscaledDeltaTime * 5f));
                }

                actor.model.localPosition = Vector3.Lerp(
                    actor.model.localPosition,
                    new Vector3(0f, -0.18f, 0f),
                    1f - Mathf.Exp(-Time.unscaledDeltaTime * 3f));
            }

            actor.lastWorldPosition = desired;
            actor.lastAttackTimer = unit.attackTimer;
            actor.lastHealth = unit.hp;
        }

        private static void PlayActorAnimation(
            Actor actor,
            string state,
            float lockSeconds,
            bool force)
        {
            if (actor.animators == null || actor.animators.Length == 0)
            {
                return;
            }

            if (!force && string.Equals(actor.animationState, state, StringComparison.Ordinal))
            {
                return;
            }

            var stateHash = Animator.StringToHash(state);
            var played = false;
            foreach (var animator in actor.animators)
            {
                if (animator == null ||
                    animator.runtimeAnimatorController == null ||
                    !animator.HasState(0, stateHash))
                {
                    continue;
                }

                animator.CrossFadeInFixedTime(stateHash, 0.08f, 0, 0f);
                played = true;
            }

            if (!played)
            {
                return;
            }

            actor.animationState = state;
            actor.animationLockUntil = Mathf.Max(
                actor.animationLockUntil,
                Time.unscaledTime + lockSeconds);
        }

        private void SpawnImpactEffect(Vector3 position)
        {
            cameraShake = Mathf.Max(cameraShake, 0.08f);
            for (var index = 0; index < 3; index += 1)
            {
                var spark = Primitive(
                    "Zırh Çarpışma Kıvılcımı",
                    PrimitiveType.Cube,
                    worldRoot.transform,
                    position + UnityEngine.Random.insideUnitSphere * 0.12f,
                    new Vector3(0.035f, 0.16f, 0.035f),
                    healthFlash);
                spark.transform.rotation = UnityEngine.Random.rotation;
                effects.Add(new TimedEffect
                {
                    root = spark,
                    baseScale = spark.transform.localScale,
                    velocity = new Vector3(
                        UnityEngine.Random.Range(-1.4f, 1.4f),
                        UnityEngine.Random.Range(1.1f, 2.2f),
                        UnityEngine.Random.Range(-1.4f, 1.4f)),
                    life = 0.24f,
                    duration = 0.24f,
                    spin = UnityEngine.Random.Range(-520f, 520f)
                });
            }
        }

        private void SpawnDustEffect(Vector3 position)
        {
            var cloud = Primitive(
                "Yürüyüş Tozu",
                PrimitiveType.Sphere,
                worldRoot.transform,
                position + new Vector3(-0.18f, 0.08f, 0f),
                new Vector3(0.34f, 0.12f, 0.28f),
                dust);
            effects.Add(new TimedEffect
            {
                root = cloud,
                baseScale = cloud.transform.localScale,
                velocity = new Vector3(-0.12f, 0.32f, 0f),
                life = 0.42f,
                duration = 0.42f,
                expanding = true
            });
        }

        private void SpawnDeathEffect(Vector3 position, BattleTeam team)
        {
            cameraShake = Mathf.Max(cameraShake, 0.11f);
            var ring = Primitive(
                "Yere Düşüş Dalgası",
                PrimitiveType.Cylinder,
                worldRoot.transform,
                position + Vector3.up * 0.05f,
                new Vector3(0.52f, 0.025f, 0.52f),
                team == BattleTeam.Friendly ? friendlyArmor : enemyArmor,
                16);
            effects.Add(new TimedEffect
            {
                root = ring,
                baseScale = ring.transform.localScale,
                velocity = Vector3.up * 0.08f,
                life = 0.56f,
                duration = 0.56f,
                expanding = true
            });
        }

        private void SpawnAttackEffect(Actor actor, BattleUnit unit)
        {
            CihanAudioDirector.Instance?.PlayAttack(unit.kind);
            var direction = actor.root.transform.right;
            if (simulation.TryGetUnit(unit.targetId, out var target) &&
                target.Alive)
            {
                direction = (
                    WorldPosition(target) -
                    actor.root.transform.position).normalized;
            }

            var isProjectile =
                unit.kind == BattleUnitKind.Archer ||
                unit.kind == BattleUnitKind.Siege;
            var effect = Primitive(
                isProjectile ? "Mermi İzi" : "Kılıç Parıltısı",
                isProjectile ? PrimitiveType.Sphere : PrimitiveType.Cube,
                worldRoot.transform,
                actor.root.transform.position + Vector3.up * 1.05f + direction * 0.4f,
                isProjectile
                    ? new Vector3(0.14f, 0.14f, 0.14f)
                    : new Vector3(0.06f, 0.55f, 0.11f),
                unit.kind == BattleUnitKind.Siege ? obsidian : healthFlash);
            effect.transform.rotation = actor.root.transform.rotation;
            effects.Add(new TimedEffect
            {
                root = effect,
                baseScale = effect.transform.localScale,
                velocity = direction *
                           (unit.kind == BattleUnitKind.Siege ? 9.5f : 6.5f) +
                           Vector3.up * (unit.kind == BattleUnitKind.Siege ? 1.2f : 0.25f),
                life = isProjectile ? 0.56f : 0.18f,
                duration = isProjectile ? 0.56f : 0.18f,
                spin = isProjectile ? 240f : 680f
            });

            if (unit.kind == BattleUnitKind.Siege)
            {
                cameraShake = Mathf.Max(cameraShake, 0.36f);
                SpawnCannonBlast(
                    actor.root.transform.position + Vector3.up * 1.05f + direction * 0.62f);
            }
        }

        private void SpawnCannonBlast(Vector3 position)
        {
            var flash = Primitive(
                "Şahi Namlu Alevi",
                PrimitiveType.Sphere,
                worldRoot.transform,
                position,
                new Vector3(0.34f, 0.34f, 0.34f),
                fire);
            effects.Add(new TimedEffect
            {
                root = flash,
                baseScale = flash.transform.localScale,
                velocity = Vector3.up * 0.15f,
                life = 0.22f,
                duration = 0.22f,
                expanding = true,
                spin = 420f
            });

            for (var index = 0; index < 3; index += 1)
            {
                var cloud = Primitive(
                    "Şahi Barut Dumanı",
                    PrimitiveType.Sphere,
                    worldRoot.transform,
                    position + UnityEngine.Random.insideUnitSphere * 0.13f,
                    Vector3.one * UnityEngine.Random.Range(0.24f, 0.40f),
                    smoke);
                effects.Add(new TimedEffect
                {
                    root = cloud,
                    baseScale = cloud.transform.localScale,
                    velocity = new Vector3(
                        UnityEngine.Random.Range(-0.3f, 0.3f),
                        UnityEngine.Random.Range(0.45f, 0.75f),
                        UnityEngine.Random.Range(-0.3f, 0.3f)),
                    life = 0.72f,
                    duration = 0.72f,
                    expanding = true
                });
            }
        }

        private void PlayCommandEffect(BattleCommand command)
        {
            CihanAudioDirector.Instance?.PlayCommand(command);
            switch (command)
            {
                case BattleCommand.Charge:
                    cameraShake = 0.28f;
                    SpawnArmyPulse(
                        BattleTeam.Friendly,
                        gold,
                        "Hücum Parıltısı",
                        0.55f);
                    break;
                case BattleCommand.ShieldWall:
                    SpawnArmyPulse(
                        BattleTeam.Friendly,
                        friendlyArmor,
                        "Kalkan Duvarı Parıltısı",
                        0.82f);
                    break;
                case BattleCommand.ArrowVolley:
                    cameraShake = 0.40f;
                    SpawnArrowVolley(BattleTeam.Friendly);
                    break;
                case BattleCommand.CannonBarrage:
                    cameraShake = 0.68f;
                    foreach (var unit in simulation.Units.Where(item =>
                                 item.team == BattleTeam.Friendly &&
                                 item.kind == BattleUnitKind.Siege &&
                                 item.Alive))
                    {
                        if (actors.TryGetValue(unit.id, out var cannon))
                        {
                            SpawnCannonBlast(
                                cannon.root.transform.position +
                                cannon.root.transform.right * 0.9f +
                                Vector3.up * 1.05f);
                        }
                    }

                    SpawnArmyPulse(
                        BattleTeam.Friendly,
                        fire,
                        "Şahi Ateşi Dalgası",
                        0.70f);
                    break;
                case BattleCommand.Rally:
                    cameraShake = 0.18f;
                    SpawnArmyPulse(
                        BattleTeam.Friendly,
                        gold,
                        "Cihat Narası Parıltısı",
                        1.05f);
                    break;
                case BattleCommand.EnemyReinforcement:
                    cameraShake = 0.24f;
                    SpawnArmyPulse(
                        BattleTeam.Enemy,
                        enemyArmor,
                        "Düşman Takviye Alarmı",
                        0.65f);
                    break;
                case BattleCommand.EnemyShieldWall:
                    SpawnArmyPulse(
                        BattleTeam.Enemy,
                        enemyArmor,
                        "Düşman Kalkan Duvarı",
                        0.82f);
                    break;
                case BattleCommand.EnemyArrowVolley:
                    cameraShake = 0.36f;
                    SpawnArrowVolley(BattleTeam.Enemy);
                    break;
                case BattleCommand.EnemyCharge:
                    cameraShake = 0.30f;
                    SpawnArmyPulse(
                        BattleTeam.Enemy,
                        healthFlash,
                        "Düşman Hücum Alarmı",
                        0.58f);
                    break;
            }
        }

        private void SpawnArmyPulse(
            BattleTeam team,
            Material material,
            string effectName,
            float duration)
        {
            foreach (var unit in simulation.Units.Where(item =>
                         item.team == team && item.Alive))
            {
                if (!actors.TryGetValue(unit.id, out var actor))
                {
                    continue;
                }

                var pulse = Primitive(
                    effectName,
                    PrimitiveType.Cylinder,
                    worldRoot.transform,
                    actor.root.transform.position + Vector3.up * 0.08f,
                    new Vector3(0.72f, 0.025f, 0.72f),
                    material,
                    16);
                effects.Add(new TimedEffect
                {
                    root = pulse,
                    baseScale = pulse.transform.localScale,
                    velocity = Vector3.up * 0.22f,
                    life = duration,
                    duration = duration,
                    expanding = true
                });
            }
        }

        private void SpawnArrowVolley(BattleTeam sourceTeam)
        {
            var targetTeam = sourceTeam == BattleTeam.Friendly
                ? BattleTeam.Enemy
                : BattleTeam.Friendly;
            var archers = simulation.Units
                .Where(item =>
                    item.team == sourceTeam &&
                    item.kind == BattleUnitKind.Archer &&
                    item.Alive)
                .Take(6)
                .ToArray();
            var targets = simulation.Units
                .Where(item => item.team == targetTeam && item.Alive)
                .OrderBy(item => sourceTeam == BattleTeam.Friendly ? item.x : -item.x)
                .Take(6)
                .ToArray();
            if (archers.Length == 0 || targets.Length == 0)
            {
                return;
            }

            for (var index = 0; index < targets.Length; index += 1)
            {
                var archer = archers[index % archers.Length];
                var start = WorldPosition(archer) + Vector3.up * 1.45f;
                var destination = WorldPosition(targets[index]) + Vector3.up * 0.9f;
                var direction = (destination - start).normalized;
                var arrow = Primitive(
                    "Ok Yağmuru",
                    PrimitiveType.Cube,
                    worldRoot.transform,
                    start,
                    new Vector3(0.035f, 0.035f, 0.7f),
                    wood);
                arrow.transform.rotation = Quaternion.LookRotation(direction);
                effects.Add(new TimedEffect
                {
                    root = arrow,
                    baseScale = arrow.transform.localScale,
                    velocity = direction * 12f + Vector3.up * 2.5f,
                    life = 0.62f,
                    duration = 0.62f,
                    spin = 90f
                });
            }
        }

        private void UpdateEffects(float deltaTime)
        {
            for (var index = effects.Count - 1; index >= 0; index -= 1)
            {
                var effect = effects[index];
                effect.life -= deltaTime;
                if (effect.life <= 0f)
                {
                    if (effect.root != null)
                    {
                        Destroy(effect.root);
                    }

                    effects.RemoveAt(index);
                    continue;
                }

                effect.root.transform.position += effect.velocity * deltaTime;
                effect.velocity += Vector3.down * 3.5f * deltaTime;
                var ratio = Mathf.Clamp01(effect.life / effect.duration);
                if (effect.baseScale == Vector3.zero)
                {
                    effect.baseScale = effect.root.transform.localScale;
                }

                var progress = 1f - ratio;
                var scale = effect.expanding
                    ? Mathf.Lerp(0.72f, 1.72f, progress)
                    : Mathf.Lerp(1f, 0.48f, progress);
                effect.root.transform.localScale = effect.baseScale * scale;
                if (Mathf.Abs(effect.spin) > 0.01f)
                {
                    effect.root.transform.Rotate(
                        effect.spin * deltaTime,
                        effect.spin * 0.35f * deltaTime,
                        0f,
                        Space.Self);
                }
            }
        }

        private static Vector3 WorldPosition(BattleUnit unit)
        {
            return new Vector3(
                (unit.x - 0.5f) * 17.2f,
                0.06f,
                (unit.y - 0.5f) * 10.6f);
        }

        private Material CreateMaterial(Color color, float metallic, float smoothness)
        {
            var shader = Shader.Find("Standard");
            if (shader == null)
            {
                shader = Shader.Find("Mobile/Diffuse");
            }

            var material = new Material(shader)
            {
                color = color
            };
            if (material.HasProperty("_Metallic"))
            {
                material.SetFloat("_Metallic", metallic);
            }

            if (material.HasProperty("_Glossiness"))
            {
                material.SetFloat("_Glossiness", smoothness);
            }

            materials.Add(material);
            return material;
        }

        private static GameObject Primitive(
            string name,
            PrimitiveType type,
            Transform parent,
            Vector3 localPosition,
            Vector3 localScale,
            Material material,
            int ignoredSides = 0)
        {
            var value = GameObject.CreatePrimitive(type);
            value.name = name;
            value.transform.SetParent(parent, false);
            value.transform.localPosition = localPosition;
            value.transform.localScale = localScale;
            var collider = value.GetComponent<Collider>();
            if (collider != null)
            {
                Destroy(collider);
            }

            var renderer = value.GetComponent<MeshRenderer>();
            renderer.sharedMaterial = material;
            renderer.shadowCastingMode = ShadowCastingMode.On;
            renderer.receiveShadows = true;
            return value;
        }

        private static string TeamName(BattleTeam team)
        {
            return team == BattleTeam.Friendly ? "CİHAN" : "HİSAR";
        }

        private static string KindName(BattleUnitKind kind)
        {
            return kind switch
            {
                BattleUnitKind.Infantry => "Piyade",
                BattleUnitKind.Archer => "Okçu",
                BattleUnitKind.Cavalry => "Süvari",
                BattleUnitKind.Siege => "Şahi Topu",
                BattleUnitKind.Commander => "Kale Beyi",
                _ => "Birlik"
            };
        }

        private void OnDestroy()
        {
            if (worldRoot != null)
            {
                Destroy(worldRoot);
            }

            foreach (var material in materials)
            {
                if (material != null)
                {
                    Destroy(material);
                }
            }

            foreach (var texture in textures)
            {
                if (texture != null)
                {
                    Destroy(texture);
                }
            }
        }
    }
}
