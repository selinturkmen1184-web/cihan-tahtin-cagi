using System;
using System.Collections;
using System.IO;
using Cihan.Domain;
using UnityEngine;
using UnityEngine.Networking;

namespace Cihan.Services
{
    [Serializable]
    public sealed class CihanCloudSnapshot
    {
        public string playerId;
        public string gameVersion;
        public double savedAt;
        public int power;
        public int victories;
        public int campaignProgress;
        public int glory;
    }

    public sealed class CihanCloudGateway : MonoBehaviour
    {
        private const string EndpointKey = "cihan.cloud.endpoint";
        private const string PlayerIdKey = "cihan.cloud.playerId";
        private const string OutboxFile = "cihan-cloud-outbox.json";

        public static CihanCloudGateway Instance { get; private set; }
        public string StatusText { get; private set; } = "ÇEVRİMDIŞI KAYIT KORUMASI";

        private bool syncing;
        private double nextQueueAt;

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(this);
                return;
            }

            Instance = this;
            EnsurePlayerId();
        }

        public void QueueProfile(GameState state, bool immediate = false)
        {
            if (state == null || (!immediate && GameService.Now < nextQueueAt))
            {
                return;
            }

            nextQueueAt = GameService.Now + 15d;
            var snapshot = new CihanCloudSnapshot
            {
                playerId = PlayerPrefs.GetString(PlayerIdKey),
                gameVersion = Application.version,
                savedAt = GameService.Now,
                power = state.Power,
                victories = state.victories,
                campaignProgress = state.campaignProgress,
                glory = state.seasonPoints
            };
            var json = JsonUtility.ToJson(snapshot, true);
            File.WriteAllText(OutboxPath, json);

            var endpoint = PlayerPrefs.GetString(EndpointKey, string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(endpoint))
            {
                StatusText = "ÇEVRİMDIŞI KAYIT KORUMASI";
                return;
            }

            if (!syncing)
            {
                StartCoroutine(Push(endpoint, json));
            }
        }

        public void ConfigureEndpoint(string endpoint)
        {
            PlayerPrefs.SetString(EndpointKey, endpoint?.Trim() ?? string.Empty);
            PlayerPrefs.Save();
            StatusText = string.IsNullOrWhiteSpace(endpoint)
                ? "ÇEVRİMDIŞI KAYIT KORUMASI"
                : "SUNUCU BAĞLANTISI HAZIR";
        }

        private IEnumerator Push(string endpoint, string json)
        {
            syncing = true;
            StatusText = "SUNUCUYLA EŞİTLENİYOR";
            using var request = new UnityWebRequest(endpoint, UnityWebRequest.kHttpVerbPOST);
            request.uploadHandler = new UploadHandlerRaw(System.Text.Encoding.UTF8.GetBytes(json));
            request.downloadHandler = new DownloadHandlerBuffer();
            request.timeout = 8;
            request.SetRequestHeader("Content-Type", "application/json");
            yield return request.SendWebRequest();

            if (request.result == UnityWebRequest.Result.Success)
            {
                StatusText = "SUNUCU KAYDI GÜNCEL";
                if (File.Exists(OutboxPath))
                {
                    File.Delete(OutboxPath);
                }
            }
            else
            {
                StatusText = "AĞ YOK · KAYIT TELEFONDA KORUNUYOR";
            }

            syncing = false;
        }

        private static void EnsurePlayerId()
        {
            if (!string.IsNullOrWhiteSpace(PlayerPrefs.GetString(PlayerIdKey, string.Empty)))
            {
                return;
            }

            PlayerPrefs.SetString(PlayerIdKey, Guid.NewGuid().ToString("N"));
            PlayerPrefs.Save();
        }

        private static string OutboxPath =>
            Path.Combine(Application.persistentDataPath, OutboxFile);
    }
}
