using System;
using Cihan.Battle;
using UnityEngine;

namespace Cihan.Services
{
    public sealed class CihanAudioDirector : MonoBehaviour
    {
        private const int SampleRate = 24000;

        public static CihanAudioDirector Instance { get; private set; }

        private AudioSource ambience;
        private AudioSource effects;
        private AudioClip uiConfirm;
        private AudioClip swordClash;
        private AudioClip arrowFlight;
        private AudioClip cannonBlast;
        private AudioClip commandHorn;
        private AudioClip victoryFanfare;
        private AudioClip defeatSignal;
        private float nextLightEffectTime;
        private float nextHeavyEffectTime;

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(this);
                return;
            }

            Instance = this;
            BuildSources();
            BuildClips();
            ambience.clip = BuildWarDrumLoop();
            ambience.loop = true;
            ambience.volume = 0.12f;
            ambience.Play();
        }

        public void EnterBattle()
        {
            ambience.volume = 0.26f;
            effects.PlayOneShot(commandHorn, 0.55f);
        }

        public void LeaveBattle()
        {
            ambience.volume = 0.12f;
        }

        public void PlayUiConfirm()
        {
            effects.PlayOneShot(uiConfirm, 0.32f);
        }

        public void PlayCommand(BattleCommand command)
        {
            var volume = command == BattleCommand.CannonBarrage ? 0.82f : 0.48f;
            effects.PlayOneShot(commandHorn, volume);
        }

        public void PlayAttack(BattleUnitKind kind)
        {
            if (kind == BattleUnitKind.Siege)
            {
                if (Time.unscaledTime < nextHeavyEffectTime)
                {
                    return;
                }

                nextHeavyEffectTime = Time.unscaledTime + 0.42f;
                effects.PlayOneShot(cannonBlast, 0.82f);
                return;
            }

            if (Time.unscaledTime < nextLightEffectTime)
            {
                return;
            }

            nextLightEffectTime = Time.unscaledTime + 0.10f;
            effects.PlayOneShot(
                kind == BattleUnitKind.Archer ? arrowFlight : swordClash,
                kind == BattleUnitKind.Archer ? 0.24f : 0.30f);
        }

        public void PlayOutcome(bool victory)
        {
            effects.PlayOneShot(victory ? victoryFanfare : defeatSignal, 0.68f);
        }

        private void BuildSources()
        {
            ambience = gameObject.AddComponent<AudioSource>();
            ambience.playOnAwake = false;
            ambience.spatialBlend = 0f;
            ambience.ignoreListenerPause = true;

            effects = gameObject.AddComponent<AudioSource>();
            effects.playOnAwake = false;
            effects.spatialBlend = 0f;
            effects.ignoreListenerPause = true;
            effects.volume = 0.9f;
        }

        private void BuildClips()
        {
            var random = new System.Random(1453);
            uiConfirm = CreateClip("Divan Mührü", 0.16f, (time, index) =>
                Mathf.Sin(time * Mathf.PI * 2f * 680f) *
                Mathf.Exp(-time * 20f) * 0.45f);
            swordClash = CreateClip("Kılıç Çarpışması", 0.28f, (time, index) =>
            {
                var noise = (float)(random.NextDouble() * 2d - 1d);
                var ring = Mathf.Sin(time * Mathf.PI * 2f * (1040f - time * 900f));
                return (ring * 0.45f + noise * 0.22f) * Mathf.Exp(-time * 12f);
            });
            arrowFlight = CreateClip("Ok Uçuşu", 0.34f, (time, index) =>
            {
                var noise = (float)(random.NextDouble() * 2d - 1d);
                var whistle = Mathf.Sin(time * Mathf.PI * 2f * (1450f + time * 1100f));
                return (noise * 0.14f + whistle * 0.16f) *
                       Mathf.Sin(Mathf.Clamp01(time / 0.34f) * Mathf.PI);
            });
            cannonBlast = CreateClip("Şahi Topu", 1.05f, (time, index) =>
            {
                var noise = (float)(random.NextDouble() * 2d - 1d);
                var boom = Mathf.Sin(time * Mathf.PI * 2f * (62f - time * 18f));
                return (boom * 0.72f + noise * 0.34f) * Mathf.Exp(-time * 3.7f);
            });
            commandHorn = CreateClip("Hücum Borusu", 1.20f, (time, index) =>
            {
                var note = time < 0.52f ? 293.66f : 392f;
                var envelope = Mathf.Sin(Mathf.Clamp01(time / 1.2f) * Mathf.PI);
                return (
                    Mathf.Sin(time * Mathf.PI * 2f * note) * 0.42f +
                    Mathf.Sin(time * Mathf.PI * 2f * note * 2f) * 0.10f) *
                       envelope;
            });
            victoryFanfare = CreateClip("Zafer Fanfari", 1.85f, (time, index) =>
            {
                var noteIndex = Mathf.Min(3, Mathf.FloorToInt(time / 0.42f));
                var notes = new[] { 293.66f, 369.99f, 440f, 587.33f };
                var local = time - noteIndex * 0.42f;
                return Mathf.Sin(time * Mathf.PI * 2f * notes[noteIndex]) *
                       Mathf.Exp(-local * 1.8f) * 0.38f;
            });
            defeatSignal = CreateClip("Geri Çekilme Borusu", 1.45f, (time, index) =>
            {
                var note = time < 0.7f ? 246.94f : 196f;
                return Mathf.Sin(time * Mathf.PI * 2f * note) *
                       Mathf.Sin(Mathf.Clamp01(time / 1.45f) * Mathf.PI) * 0.32f;
            });
        }

        private static AudioClip BuildWarDrumLoop()
        {
            var random = new System.Random(1299);
            return CreateClip("Sefer Davulları", 6f, (time, index) =>
            {
                var beat = time % 0.75f;
                var drum = Mathf.Sin(beat * Mathf.PI * 2f * (74f - beat * 38f)) *
                           Mathf.Exp(-beat * 13f);
                var marchingPulse = Mathf.Sin(time * Mathf.PI * 2f * 1.3333f) * 0.035f;
                var dustNoise = (float)(random.NextDouble() * 2d - 1d) *
                                Mathf.Exp(-beat * 18f) * 0.05f;
                return drum * 0.42f + marchingPulse + dustNoise;
            });
        }

        private static AudioClip CreateClip(
            string name,
            float duration,
            Func<float, int, float> sample)
        {
            var sampleCount = Mathf.CeilToInt(duration * SampleRate);
            var data = new float[sampleCount];
            for (var index = 0; index < sampleCount; index += 1)
            {
                data[index] = Mathf.Clamp(sample(index / (float)SampleRate, index), -1f, 1f);
            }

            var clip = AudioClip.Create(name, sampleCount, 1, SampleRate, false);
            clip.SetData(data, 0);
            return clip;
        }
    }
}
