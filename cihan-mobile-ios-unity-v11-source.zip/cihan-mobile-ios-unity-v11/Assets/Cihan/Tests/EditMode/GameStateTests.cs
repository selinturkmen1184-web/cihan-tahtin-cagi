using System.Linq;
using Cihan.Battle;
using Cihan.Domain;
using NUnit.Framework;

namespace Cihan.Tests
{
    public sealed class GameStateTests
    {
        [Test]
        public void ResourcesContinueProducingWhileTimeAdvances()
        {
            const double now = 1000d;
            var state = GameState.CreateNew(now);
            var initialFood = state.food;
            var initialWood = state.wood;

            state.Advance(now + 60d);

            Assert.That(state.food, Is.GreaterThan(initialFood));
            Assert.That(state.wood, Is.GreaterThan(initialWood));
        }

        [Test]
        public void BuildingUpgradeSpendsResourcesAndCompletes()
        {
            const double now = 2000d;
            var state = GameState.CreateNew(now);
            var initialLevel = state.GetBuilding("farm").level;
            var initialWood = state.wood;

            Assert.That(state.BeginUpgrade("farm", now), Is.True);
            Assert.That(state.wood, Is.LessThan(initialWood));
            Assert.That(state.construction, Is.Not.Null);

            state.Advance(now + 120d);

            Assert.That(state.GetBuilding("farm").level, Is.EqualTo(initialLevel + 1));
            Assert.That(state.construction, Is.Null);
        }

        [Test]
        public void TrainedUnitsJoinTheArmy()
        {
            const double now = 3000d;
            var state = GameState.CreateNew(now);
            var initialCount = state.GetUnit("infantry").count;
            var expectedBatch = GameRules.TrainingBatch(
                GameRules.Units.First(item => item.id == "infantry"),
                state.GetBuilding("barracks").level);

            Assert.That(state.BeginTraining("infantry", now), Is.True);
            state.Advance(now + 120d);

            Assert.That(
                state.GetUnit("infantry").count,
                Is.EqualTo(initialCount + expectedBatch));
            Assert.That(state.training, Is.Null);
        }

        [Test]
        public void BarracksLevelUnlocksAdvancedUnits()
        {
            const double now = 3500d;
            var state = GameState.CreateNew(now);

            Assert.That(state.GetBuilding("barracks").level, Is.EqualTo(2));
            Assert.That(state.BeginTraining("cavalry", now), Is.False);
            Assert.That(state.BeginTraining("siege", now), Is.False);
        }

        [Test]
        public void PalaceLevelLimitsOtherBuildings()
        {
            const double now = 3750d;
            var state = GameState.CreateNew(now);
            state.GetBuilding("farm").level = state.GetBuilding("palace").level;

            Assert.That(state.BeginUpgrade("farm", now), Is.False);
            Assert.That(state.BeginUpgrade("palace", now), Is.True);
        }

        [Test]
        public void ExpeditionReturnsWithRewards()
        {
            const double now = 4000d;
            var state = GameState.CreateNew(now);
            var initialGold = state.gold;

            Assert.That(state.BeginExpedition(now), Is.True);
            state.Advance(now + 120d);

            Assert.That(state.victories, Is.EqualTo(1));
            Assert.That(state.gold, Is.GreaterThan(initialGold));
            Assert.That(state.expedition, Is.Null);
        }

        [Test]
        public void HeroAssignmentIsLimitedToTwoCommanders()
        {
            var state = GameState.CreateNew(5000d);

            Assert.That(state.ToggleHeroAssignment("leyla"), Is.False);
            Assert.That(state.ToggleHeroAssignment("nizam"), Is.True);
            Assert.That(state.ToggleHeroAssignment("leyla"), Is.True);
            Assert.That(
                state.heroes.Count(item => item.assigned),
                Is.EqualTo(2));
        }

        [Test]
        public void LiveBattleMovesArmiesIntoCombatAndFinishes()
        {
            var state = GameState.CreateNew(6000d);
            var battle = BattleSimulation.Create(state);
            Assert.That(
                battle.ApplyFormation(BattleFormation.Crescent),
                Is.True);

            for (var step = 0; step < 4000 && !battle.IsFinished; step += 1)
            {
                battle.Step(0.02f);
            }

            Assert.That(battle.Clashes, Is.GreaterThan(0));
            Assert.That(battle.IsFinished, Is.True);
            Assert.That(
                battle.FriendlyKills + battle.FriendlyCasualties,
                Is.GreaterThan(0));
        }

        [Test]
        public void CommanderCanIssueTacticalOrdersWithCooldowns()
        {
            var state = GameState.CreateNew(6500d);
            var battle = BattleSimulation.Create(state);
            var initialMorale = battle.FriendlyMorale;

            Assert.That(
                battle.ApplyFormation(BattleFormation.LightningRaid),
                Is.True);
            Assert.That(battle.IssueCharge(), Is.True);
            Assert.That(battle.IssueCharge(), Is.False);
            Assert.That(battle.ChargeSeconds, Is.GreaterThan(0f));
            Assert.That(battle.ChargeCooldown, Is.GreaterThan(0f));
            Assert.That(battle.FriendlyMorale, Is.GreaterThan(initialMorale));

            Assert.That(battle.RaiseShieldWall(), Is.True);
            Assert.That(battle.LaunchArrowVolley(), Is.True);
            Assert.That(battle.CommandRevision, Is.EqualTo(3));
        }

        [Test]
        public void EnemyReinforcementsEnterAfterOpeningClash()
        {
            var state = GameState.CreateNew(7000d);
            var battle = BattleSimulation.Create(state);
            var initialEnemyCount = battle.EnemyAlive;
            Assert.That(
                battle.ApplyFormation(BattleFormation.ShieldWall),
                Is.True);

            for (var step = 0;
                 step < 1000 &&
                 !battle.EnemyReinforcementsDeployed &&
                 !battle.IsFinished;
                 step += 1)
            {
                battle.Step(0.05f);
            }

            Assert.That(battle.EnemyReinforcementsDeployed, Is.True);
            Assert.That(battle.Units.Count, Is.GreaterThan(initialEnemyCount));
        }

        [Test]
        public void FormationAndRallyAlterTheBattlePlan()
        {
            var state = GameState.CreateNew(7500d);
            var battle = BattleSimulation.Create(state);
            var initialInfantryHealth = battle.Units
                .First(item =>
                    item.team == BattleTeam.Friendly &&
                    item.kind == BattleUnitKind.Infantry)
                .maxHp;

            Assert.That(
                battle.ApplyFormation(BattleFormation.ShieldWall),
                Is.True);
            Assert.That(
                battle.Units.First(item =>
                        item.team == BattleTeam.Friendly &&
                        item.kind == BattleUnitKind.Infantry)
                    .maxHp,
                Is.GreaterThan(initialInfantryHealth));
            Assert.That(battle.ApplyFormation(BattleFormation.Crescent), Is.False);

            var moraleBeforeRally = battle.FriendlyMorale;
            Assert.That(battle.RallyTheArmy(), Is.True);
            Assert.That(battle.RallyTheArmy(), Is.False);
            Assert.That(battle.FriendlyMorale, Is.GreaterThan(moraleBeforeRally));
        }

        [Test]
        public void CampaignVictoryUnlocksNextFrontAndKeepsBestStars()
        {
            var state = GameState.CreateNew(8000d);
            var initialFood = state.food;

            Assert.That(state.CanLaunchCampaign(0), Is.True);
            Assert.That(state.CanLaunchCampaign(1), Is.False);
            Assert.That(state.BeginCampaignBattle(0), Is.True);
            Assert.That(state.food, Is.LessThan(initialFood));

            state.ApplyBattleResult(
                true,
                2,
                18,
                GameRules.Campaign[0].id,
                3);

            Assert.That(state.campaignProgress, Is.EqualTo(1));
            Assert.That(state.CampaignStars(0), Is.EqualTo(3));
            Assert.That(state.CanLaunchCampaign(1), Is.True);

            state.ApplyBattleResult(
                true,
                8,
                12,
                GameRules.Campaign[0].id,
                1);

            Assert.That(state.CampaignStars(0), Is.EqualTo(3));
        }

        [Test]
        public void CompletedFetihOrderCanOnlyBeClaimedOnce()
        {
            var state = GameState.CreateNew(8500d);
            state.campaignProgress = 1;
            var initialGold = state.gold;

            Assert.That(state.IsMissionComplete(2), Is.True);
            Assert.That(state.ClaimMissionReward(2), Is.True);
            Assert.That(state.gold, Is.GreaterThan(initialGold));
            Assert.That(state.ClaimMissionReward(2), Is.False);
        }

        [Test]
        public void ShahiBarrageDamagesEnemyAndStartsCooldown()
        {
            var state = GameState.CreateNew(9000d);
            var battle = BattleSimulation.Create(state);
            Assert.That(battle.ApplyFormation(BattleFormation.Crescent), Is.True);
            var initialHealth = battle.Units
                .Where(item => item.team == BattleTeam.Enemy)
                .Sum(item => item.hp);

            Assert.That(battle.LaunchCannonBarrage(), Is.True);

            Assert.That(
                battle.Units.Where(item => item.team == BattleTeam.Enemy).Sum(item => item.hp),
                Is.LessThan(initialHealth));
            Assert.That(battle.CannonBarrageCooldown, Is.GreaterThan(0f));
            Assert.That(battle.LaunchCannonBarrage(), Is.False);
        }

        [Test]
        public void DailyDivanOrderCanBeCompletedAndClaimedOnce()
        {
            const double now = 10000d;
            var state = GameState.CreateNew(now);
            state.EnsureDailyOrder(now);
            state.dailyOrderIndex = 2;
            var initialGold = state.gold;

            state.ApplyBattleResult(false, 2, 4);

            Assert.That(state.IsDailyOrderComplete(), Is.True);
            Assert.That(state.ClaimDailyOrderReward(now), Is.True);
            Assert.That(state.gold, Is.GreaterThan(initialGold));
            Assert.That(state.ClaimDailyOrderReward(now), Is.False);
        }
    }
}
