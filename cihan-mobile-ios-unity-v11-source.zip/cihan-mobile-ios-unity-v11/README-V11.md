# CİHAN: Tahtın Çağı — Unity V11

Unity 6000.0 ile hazırlanmış Android ve iOS mobil strateji prototipidir.

## V11 yenilikleri

- Animasyonlu 3B piyade ve okçular; sınıfa göre silah, kalkan ve tarihî başlıklar
- Sipahi süvarileri, Şahi topları ve yeni **Şahi Ateşi** meydan emri
- Kalkan duvarı, ok yağmuru, hücum, moral ve düşman karşı-taktikleri
- Özgün kuşatma ana görseli ve 1024×1024 mağaza ikonu
- Sefer davulları, hücum borusu, ok, kılıç, top ve zafer sesleri
- Günlük Divan emri, yedi kalıcı fetih görevi, ödül ve şöhret ilerlemesi
- Çevrimdışı güvenli kayıt ve daha sonra gerçek sunucuya bağlanabilecek bulut eşitleme geçidi

## Unity'de açma

1. Unity Hub'da **Add project from disk** seçin.
2. Bu klasörü seçin.
3. Unity 6000.0 ile açın.
4. Android için `Cihan > Android APK Oluştur` menüsünü kullanın.
5. iPhone için `Cihan > iOS Xcode Projesi Oluştur` menüsünü kullanın.

## iPhone yayını

Unity'nin oluşturduğu `Unity-iPhone.xcodeproj` dosyasını Xcode ile açın. Apple geliştirici takımınızı seçip **Product > Archive** ile TestFlight/App Store paketi oluşturun. Kaynak kod ve iPhone cihaz derlemesi doğrulanmıştır; imzalı IPA üretimi Apple geliştirici hesabına bağlıdır.

## Sunucu bağlantısı

Oyun sunucu adresi verilene kadar profili cihazda ve yerel eşitleme kuyruğunda korur. Bir REST uç noktası hazırlandığında `CihanCloudGateway.ConfigureEndpoint(...)` ile bağlanabilir. Canlı çok oyunculu eşleşme sunucusu bu prototipte etkin değildir.

## Lisanslar

KayKit karakter ve animasyon lisansları `Assets/Cihan/ThirdParty/KayKit` klasöründedir.
