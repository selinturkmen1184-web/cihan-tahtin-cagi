using System;
using UnityEditor;
using UnityEngine;

namespace Cihan.Editor
{
    /// <summary>
    /// Keeps the cinematic V27/V28 artwork sharp on mobile while preventing
    /// source-resolution RGBA textures from inflating the APK.
    /// </summary>
    public static class CihanMobileTextureOptimizer
    {
        private const string ArtFolder = "Assets/Cihan/Resources/Art";

        public static void Optimize()
        {
            foreach (var guid in AssetDatabase.FindAssets("t:Texture2D", new[] { ArtFolder }))
            {
                var assetPath = AssetDatabase.GUIDToAssetPath(guid);
                if (!IsCinematicUnitTexture(assetPath))
                {
                    continue;
                }

                var importer = AssetImporter.GetAtPath(assetPath) as TextureImporter;
                if (importer == null)
                {
                    continue;
                }

                var changed = false;
                changed |= SetIfDifferent(importer.maxTextureSize, 1024, value => importer.maxTextureSize = value);
                changed |= SetIfDifferent(importer.mipmapEnabled, false, value => importer.mipmapEnabled = value);
                changed |= SetIfDifferent(importer.isReadable, false, value => importer.isReadable = value);
                changed |= SetIfDifferent(importer.alphaIsTransparency, true, value => importer.alphaIsTransparency = value);
                changed |= SetIfDifferent(importer.textureCompression, TextureImporterCompression.CompressedHQ,
                    value => importer.textureCompression = value);
                changed |= SetIfDifferent(importer.crunchedCompression, true, value => importer.crunchedCompression = value);
                changed |= SetIfDifferent(importer.compressionQuality, 100, value => importer.compressionQuality = value);

                var android = importer.GetPlatformTextureSettings("Android");
                if (!android.overridden ||
                    android.maxTextureSize != 1024 ||
                    android.format != TextureImporterFormat.ETC2_RGBA8Crunched ||
                    android.compressionQuality != 100)
                {
                    android.name = "Android";
                    android.overridden = true;
                    android.maxTextureSize = 1024;
                    android.format = TextureImporterFormat.ETC2_RGBA8Crunched;
                    android.compressionQuality = 100;
                    importer.SetPlatformTextureSettings(android);
                    changed = true;
                }

                if (changed)
                {
                    importer.SaveAndReimport();
                    Debug.Log($"CİHAN mobil görsel optimize edildi: {assetPath}");
                }
            }
        }

        private static bool IsCinematicUnitTexture(string assetPath)
        {
            var fileName = System.IO.Path.GetFileName(assetPath);
            return ((fileName.StartsWith("cihan-unit-", StringComparison.OrdinalIgnoreCase) &&
                     (fileName.Contains("-v27", StringComparison.OrdinalIgnoreCase) ||
                      fileName.Contains("-v28", StringComparison.OrdinalIgnoreCase))) ||
                    fileName.Equals("cihan-battlefield-v28.png", StringComparison.OrdinalIgnoreCase));
        }

        private static bool SetIfDifferent<T>(T current, T desired, Action<T> setter)
        {
            if (Equals(current, desired))
            {
                return false;
            }

            setter(desired);
            return true;
        }
    }
}
