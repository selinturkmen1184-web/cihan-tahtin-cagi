using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Android;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;
using UnityEngine.Rendering;

namespace Cihan.Editor
{
    public static class CihanAndroidBuilder
    {
        private const string DefaultApkName = "Cihan-Tahtin-Cagi-v28.apk";

        [MenuItem("Cihan/Android APK Oluştur")]
        public static void BuildFromMenu()
        {
            Build();
        }

        public static void Build()
        {
            CihanProjectSetup.ConfigureProject();
            CihanKayKitSetup.EnsureConfigured();

            if (!BuildPipeline.IsBuildTargetSupported(
                    BuildTargetGroup.Android,
                    BuildTarget.Android))
            {
                throw new BuildFailedException(
                    "Unity Android Build Support modülü kurulu değil.");
            }

            if (!EditorUserBuildSettings.SwitchActiveBuildTarget(
                    BuildTargetGroup.Android,
                    BuildTarget.Android))
            {
                throw new BuildFailedException(
                    "Unity Android hedef platformuna geçemedi.");
            }

            ApplyAndroidSettings();
            CihanMobileTextureOptimizer.Optimize();

            var outputPath = ResolveOutputPath();
            var outputDirectory = Path.GetDirectoryName(outputPath);
            if (!string.IsNullOrWhiteSpace(outputDirectory))
            {
                Directory.CreateDirectory(outputDirectory);
            }

            var scenes = EditorBuildSettings.scenes
                .Where(scene => scene.enabled)
                .Select(scene => scene.path)
                .ToArray();
            if (scenes.Length == 0)
            {
                throw new BuildFailedException(
                    "APK için etkin bir Unity sahnesi bulunamadı.");
            }

            var report = BuildPipeline.BuildPlayer(
                new BuildPlayerOptions
                {
                    scenes = scenes,
                    locationPathName = outputPath,
                    target = BuildTarget.Android,
                    targetGroup = BuildTargetGroup.Android,
                    options = BuildOptions.None
                });

            if (report.summary.result != BuildResult.Succeeded)
            {
                throw new BuildFailedException(
                    $"CİHAN APK derlemesi başarısız: {report.summary.result}");
            }

            Debug.Log(
                $"CİHAN APK hazır: {outputPath} " +
                $"({report.summary.totalSize / 1024f / 1024f:N1} MB)");
        }

        private static void ApplyAndroidSettings()
        {
            PlayerSettings.companyName = "Selin Türkmen";
            PlayerSettings.productName = "CİHAN: Tahtın Çağı";
            PlayerSettings.bundleVersion = "0.28.0";
            PlayerSettings.SetApplicationIdentifier(
                BuildTargetGroup.Android,
                "com.selinturkmen.cihan");
            PlayerSettings.Android.bundleVersionCode = 280;
            PlayerSettings.Android.minSdkVersion =
                AndroidSdkVersions.AndroidApiLevel26;
            PlayerSettings.Android.targetSdkVersion =
                AndroidSdkVersions.AndroidApiLevelAuto;
            // 32-bit ve 64-bit Android telefonları aynı APK ile destekle.
            PlayerSettings.Android.targetArchitectures =
                AndroidArchitecture.ARMv7 | AndroidArchitecture.ARM64;
            PlayerSettings.SetScriptingBackend(
                BuildTargetGroup.Android,
                ScriptingImplementation.IL2CPP);
            PlayerSettings.SetManagedStrippingLevel(
                NamedBuildTarget.Android,
                ManagedStrippingLevel.Low);
            PlayerSettings.SetApiCompatibilityLevel(
                NamedBuildTarget.Android,
                ApiCompatibilityLevel.NET_Standard);
            PlayerSettings.stripEngineCode = false;

            // Vulkan sürücüleri bazı Android cihazlarda Unity açılış ekranında
            // yerel çökmeye neden olabiliyor. GLES3 ve klasik Activity girişi
            // daha geniş cihaz uyumluluğu sağlıyor.
            PlayerSettings.SetUseDefaultGraphicsAPIs(BuildTarget.Android, false);
            PlayerSettings.SetGraphicsAPIs(
                BuildTarget.Android,
                new[] { GraphicsDeviceType.OpenGLES3 });
            PlayerSettings.Android.applicationEntry =
                AndroidApplicationEntry.Activity;

            ConfigureNdk();

            EditorUserBuildSettings.buildAppBundle = false;
            EditorUserBuildSettings.exportAsGoogleAndroidProject = false;
        }

        private static void ConfigureNdk()
        {
            var configuredNdk =
                Environment.GetEnvironmentVariable("CIHAN_ANDROID_NDK");
            var candidates = new[]
            {
                configuredNdk,
                "/private/tmp/cihan-ndk-r23b/Android NDK r23b/AndroidNDK7779620.app/Contents/NDK",
                "/Applications/Unity/PlaybackEngines/AndroidPlayer/NDK"
            };

            var ndkRoot = candidates.FirstOrDefault(HasNdkCompiler);
            if (string.IsNullOrWhiteSpace(ndkRoot))
            {
                throw new BuildFailedException(
                    "ARM64 derlemesi için Android NDK r23b bulunamadı.");
            }

            AndroidExternalToolsSettings.ndkRootPath = ndkRoot;
            Debug.Log($"CİHAN Android NDK: {ndkRoot}");
        }

        private static bool HasNdkCompiler(string path)
        {
            if (string.IsNullOrWhiteSpace(path) || !Directory.Exists(path))
            {
                return false;
            }

            var toolchain = Path.Combine(path, "toolchains", "llvm", "prebuilt");
            return Directory.Exists(toolchain) &&
                   Directory.EnumerateFiles(
                       toolchain,
                       "clang++",
                       SearchOption.AllDirectories).Any();
        }

        private static string ResolveOutputPath()
        {
            var environmentPath =
                Environment.GetEnvironmentVariable("CIHAN_APK_OUTPUT");
            if (!string.IsNullOrWhiteSpace(environmentPath))
            {
                return Path.GetFullPath(environmentPath);
            }

            var projectRoot = Directory.GetParent(Application.dataPath)?.FullName;
            if (string.IsNullOrWhiteSpace(projectRoot))
            {
                throw new BuildFailedException(
                    "Unity proje klasörü belirlenemedi.");
            }

            return Path.Combine(projectRoot, "Builds", DefaultApkName);
        }
    }
}
