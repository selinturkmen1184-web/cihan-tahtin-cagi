using System.Linq;
using Cihan.Battle;
using Cihan.Domain;
using Cihan.UI;
using UnityEditor;
using UnityEditor.Build;
using UnityEngine;

namespace Cihan.Editor
{
    public static class CihanV12SmokeTests
    {
        [MenuItem("Cihan/V12 Duman Testlerini Çalıştır")]
        public static void Run()
        {
            ValidateLivingCapitalAndResearch();
            ValidateCommanderProgression();
            ValidateFormationAndBattle();
            ValidateTacticalOrdersAndCampaign();
            ValidateCampaignCouncil();
            ValidateWorldMarch();
            ValidateAllianceAndPvp();
            ValidateRequiredAssets();
            Debug.Log("CIHAN_V12_SMOKE_TESTS_PASSED");
        }

        private static void ValidateLivingCapitalAndResearch()
        {
            const double now = 45000d;
            var state = GameState.CreateNew(now);
            Require(state.GetBuilding("academy") != null, "Enderun Akademisi oluşturulmadı.");
            Require(state.GetBuilding("embassy") != null, "Sancak Elçiliği oluşturulmadı.");
            Require(state.Population > 1000, "Başkent nüfusu hesaplanmadı.");
            var foodBeforeCollection = state.food;
            Require(
                state.ClaimBuildingProduction("farm", now),
                "Dokunulabilir şehir üretimi toplanamadı.");
            Require(
                state.food > foodBeforeCollection,
                "Şehir üretimi kaynağa dönüşmedi.");
            Require(
                !state.ClaimBuildingProduction("farm", now + 1d),
                "Üretim toplama bekleme süresi uygulanmadı.");
            Require(state.BeginResearch("logistics", now), "Araştırma başlatılamadı.");
            state.Advance(now + 40d);
            Require(state.ResearchLevel("logistics") == 1, "Araştırma tamamlanmadı.");
        }

        private static void ValidateCommanderProgression()
        {
            var state = GameState.CreateNew(55000d);
            var hero = state.GetHero("aybars");
            var initialPower = state.CommanderPower("aybars");
            Require(state.UpgradeCommanderLevel("aybars"), "Komutan seviyesi yükseltilemedi.");
            Require(state.CommanderPower("aybars") > initialPower, "Komutan gücü artmadı.");
            Require(state.UpgradeCommanderEquipment("aybars"), "Komutan teçhizatı geliştirilemedi.");
            hero.shards = 50;
            Require(state.PromoteCommander("aybars"), "Komutan yıldız terfisi yapılamadı.");
            Require(hero.stars == 2, "Komutan yıldızı artmadı.");
        }

        private static void ValidateFormationAndBattle()
        {
            var state = GameState.CreateNew(65000d);
            var previousRevision = state.formationRevision;
            state.SetFormationDoctrine("shield");
            state.CycleFormationUnit(0);
            Require(state.formationRevision > previousRevision, "Formasyon değişikliği kaydedilmedi.");
            Require(state.FormationPower > 0, "Formasyon gücü hesaplanmadı.");

            var battle = BattleSimulation.Create(state, 1);
            Require(battle.ApplyFormation(BattleFormation.ShieldWall), "Kalkan düzeni uygulanamadı.");
            Require(battle.LaunchCannonBarrage(), "Şahi ateşi kullanılamadı.");
            Require(
                battle.Units.Any(item => item.team == BattleTeam.Enemy && item.hp < item.maxHp),
                "Şahi ateşi düşman hattına hasar vermedi.");
        }

        private static void ValidateTacticalOrdersAndCampaign()
        {
            var state = GameState.CreateNew(70000d);
            state.EnsureCompatibility();
            Require(GameRules.Campaign.Length == 12, "V25 seferi 12 bölgeye genişletilmedi.");
            Require(
                state.campaignBestStars.Length == GameRules.Campaign.Length,
                "Sefer yıldız kaydı yeni bölge sayısıyla uyumlu değil.");
            Require(
                GameRules.Campaign[11].enemyTier == 5,
                "Bölüm sonu kumandanı zorluk kademesine bağlanmadı.");
            Require(
                typeof(CihanPremiumWorldOverlay).Assembly == typeof(CihanGameApp).Assembly,
                "V24 sinematik etkileşim katmanı çalışma derlemesine katılmadı.");

            var battle = BattleSimulation.Create(state, 3);
            Require(
                battle.ApplyFormation(BattleFormation.Crescent),
                "Taktik emir testi için düzen seçilemedi.");
            var enemyArcher = battle.Units.First(item =>
                item.team == BattleTeam.Enemy &&
                item.kind == BattleUnitKind.Archer);
            Require(
                battle.IssueFocusOrder(BattleUnitKind.Cavalry, enemyArcher.id),
                "Süvariye hedef saldırı emri verilemedi.");
            Require(
                battle.IssueLaneOrder(BattleUnitKind.Infantry, 0.22f),
                "Piyadeye sol kanat emri verilemedi.");
            battle.Step(0.05f);
            Require(
                battle.Units
                    .Where(item =>
                        item.team == BattleTeam.Friendly &&
                        item.kind == BattleUnitKind.Cavalry &&
                        item.targetId > 0)
                    .Any(item =>
                        battle.TryGetUnit(item.targetId, out var target) &&
                        target.kind == BattleUnitKind.Archer),
                "Süvari hedef saldırı emrinde düşman okçusuna yönelmedi.");
            Require(
                battle.IssueTacticalFallback(BattleUnitKind.Infantry),
                "Piyadeye taktik geri çekilme emri verilemedi.");
        }

        private static void ValidateCampaignCouncil()
        {
            var direct = GameState.CreateNew(72000d);
            var directFood = direct.food;
            Require(
                direct.BeginCampaignOperation(0, "assault", out var assault),
                "Doğrudan hücum planı başlatılamadı.");
            Require(
                assault != null &&
                assault.powerMultiplier == 1f &&
                direct.food == directFood - GameRules.Campaign[0].marchFood,
                "Doğrudan hücum maliyeti veya etkisi yanlış.");

            var intelligence = GameState.CreateNew(72100d);
            var intelligenceGold = intelligence.gold;
            var intelligenceCost = GameRules.CampaignOperationCost(
                "intelligence",
                GameRules.Campaign[0].enemyTier);
            Require(
                intelligence.BeginCampaignOperation(
                    0,
                    "intelligence",
                    out var intelligencePlan),
                "Casus ağı planı başlatılamadı.");
            Require(
                intelligencePlan.moralePenalty > 10f &&
                intelligence.gold == intelligenceGold - intelligenceCost.gold,
                "Casus ağı düşman moralini veya hazineyi değiştirmedi.");

            var sabotage = GameState.CreateNew(72200d);
            Require(
                sabotage.BeginCampaignOperation(0, "sabotage", out var sabotagePlan) &&
                sabotagePlan.powerMultiplier < 0.9f,
                "Sabotaj düşman gücünü azaltmadı.");

            var bribery = GameState.CreateNew(72300d);
            Require(
                bribery.BeginCampaignOperation(0, "bribery", out var briberyPlan) &&
                briberyPlan.countMultiplier < 0.8f,
                "Rüşvet düşman asker sayısını azaltmadı.");

            var atomic = GameState.CreateNew(72400d);
            atomic.gold = 0;
            var atomicFood = atomic.food;
            Require(
                !atomic.BeginCampaignOperation(0, "bribery", out _) &&
                atomic.food == atomicFood,
                "Yetersiz kaynakta Sefer Meclisi maliyeti kısmen harcandı.");
        }

        private static void ValidateWorldMarch()
        {
            const double now = 75000d;
            var state = GameState.CreateNew(now);
            Require(state.ScoutWorldNode(0), "Dünya bölgesi keşfedilemedi.");
            Require(state.BeginWorldMarch(0, now), "Dünya yürüyüşü başlatılamadı.");
            state.Advance(now + 40d);
            Require(state.IsWorldNodeClaimed(0), "Dünya bölgesi ele geçirilemedi.");
            Require(state.TerritoriesControlled == 1, "Bölge hakimiyeti sayılmadı.");
        }

        private static void ValidateAllianceAndPvp()
        {
            const double now = 85000d;
            var state = GameState.CreateNew(now);
            Require(state.DonateAlliance(), "İttifak bağışı yapılamadı.");
            Require(state.allianceContribution > 0, "İttifak katkısı artmadı.");
            Require(state.LaunchAllianceRally(now), "Ortak sefer başlatılamadı.");
            state.Advance(now + 40d);
            Require(state.allianceWarPoints > 0, "Ortak sefer puanı eklenmedi.");
            Require(state.SearchPvpOpponent(), "PvP rakibi bulunamadı.");
            Require(state.pvpOpponent != null, "PvP rakip kaydı oluşmadı.");
            Require(state.ResolvePvpSkirmish(), "PvP düellosu çözülemedi.");
            Require(state.pvpWins + state.pvpLosses == 1, "PvP sonucu kaydedilmedi.");
        }

        private static void ValidateRequiredAssets()
        {
            Require(
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-living-capital-v12.png") != null,
                "V12 yaşayan başkent görseli bulunamadı.");
            Require(
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-commanders-v12.png") != null,
                "V12 komutan atlası bulunamadı.");
            Require(
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-world-map-v12.png") != null,
                "V12 dünya haritası bulunamadı.");
            Require(
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-capital-v18.png") != null,
                "V18 sinematik payitaht görseli bulunamadı.");
            Require(
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-campaign-parchment-v18.png") != null,
                "V18 parşömen sefer haritası bulunamadı.");
            Require(
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-commander-aybars-v16.png") != null &&
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-commander-nizam-v16.png") != null &&
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-commander-leyla-v16.png") != null,
                "V20 komutan koleksiyonu portreleri bulunamadı.");
            Require(
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-capital-v21.png") != null &&
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-world-v21.png") != null &&
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-siege-v21.png") != null,
                "V23 başkent, dünya veya kuşatma görseli bulunamadı.");
            Require(
                AssetDatabase.LoadAssetAtPath<GameObject>(
                    "Assets/Cihan/Resources/KayKit/Characters/Knight.fbx") != null,
                "Animasyonlu asker modeli bulunamadı.");
            Require(
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-capital-v24.png") != null &&
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-world-v24.png") != null &&
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-guard-v24.png") != null,
                "V24 sinematik başkent, dünya veya hareketli muhafız görseli bulunamadı.");
            Require(
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-capital-v26.png") != null &&
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-world-v26.png") != null &&
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-council-v26.png") != null &&
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-siege-v26.png") != null,
                "V26 Köz İmparatorluğu görsel seti eksik.");
            Require(
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-unit-infantry-v27.png") != null &&
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-unit-archer-v27.png") != null &&
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-unit-cavalry-v27.png") != null &&
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-unit-siege-v27.png") != null &&
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-unit-commander-v27.png") != null,
                "V27 yüksek ayrıntılı sinematik birlik seti eksik.");
            Require(
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-unit-infantry-v28.png") != null &&
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-unit-archer-v28.png") != null &&
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-unit-cavalry-v28.png") != null &&
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-unit-siege-v28.png") != null &&
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-unit-commander-v28.png") != null &&
                AssetDatabase.LoadAssetAtPath<Texture2D>(
                    "Assets/Cihan/Resources/Art/cihan-battlefield-v28.png") != null,
                "V28 Altın Sefer görsel seti eksik.");
        }

        private static void Require(bool condition, string message)
        {
            if (!condition)
            {
                throw new BuildFailedException($"CİHAN V12 testi başarısız: {message}");
            }
        }
    }
}
