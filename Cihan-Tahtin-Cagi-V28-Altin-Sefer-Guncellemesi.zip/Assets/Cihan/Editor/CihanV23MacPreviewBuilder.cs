using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace Cihan.Editor
{
    public static class CihanV23MacPreviewBuilder
    {
        public static void Build()
        {
            CihanProjectSetup.ConfigureProject();
            CihanKayKitSetup.EnsureConfigured();
            if (!EditorUserBuildSettings.SwitchActiveBuildTarget(
                    BuildTargetGroup.Standalone,
                    BuildTarget.StandaloneOSX))
            {
                throw new BuildFailedException("macOS önizleme hedefine geçilemedi.");
            }

            PlayerSettings.fullScreenMode = FullScreenMode.Windowed;
            PlayerSettings.defaultScreenWidth = 540;
            PlayerSettings.defaultScreenHeight = 960;
            PlayerSettings.resizableWindow = false;
            PlayerSettings.bundleVersion = "0.28.0";

            var output = Environment.GetEnvironmentVariable("CIHAN_MAC_PREVIEW_OUTPUT");
            if (string.IsNullOrWhiteSpace(output))
            {
                output = "/private/tmp/CihanV23Preview.app";
            }

            output = Path.GetFullPath(output);
            var scenes = EditorBuildSettings.scenes
                .Where(scene => scene.enabled)
                .Select(scene => scene.path)
                .ToArray();
            var report = BuildPipeline.BuildPlayer(
                new BuildPlayerOptions
                {
                    scenes = scenes,
                    locationPathName = output,
                    target = BuildTarget.StandaloneOSX,
                    targetGroup = BuildTargetGroup.Standalone,
                    options = BuildOptions.Development
                });
            if (report.summary.result != BuildResult.Succeeded)
            {
                throw new BuildFailedException(
                    $"V23 macOS önizleme derlemesi başarısız: {report.summary.result}");
            }

            Debug.Log($"CIHAN_V23_MAC_PREVIEW {output}");
        }
    }
}
