using System;
using System.Collections.Generic;
using Cihan.Battle;
using Cihan.Domain;
using Cihan.Services;
using UnityEngine;
using UnityEngine.UI;

namespace Cihan.UI
{
    public sealed class CihanBattleView : MonoBehaviour
    {
        private sealed class UnitVisual
        {
            public RectTransform rect;
            public Image health;
            public Text strength;
            public Outline markerOutline;
            public BattleTeam team;
            public BattleUnitKind kind;
        }

        private sealed class CommandVisual
        {
            public Button button;
            public Text label;
            public Image cooldownMask;
            public string readyLabel;
        }

        private static readonly Color32 Ink = new(7, 12, 24, 255);
        private static readonly Color32 Panel = new(14, 25, 45, 245);
        private static readonly Color32 Gold = new(229, 184, 75, 255);
        private static readonly Color32 Ivory = new(247, 239, 220, 255);
        private static readonly Color32 Muted = new(181, 194, 211, 255);
        private static readonly Color32 FriendlyBright = new(56, 123, 235, 255);
        private static readonly Color32 EnemyBright = new(205, 50, 55, 255);

        private static float preparedMoralePenalty;
        private static float preparedPowerMultiplier = 1f;
        private static float preparedCountMultiplier = 1f;
        private static string preparedIntrigueReport;

        private readonly Dictionary<int, UnitVisual> visuals = new();
        private readonly HashSet<BattleUnitKind> deployed = new();
        private readonly Dictionary<BattleCommand, CommandVisual> commandVisuals = new();
        private readonly List<Sprite> runtimePortraits = new();

        private GameService game;
        private CampaignSpec battleStage;
        private Action closed;
        private BattleSimulation simulation;
        private Font font;
        private RectTransform unitLayer;
        private Text timerText;
        private Text friendlyText;
        private Text enemyText;
        private Text battleMessage;
        private Text tacticalOrderText;
        private Text formationText;
        private RectTransform moraleFill;
        private RectTransform commanderFill;
        private Text siegeProgressText;
        private Sprite aybarsPortrait;
        private Sprite nizamPortrait;
        private Sprite leylaPortrait;
        private Sprite infantryPortrait;
        private Sprite archerPortrait;
        private Sprite cavalryPortrait;
        private Sprite siegePortrait;
        private Sprite commanderPortrait;
        private GameObject resultOverlay;
        private RenderTexture battleRender;
        private CihanBattleWorld3D battleWorld;
        private GameObject deploymentOverlay;
        private bool battleStarted;
        private bool resultShown;
        private bool resultApplied;
        private float enemyMoralePenalty;
        private float enemyPowerMultiplier = 1f;
        private float enemyCountMultiplier = 1f;
        private string intrigueReport;
        private BattleUnitKind? selectedSquadKind;

        public static void PrepareNextBattle(
            float moralePenalty,
            float powerMultiplier,
            float countMultiplier,
            string report)
        {
            preparedMoralePenalty = Mathf.Clamp(moralePenalty, 0f, 45f);
            preparedPowerMultiplier = Mathf.Clamp(powerMultiplier, 0.55f, 1.25f);
            preparedCountMultiplier = Mathf.Clamp(countMultiplier, 0.55f, 1.20f);
            preparedIntrigueReport = report;
        }

        public static void Show(
            GameService game,
            CampaignSpec battleStage,
            Action onClosed)
        {
            if (FindFirstObjectByType<CihanBattleView>() != null)
            {
                return;
            }

            var root = new GameObject("CİHAN · Canlı Kuşatma");
            var view = root.AddComponent<CihanBattleView>();
            view.game = game;
            view.battleStage = battleStage;
            view.closed = onClosed;
            view.enemyMoralePenalty = preparedMoralePenalty;
            view.enemyPowerMultiplier = preparedPowerMultiplier;
            view.enemyCountMultiplier = preparedCountMultiplier;
            view.intrigueReport = preparedIntrigueReport;
            preparedMoralePenalty = 0f;
            preparedPowerMultiplier = 1f;
            preparedCountMultiplier = 1f;
            preparedIntrigueReport = null;
        }

        public static void Show(GameService game, Action onClosed)
        {
            Show(game, GameRules.Campaign[0], onClosed);
        }

        private void Start()
        {
            font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            if (font == null)
            {
                font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            }

            aybarsPortrait = LoadPortrait("Art/cihan-commander-aybars-v16");
            nizamPortrait = LoadPortrait("Art/cihan-commander-nizam-v16");
            leylaPortrait = LoadPortrait("Art/cihan-commander-leyla-v16");
            infantryPortrait = LoadPortrait("Art/cihan-unit-infantry-v28");
            archerPortrait = LoadPortrait("Art/cihan-unit-archer-v28");
            cavalryPortrait = LoadPortrait("Art/cihan-unit-cavalry-v28");
            siegePortrait = LoadPortrait("Art/cihan-unit-siege-v28");
            commanderPortrait = LoadPortrait("Art/cihan-unit-commander-v28");

            battleStage ??= GameRules.Campaign[0];
            simulation = BattleSimulation.Create(
                game.State,
                battleStage.enemyTier,
                enemyMoralePenalty,
                enemyPowerMultiplier,
                enemyCountMultiplier);
            CihanAudioDirector.Instance?.EnterBattle();
            BuildInterface();
            SyncUnitVisuals();
            ShowDeployment();
            if (HasCommandLineFlag("-cihan-auto-deploy"))
            {
                SelectFormation(BattleFormation.Crescent);
            }
        }

        private void Update()
        {
            if (simulation == null || resultShown || !battleStarted)
            {
                return;
            }

            simulation.Step(Time.unscaledDeltaTime);
            SyncUnitVisuals();
            RefreshHud();

            if (simulation.IsFinished)
            {
                ShowResult();
            }
        }

        private void BuildInterface()
        {
            var canvas = gameObject.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 100;

            var scaler = gameObject.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1080, 1920);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0.5f;
            gameObject.AddComponent<GraphicRaycaster>();

            var blackout = CreatePanel(transform, "Savaş Zemini", Ink);
            Stretch(blackout.rectTransform);

            var safeArea = CreatePanel(transform, "Güvenli Alan", Color.clear);
            Stretch(safeArea.rectTransform);
            safeArea.gameObject.AddComponent<SafeAreaFitter>();

            BuildBattlefield(safeArea.transform);
            BuildHeader(safeArea.transform);
            BuildCommands(safeArea.transform);
        }

        private void BuildBattlefield(Transform parent)
        {
            var arena = new GameObject(
                "Kuşatma Meydanı",
                typeof(RectTransform),
                typeof(RawImage),
                typeof(Mask));
            arena.transform.SetParent(parent, false);
            var arenaRect = (RectTransform)arena.transform;
            arenaRect.anchorMin = Vector2.zero;
            arenaRect.anchorMax = Vector2.one;
            arenaRect.offsetMin = new Vector2(8f, 238f);
            arenaRect.offsetMax = new Vector2(-8f, -150f);

            var background = arena.GetComponent<RawImage>();
            battleRender = new RenderTexture(
                900,
                1350,
                24,
                RenderTextureFormat.ARGB32)
            {
                name = "CİHAN V28 Altın Sefer Savaş Görüntüsü",
                antiAliasing = 4,
                filterMode = FilterMode.Bilinear
            };
            battleRender.Create();
            background.texture = battleRender;
            background.color = Color.white;
            background.raycastTarget = false;
            arena.GetComponent<Mask>().showMaskGraphic = true;

            battleWorld = gameObject.AddComponent<CihanBattleWorld3D>();
            battleWorld.Initialize(simulation, battleRender);

            var shade = CreatePanel(
                arena.transform,
                "Okunabilirlik Gölgesi",
                new Color32(9, 16, 29, 18));
            Stretch(shade.rectTransform);

            var layer = new GameObject("Hareketli Birlikler", typeof(RectTransform));
            layer.transform.SetParent(arena.transform, false);
            unitLayer = (RectTransform)layer.transform;
            Stretch(unitLayer, 12f, 12f, 12f, 12f);

            battleMessage = CreateText(
                arena.transform,
                "ORDULAR İLERLİYOR",
                18,
                Ivory,
                TextAnchor.UpperCenter,
                FontStyle.Bold);
            battleMessage.rectTransform.anchorMin = new Vector2(0f, 1f);
            battleMessage.rectTransform.anchorMax = new Vector2(1f, 1f);
            battleMessage.rectTransform.sizeDelta = new Vector2(0f, 42f);
            battleMessage.rectTransform.anchoredPosition = new Vector2(0f, -24f);

            BuildTacticalOrderBar(arena.transform);
        }

        private void BuildTacticalOrderBar(Transform parent)
        {
            var bar = CreatePanel(
                parent,
                "Doğrudan Manga Emirleri",
                new Color32(12, 24, 45, 230));
            bar.rectTransform.anchorMin = new Vector2(0.015f, 0.015f);
            bar.rectTransform.anchorMax = new Vector2(0.985f, 0.145f);
            bar.rectTransform.offsetMin = Vector2.zero;
            bar.rectTransform.offsetMax = Vector2.zero;

            tacticalOrderText = CreateText(
                bar.transform,
                "MANGA SEÇ",
                14,
                Gold,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            tacticalOrderText.rectTransform.anchorMin = new Vector2(0.01f, 0.08f);
            tacticalOrderText.rectTransform.anchorMax = new Vector2(0.24f, 0.92f);
            tacticalOrderText.rectTransform.offsetMin = Vector2.zero;
            tacticalOrderText.rectTransform.offsetMax = Vector2.zero;

            AddLaneOrderButton(bar.transform, "SOL", 0.25f, 0.22f);
            AddLaneOrderButton(bar.transform, "MERKEZ", 0.43f, 0.50f);
            AddLaneOrderButton(bar.transform, "SAĞ", 0.63f, 0.78f);

            var fallback = CreateButton(
                bar.transform,
                "GERİ",
                IssueSelectedFallback,
                new Color32(104, 42, 38, 245),
                14);
            var fallbackRect = fallback.GetComponent<RectTransform>();
            fallbackRect.anchorMin = new Vector2(0.82f, 0.12f);
            fallbackRect.anchorMax = new Vector2(0.98f, 0.88f);
            fallbackRect.offsetMin = Vector2.zero;
            fallbackRect.offsetMax = Vector2.zero;
        }

        private void AddLaneOrderButton(
            Transform parent,
            string label,
            float minX,
            float lane)
        {
            var button = CreateButton(
                parent,
                label,
                () => IssueSelectedLane(lane, label),
                new Color32(38, 78, 151, 245),
                14);
            var rect = button.GetComponent<RectTransform>();
            rect.anchorMin = new Vector2(minX, 0.12f);
            rect.anchorMax = new Vector2(minX + 0.16f, 0.88f);
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;
        }

        private void IssueSelectedLane(float lane, string label)
        {
            if (!selectedSquadKind.HasValue ||
                !simulation.IssueLaneOrder(selectedSquadKind.Value, lane))
            {
                return;
            }

            tacticalOrderText.text = $"{KindTitle(selectedSquadKind.Value)}\n{label} KANAT";
            battleMessage.text = $"{KindTitle(selectedSquadKind.Value)} · {label} MEVZİYE";
            PulseHaptic();
        }

        private void IssueSelectedFallback()
        {
            if (!selectedSquadKind.HasValue ||
                !simulation.IssueTacticalFallback(selectedSquadKind.Value))
            {
                return;
            }

            tacticalOrderText.text = $"{KindTitle(selectedSquadKind.Value)}\nGERİ ÇEKİL";
            battleMessage.text = $"{KindTitle(selectedSquadKind.Value)} · HAT GERİ ALINIYOR";
            PulseHaptic();
        }

        private void BuildHeader(Transform parent)
        {
            var header = CreatePanel(parent, "Savaş Başlığı", Panel);
            header.rectTransform.anchorMin = new Vector2(0f, 1f);
            header.rectTransform.anchorMax = new Vector2(1f, 1f);
            header.rectTransform.sizeDelta = new Vector2(0f, 145f);
            header.rectTransform.anchoredPosition = new Vector2(0f, -72.5f);

            var title = CreateText(
                header.transform,
                battleStage.title.ToUpperInvariant(),
                20,
                Gold,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            title.rectTransform.anchorMin = new Vector2(0f, 0.67f);
            title.rectTransform.anchorMax = new Vector2(1f, 1f);
            title.rectTransform.offsetMin = new Vector2(145f, 0f);
            title.rectTransform.offsetMax = new Vector2(-145f, -8f);

            CreateCommanderMedallion(
                header.transform,
                "CİHAN KOMUTANI",
                aybarsPortrait,
                true);
            CreateCommanderMedallion(
                header.transform,
                "HİSAR KOMUTANI",
                nizamPortrait,
                false);

            friendlyText = CreateText(
                header.transform,
                "CİHAN 0",
                17,
                FriendlyBright,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            SetHudRect(friendlyText.rectTransform, 0f, 0.34f, 32f);
            friendlyText.rectTransform.anchorMin = new Vector2(0.13f, 0.40f);
            friendlyText.rectTransform.anchorMax = new Vector2(0.34f, 0.69f);

            timerText = CreateText(
                header.transform,
                "00:00",
                19,
                Ivory,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            SetHudRect(timerText.rectTransform, 0.34f, 0.66f, 0f);
            timerText.rectTransform.anchorMin = new Vector2(0.34f, 0.40f);
            timerText.rectTransform.anchorMax = new Vector2(0.66f, 0.69f);

            enemyText = CreateText(
                header.transform,
                "HİSAR 0",
                17,
                EnemyBright,
                TextAnchor.MiddleRight,
                FontStyle.Bold);
            SetHudRect(enemyText.rectTransform, 0.66f, 1f, -32f);
            enemyText.rectTransform.anchorMin = new Vector2(0.66f, 0.40f);
            enemyText.rectTransform.anchorMax = new Vector2(0.87f, 0.69f);

            moraleFill = CreateBattleMeter(
                header.transform,
                "CİHAN MORALİ",
                new Vector2(0.04f, 0.06f),
                new Vector2(0.37f, 0.16f),
                FriendlyBright);
            commanderFill = CreateBattleMeter(
                header.transform,
                " ",
                new Vector2(0.12f, 0.23f),
                new Vector2(0.88f, 0.34f),
                EnemyBright);

            siegeProgressText = CreateText(
                header.transform,
                "HİSAR SAVUNMASI  %100",
                11,
                Ivory,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            siegeProgressText.rectTransform.anchorMin = new Vector2(0.12f, 0.23f);
            siegeProgressText.rectTransform.anchorMax = new Vector2(0.88f, 0.34f);
            siegeProgressText.rectTransform.offsetMin = new Vector2(4f, 0f);
            siegeProgressText.rectTransform.offsetMax = new Vector2(-4f, 0f);

            formationText = CreateText(
                header.transform,
                "SAVAŞ DÜZENİ BEKLENİYOR",
                11,
                Muted,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            formationText.rectTransform.anchorMin = new Vector2(0.40f, 0.03f);
            formationText.rectTransform.anchorMax = new Vector2(0.96f, 0.18f);
            formationText.rectTransform.offsetMin = new Vector2(8f, 0f);
            formationText.rectTransform.offsetMax = new Vector2(-8f, 0f);
        }

        private RectTransform CreateBattleMeter(
            Transform parent,
            string label,
            Vector2 anchorMin,
            Vector2 anchorMax,
            Color color)
        {
            var track = CreatePanel(
                parent,
                $"{label} Göstergesi",
                new Color32(33, 38, 41, 255));
            track.rectTransform.anchorMin = anchorMin;
            track.rectTransform.anchorMax = anchorMax;
            track.rectTransform.offsetMin = Vector2.zero;
            track.rectTransform.offsetMax = Vector2.zero;

            var fill = CreatePanel(track.transform, "Doluluk", color);
            fill.rectTransform.anchorMin = Vector2.zero;
            fill.rectTransform.anchorMax = Vector2.one;
            fill.rectTransform.offsetMin = new Vector2(3f, 3f);
            fill.rectTransform.offsetMax = new Vector2(-3f, -3f);

            var text = CreateText(
                track.transform,
                label,
                13,
                Ivory,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            Stretch(text.rectTransform, 4f, 4f, 0f, 0f);
            return fill.rectTransform;
        }

        private void CreateCommanderMedallion(
            Transform parent,
            string label,
            Sprite portrait,
            bool friendly)
        {
            var frame = CreatePanel(
                parent,
                label,
                friendly
                    ? new Color32(35, 90, 177, 255)
                    : new Color32(121, 38, 34, 255));
            frame.rectTransform.anchorMin = new Vector2(
                friendly ? 0.012f : 0.878f,
                0.39f);
            frame.rectTransform.anchorMax = new Vector2(
                friendly ? 0.122f : 0.988f,
                0.96f);
            frame.rectTransform.offsetMin = new Vector2(2f, 2f);
            frame.rectTransform.offsetMax = new Vector2(-2f, -2f);
            var outline = frame.gameObject.AddComponent<Outline>();
            outline.effectColor = Gold;
            outline.effectDistance = new Vector2(3f, -3f);

            var portraitImage = CreatePanel(
                frame.transform,
                "Komutan Portresi",
                Color.white);
            portraitImage.sprite = portrait;
            portraitImage.preserveAspect = true;
            portraitImage.rectTransform.anchorMin = new Vector2(0.03f, 0.24f);
            portraitImage.rectTransform.anchorMax = new Vector2(0.97f, 0.98f);
            portraitImage.rectTransform.offsetMin = Vector2.zero;
            portraitImage.rectTransform.offsetMax = Vector2.zero;

            var name = CreateText(
                frame.transform,
                friendly ? "AYBARS" : "NİZAM",
                12,
                Ivory,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            name.rectTransform.anchorMin = new Vector2(0f, 0f);
            name.rectTransform.anchorMax = new Vector2(1f, 0.25f);
            name.rectTransform.offsetMin = new Vector2(2f, 0f);
            name.rectTransform.offsetMax = new Vector2(-2f, 0f);
        }

        private void BuildCommands(Transform parent)
        {
            var commands = CreatePanel(parent, "Savaş Emirleri", Panel);
            commands.rectTransform.anchorMin = new Vector2(0f, 0f);
            commands.rectTransform.anchorMax = new Vector2(1f, 0f);
            commands.rectTransform.sizeDelta = new Vector2(0f, 228f);
            commands.rectTransform.anchoredPosition = new Vector2(0f, 114f);

            var label = CreateText(
                commands.transform,
                "MEYDAN EMİRLERİ · ZAMANLAMAYI SEN BELİRLE",
                13,
                Muted,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            label.rectTransform.anchorMin = new Vector2(0f, 0.86f);
            label.rectTransform.anchorMax = new Vector2(1f, 1f);
            label.rectTransform.offsetMin = new Vector2(20f, 0f);
            label.rectTransform.offsetMax = new Vector2(-20f, -8f);

            var commandRow = CreateCommandRow(
                commands.transform,
                "Taktik Emirler",
                0.48f,
                0.86f);
            AddTacticalCommandButton(
                commandRow.transform,
                BattleCommand.Charge,
                "AYBARS\nHÜCUM",
                aybarsPortrait,
                simulation.IssueCharge);
            AddTacticalCommandButton(
                commandRow.transform,
                BattleCommand.ShieldWall,
                "NİZAM\nKALKAN",
                nizamPortrait,
                simulation.RaiseShieldWall);
            AddTacticalCommandButton(
                commandRow.transform,
                BattleCommand.ArrowVolley,
                "LEYLA\nOK YAĞMURU",
                leylaPortrait,
                simulation.LaunchArrowVolley);
            AddTacticalCommandButton(
                commandRow.transform,
                BattleCommand.CannonBarrage,
                "NİZAM\nŞAHİ ATEŞİ",
                nizamPortrait,
                simulation.LaunchCannonBarrage);
            AddTacticalCommandButton(
                commandRow.transform,
                BattleCommand.Rally,
                "AYBARS\nCİHAT NARASI",
                aybarsPortrait,
                simulation.RallyTheArmy);

            var reinforcementRow = CreateCommandRow(
                commands.transform,
                "Takviye Emirleri",
                0.16f,
                0.45f);

            AddReinforcementButton(
                reinforcementRow.transform,
                BattleUnitKind.Infantry,
                "♟\nPİYADE");
            AddReinforcementButton(
                reinforcementRow.transform,
                BattleUnitKind.Archer,
                "➶\nOKÇU");
            AddReinforcementButton(
                reinforcementRow.transform,
                BattleUnitKind.Cavalry,
                "♞\nSÜVARİ");

            var retreat = CreateButton(
                commands.transform,
                "SANCAĞI KORU · GERİ ÇEKİL",
                () =>
                {
                    simulation.Retreat();
                    ShowResult();
                },
                new Color32(78, 48, 44, 255),
                12);
            retreat.GetComponent<RectTransform>().anchorMin = new Vector2(0.25f, 0.015f);
            retreat.GetComponent<RectTransform>().anchorMax = new Vector2(0.75f, 0.13f);
            retreat.GetComponent<RectTransform>().offsetMin = new Vector2(0f, 4f);
            retreat.GetComponent<RectTransform>().offsetMax = new Vector2(0f, -4f);
        }

        private GameObject CreateCommandRow(
            Transform parent,
            string name,
            float anchorMinY,
            float anchorMaxY)
        {
            var row = new GameObject(name, typeof(RectTransform));
            row.transform.SetParent(parent, false);
            var rowRect = (RectTransform)row.transform;
            rowRect.anchorMin = new Vector2(0f, anchorMinY);
            rowRect.anchorMax = new Vector2(1f, anchorMaxY);
            rowRect.offsetMin = new Vector2(10f, 3f);
            rowRect.offsetMax = new Vector2(-10f, -3f);
            var layout = row.AddComponent<HorizontalLayoutGroup>();
            layout.spacing = 6f;
            layout.childControlWidth = true;
            layout.childControlHeight = true;
            layout.childForceExpandWidth = true;
            layout.childForceExpandHeight = true;
            return row;
        }

        private void AddTacticalCommandButton(
            Transform parent,
            BattleCommand command,
            string label,
            Sprite portrait,
            Func<bool> action)
        {
            Button button = null;
            button = CreateButton(
                parent,
                label,
                () =>
                {
                    if (!action())
                    {
                        return;
                    }

                    battleMessage.text = CommandMessage(command);
                    PulseHaptic();
                    UpdateCommandButtons();
                },
                command switch
                {
                    BattleCommand.Charge => new Color32(120, 70, 34, 255),
                    BattleCommand.ShieldWall => new Color32(36, 78, 86, 255),
                    BattleCommand.ArrowVolley => new Color32(72, 67, 38, 255),
                    BattleCommand.CannonBarrage => new Color32(105, 55, 31, 255),
                    _ => new Color32(55, 64, 69, 255)
                },
                11);

            var labelText = button.GetComponentInChildren<Text>();
            labelText.rectTransform.anchorMin = new Vector2(0f, 0f);
            labelText.rectTransform.anchorMax = new Vector2(1f, 0.38f);
            labelText.rectTransform.offsetMin = new Vector2(4f, 2f);
            labelText.rectTransform.offsetMax = new Vector2(-4f, -1f);

            var portraitFrame = CreatePanel(
                button.transform,
                "Komutan Çerçevesi",
                new Color32(7, 12, 17, 255));
            portraitFrame.rectTransform.anchorMin = new Vector2(0.05f, 0.39f);
            portraitFrame.rectTransform.anchorMax = new Vector2(0.95f, 0.98f);
            portraitFrame.rectTransform.offsetMin = new Vector2(2f, 1f);
            portraitFrame.rectTransform.offsetMax = new Vector2(-2f, -2f);
            portraitFrame.transform.SetAsFirstSibling();
            var portraitOutline = portraitFrame.gameObject.AddComponent<Outline>();
            portraitOutline.effectColor = new Color32(216, 173, 84, 175);
            portraitOutline.effectDistance = new Vector2(2f, -2f);

            if (portrait != null)
            {
                var portraitImage = CreatePanel(
                    portraitFrame.transform,
                    "Komutan Portresi",
                    Color.white);
                portraitImage.sprite = portrait;
                portraitImage.preserveAspect = true;
                Stretch(portraitImage.rectTransform, 1f, 1f, 1f, 1f);
            }

            var cooldownMask = CreatePanel(
                button.transform,
                "Yetenek Bekleme Perdesi",
                new Color32(3, 7, 10, 188));
            Stretch(cooldownMask.rectTransform, 2f, 2f, 2f, 2f);
            cooldownMask.type = Image.Type.Filled;
            cooldownMask.fillMethod = Image.FillMethod.Radial360;
            cooldownMask.fillOrigin = (int)Image.Origin360.Top;
            cooldownMask.fillClockwise = true;
            cooldownMask.fillAmount = 0f;
            cooldownMask.transform.SetSiblingIndex(
                Mathf.Max(0, button.transform.childCount - 2));

            commandVisuals[command] = new CommandVisual
            {
                button = button,
                label = labelText,
                cooldownMask = cooldownMask,
                readyLabel = label
            };
        }

        private void ShowDeployment()
        {
            deploymentOverlay = CreatePanel(
                transform,
                "Savaş Düzeni Seçimi",
                new Color32(5, 10, 14, 255)).gameObject;
            deploymentOverlay.GetComponent<Image>().raycastTarget = true;
            var overlayRect = (RectTransform)deploymentOverlay.transform;
            Stretch(overlayRect);
            deploymentOverlay.transform.SetAsLastSibling();

            var keyArtObject = new GameObject(
                "V28 Altın Sefer Kuşatma Brifingi",
                typeof(RectTransform),
                typeof(RawImage),
                typeof(AspectRatioFitter));
            keyArtObject.transform.SetParent(deploymentOverlay.transform, false);
            var keyArt = keyArtObject.GetComponent<RawImage>();
            keyArt.texture = Resources.Load<Texture2D>("Art/cihan-battlefield-v28") ??
                             Resources.Load<Texture2D>("Art/cihan-siege-v26") ??
                             Resources.Load<Texture2D>("Art/cihan-siege-v21");
            keyArt.color = Color.white;
            keyArt.raycastTarget = false;
            Stretch(keyArt.rectTransform);
            var keyArtAspect = keyArtObject.GetComponent<AspectRatioFitter>();
            keyArtAspect.aspectMode = AspectRatioFitter.AspectMode.EnvelopeParent;
            keyArtAspect.aspectRatio = 1024f / 1536f;

            var keyArtShade = CreatePanel(
                deploymentOverlay.transform,
                "Kuşatma Brifingi Gölgesi",
                new Color32(3, 8, 12, 112));
            Stretch(keyArtShade.rectTransform);

            var orderShade = CreatePanel(
                deploymentOverlay.transform,
                "Savaş Meclisi Altlığı",
                new Color32(5, 10, 14, 218));
            orderShade.rectTransform.anchorMin = new Vector2(0.055f, 0.075f);
            orderShade.rectTransform.anchorMax = new Vector2(0.945f, 0.62f);
            orderShade.rectTransform.offsetMin = Vector2.zero;
            orderShade.rectTransform.offsetMax = Vector2.zero;

            var eyebrow = CreateText(
                deploymentOverlay.transform,
                $"{battleStage.region} · SAVAŞ MECLİSİ",
                15,
                Muted,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            eyebrow.rectTransform.anchorMin = new Vector2(0.08f, 0.84f);
            eyebrow.rectTransform.anchorMax = new Vector2(0.92f, 0.90f);
            eyebrow.rectTransform.offsetMin = Vector2.zero;
            eyebrow.rectTransform.offsetMax = Vector2.zero;

            var title = CreateText(
                deploymentOverlay.transform,
                "ORDU DÜZENİNİ MÜHÜRLE",
                32,
                Gold,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            title.rectTransform.anchorMin = new Vector2(0.06f, 0.74f);
            title.rectTransform.anchorMax = new Vector2(0.94f, 0.84f);
            title.rectTransform.offsetMin = Vector2.zero;
            title.rectTransform.offsetMax = Vector2.zero;

            var description = CreateText(
                deploymentOverlay.transform,
                $"Gücün {game.State.FormationPower:N0} · Düşman {battleStage.recommendedPower:N0} · " +
                $"{game.State.FormationAdvantageForTier(battleStage.enemyTier)} · " +
                $"Keşif: {EnemyPreview(battleStage.enemyTier)}" +
                (string.IsNullOrWhiteSpace(intrigueReport)
                    ? string.Empty
                    : $" · Divan: {intrigueReport}"),
                16,
                Ivory,
                TextAnchor.MiddleCenter,
                FontStyle.Normal);
            description.rectTransform.anchorMin = new Vector2(0.10f, 0.66f);
            description.rectTransform.anchorMax = new Vector2(0.90f, 0.74f);
            description.rectTransform.offsetMin = Vector2.zero;
            description.rectTransform.offsetMax = Vector2.zero;

            CreateFormationCard(
                BattleFormation.Crescent,
                "☾  HİLAL TAKTİĞİ",
                "Okçuların menzili %26, hasarı %14 artar.",
                0.51f,
                0.64f,
                new Color32(54, 77, 73, 255));
            CreateFormationCard(
                BattleFormation.ShieldWall,
                "⬟  KALKAN DUVARI",
                "Piyadeler %22 daha dayanıklı başlar.",
                0.35f,
                0.48f,
                new Color32(43, 68, 85, 255));
            CreateFormationCard(
                BattleFormation.LightningRaid,
                "♞  YILDIRIM BASKINI",
                "Süvarilerin hızı %34, hasarı %18 artar.",
                0.19f,
                0.32f,
                new Color32(94, 61, 38, 255));

            var hint = CreateText(
                deploymentOverlay.transform,
                "Düzen seçildikten sonra değiştirilemez.",
                14,
                Muted,
                TextAnchor.MiddleCenter,
                FontStyle.Italic);
            hint.rectTransform.anchorMin = new Vector2(0.10f, 0.10f);
            hint.rectTransform.anchorMax = new Vector2(0.90f, 0.16f);
            hint.rectTransform.offsetMin = Vector2.zero;
            hint.rectTransform.offsetMax = Vector2.zero;
        }

        private void CreateFormationCard(
            BattleFormation formation,
            string title,
            string description,
            float anchorMinY,
            float anchorMaxY,
            Color color)
        {
            var saved = FormationKey(formation) == game.State.formationDoctrine;
            var button = CreateButton(
                deploymentOverlay.transform,
                $"{title}{(saved ? "  ·  MÜHÜRLÜ" : string.Empty)}\n{description}",
                () => SelectFormation(formation),
                saved ? new Color32(139, 92, 32, 255) : color,
                18);
            var rect = button.GetComponent<RectTransform>();
            rect.anchorMin = new Vector2(0.10f, anchorMinY);
            rect.anchorMax = new Vector2(0.90f, anchorMaxY);
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;
        }

        private void SelectFormation(BattleFormation formation)
        {
            if (!simulation.ApplyFormation(formation))
            {
                return;
            }

            game.State.SetFormationDoctrine(FormationKey(formation));
            game.SaveNow();
            battleStarted = true;
            selectedSquadKind = BattleUnitKind.Infantry;
            PulseHaptic();
            battleMessage.text = formation switch
            {
                BattleFormation.Crescent => "HİLAL DÜZENİ ALINDI · OKÇULAR HAZIR",
                BattleFormation.ShieldWall => "KALKANLAR KENETLENDİ · HAT İLERLİYOR",
                BattleFormation.LightningRaid => "YILDIRIM BASKINI · SÜVARİLER İLERİ",
                _ => "ORDU İLERLİYOR"
            };
            formationText.text = formation switch
            {
                BattleFormation.Crescent => "☾ HİLAL TAKTİĞİ",
                BattleFormation.ShieldWall => "⬟ KALKAN DUVARI",
                BattleFormation.LightningRaid => "♞ YILDIRIM BASKINI",
                _ => "SAVAŞ DÜZENİ"
            };
            Destroy(deploymentOverlay);
            deploymentOverlay = null;
            SyncUnitVisuals();
            UpdateCommandButtons();
            RefreshTacticalSelection();
        }

        private static string FormationKey(BattleFormation formation)
        {
            return formation switch
            {
                BattleFormation.ShieldWall => "shield",
                BattleFormation.LightningRaid => "raid",
                _ => "crescent"
            };
        }

        private static string EnemyPreview(int tier)
        {
            return tier switch
            {
                1 => "ağır piyade · mızraklı hat · karşı hücum",
                2 => "seçkin muhafız · süvari kanadı · topçu",
                3 => "iki savunma hattı · uzun menzil · takviye",
                4 => "zırhlı muhafız · yoğun okçu · ağır topçu",
                5 => "bölüm sonu kumandanı · seçkin süvari · Şahi bataryası",
                _ => "piyade hattı · okçu kulesi · kale beyi"
            };
        }

        private static bool HasCommandLineFlag(string flag)
        {
            return Array.Exists(
                Environment.GetCommandLineArgs(),
                item => string.Equals(
                    item,
                    flag,
                    StringComparison.OrdinalIgnoreCase));
        }

        private static void PulseHaptic()
        {
#if (UNITY_ANDROID || UNITY_IOS) && !UNITY_EDITOR
            Handheld.Vibrate();
#endif
        }

        private void AddReinforcementButton(
            Transform parent,
            BattleUnitKind kind,
            string label)
        {
            Button button = null;
            button = CreateButton(
                parent,
                label,
                () =>
                {
                    if (!deployed.Add(kind))
                    {
                        return;
                    }

                    simulation.DeployReinforcement(kind);
                    button.interactable = false;
                    battleMessage.text = $"{KindTitle(kind)} TAKVİYESİ SAHAYA GİRDİ";
                    SyncUnitVisuals();
                },
                new Color32(40, 76, 73, 255),
                18);
        }

        private void SyncUnitVisuals()
        {
            battleWorld?.Sync();
            foreach (var unit in simulation.Units)
            {
                if (!visuals.TryGetValue(unit.id, out var visual))
                {
                    visual = CreateUnitVisual(unit);
                    visuals[unit.id] = visual;
                }

                if (battleWorld != null &&
                    battleWorld.TryGetViewportPosition(unit.id, out var viewport))
                {
                    visual.rect.anchorMin = viewport;
                    visual.rect.anchorMax = viewport;
                    visual.rect.anchoredPosition = Vector2.zero;
                }

                visual.health.rectTransform.anchorMax =
                    new Vector2(unit.HealthRatio, 1f);
                if (visual.strength != null)
                {
                    visual.strength.text =
                        $"{KindBadge(visual.kind)} {Mathf.CeilToInt(unit.hp):N0}";
                }
                // V17'de birlik liderlerini görünür kıl: hedeflenen dikey savaş
                // dilinde portre, güç sayısı ve can çubuğu birlikte okunur.
                visual.rect.gameObject.SetActive(
                    unit.Alive &&
                    (unit.kind == BattleUnitKind.Siege ||
                     unit.kind == BattleUnitKind.Commander ||
                     unit.id % 4 == 0));
            }

            RefreshTacticalSelection();
        }

        private UnitVisual CreateUnitVisual(BattleUnit unit)
        {
            var root = new GameObject(
                $"{KindTitle(unit.kind)} Manga Canı {unit.id}",
                typeof(RectTransform),
                typeof(Image));
            root.transform.SetParent(unitLayer, false);
            var rect = (RectTransform)root.transform;
            rect.sizeDelta = new Vector2(92f, 9f);

            var healthTrack = root.GetComponent<Image>();
            healthTrack.color = new Color32(18, 20, 21, 235);
            healthTrack.raycastTarget = false;

            var marker = CreatePanel(
                root.transform,
                "Birlik Komutanı",
                unit.team == BattleTeam.Friendly
                    ? new Color32(25, 82, 175, 202)
                    : new Color32(128, 28, 35, 188));
            marker.rectTransform.anchorMin = new Vector2(0.5f, 0.5f);
            marker.rectTransform.anchorMax = new Vector2(0.5f, 0.5f);
            marker.rectTransform.sizeDelta = new Vector2(62f, 28f);
            marker.rectTransform.anchoredPosition = new Vector2(0f, 26f);
            var markerOutline = marker.gameObject.AddComponent<Outline>();
            markerOutline.effectColor = Gold;
            markerOutline.effectDistance = new Vector2(1f, -1f);
            markerOutline.useGraphicAlpha = true;
            marker.raycastTarget = true;
            var markerButton = marker.gameObject.AddComponent<Button>();
            markerButton.targetGraphic = marker;
            markerButton.transition = Selectable.Transition.ColorTint;
            markerButton.onClick.AddListener(() => HandleUnitMarkerPressed(unit.id));

            var markerText = CreateText(
                marker.transform,
                $"{KindBadge(unit.kind)} {Mathf.CeilToInt(unit.hp):N0}",
                10,
                Ivory,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            Stretch(markerText.rectTransform, 2f, 2f, 1f, 1f);

            var health = CreatePanel(
                root.transform,
                "Can",
                unit.team == BattleTeam.Friendly ? FriendlyBright : EnemyBright);
            health.rectTransform.anchorMin = Vector2.zero;
            health.rectTransform.anchorMax = Vector2.one;
            health.rectTransform.offsetMin = Vector2.zero;
            health.rectTransform.offsetMax = Vector2.zero;

            return new UnitVisual
            {
                rect = rect,
                health = health,
                strength = markerText,
                markerOutline = markerOutline,
                team = unit.team,
                kind = unit.kind
            };
        }

        private void HandleUnitMarkerPressed(int unitId)
        {
            if (!battleStarted || !simulation.TryGetUnit(unitId, out var unit) || !unit.Alive)
            {
                return;
            }

            if (unit.team == BattleTeam.Friendly)
            {
                selectedSquadKind = unit.kind;
                tacticalOrderText.text = $"{KindTitle(unit.kind)}\nHEDEF SEÇ";
                battleMessage.text = $"{KindTitle(unit.kind)} MANGASI SEÇİLDİ · DÜŞMANA DOKUN";
                RefreshTacticalSelection();
                PulseHaptic();
                return;
            }

            if (!selectedSquadKind.HasValue ||
                !simulation.IssueFocusOrder(selectedSquadKind.Value, unit.id))
            {
                return;
            }

            tacticalOrderText.text =
                $"{KindTitle(selectedSquadKind.Value)}\n→ {KindTitle(unit.kind)}";
            battleMessage.text =
                $"{KindTitle(selectedSquadKind.Value)} · {KindTitle(unit.kind)} HEDEF ALINDI";
            PulseHaptic();
        }

        private void RefreshTacticalSelection()
        {
            foreach (var visual in visuals.Values)
            {
                if (visual.markerOutline == null)
                {
                    continue;
                }

                var selected = visual.team == BattleTeam.Friendly &&
                               selectedSquadKind.HasValue &&
                               visual.kind == selectedSquadKind.Value;
                visual.markerOutline.effectColor = selected
                    ? new Color32(255, 230, 135, 255)
                    : Gold;
                visual.markerOutline.effectDistance = selected
                    ? new Vector2(5f, -5f)
                    : new Vector2(2f, -2f);
            }
        }

        private Sprite UnitPortrait(BattleUnit unit)
        {
            return unit.kind switch
            {
                BattleUnitKind.Archer => archerPortrait ?? leylaPortrait,
                BattleUnitKind.Cavalry => cavalryPortrait ?? aybarsPortrait,
                BattleUnitKind.Siege => siegePortrait ?? nizamPortrait,
                BattleUnitKind.Commander => commanderPortrait ??
                    (unit.team == BattleTeam.Friendly
                        ? aybarsPortrait
                        : nizamPortrait),
                _ => infantryPortrait ?? nizamPortrait
            };
        }

        private static string KindBadge(BattleUnitKind kind)
        {
            return kind switch
            {
                BattleUnitKind.Archer => "OK",
                BattleUnitKind.Cavalry => "SV",
                BattleUnitKind.Siege => "ŞH",
                BattleUnitKind.Commander => "KM",
                _ => "PY"
            };
        }

        private void RefreshHud()
        {
            timerText.text =
                $"{(int)simulation.Elapsed / 60:00}:{(int)simulation.Elapsed % 60:00}";
            friendlyText.text = $"CİHAN  {simulation.FriendlyAlive}";
            enemyText.text =
                $"{simulation.EnemyAlive}  HİSAR\n" +
                $"KALE BEYİ %{simulation.EnemyCommanderHealthRatio * 100f:0}";
            if (simulation.Clashes > 0 && simulation.Clashes < 8)
            {
                battleMessage.text = "HATLAR ÇARPIŞTI";
            }
            else if (simulation.Clashes >= 8)
            {
                battleMessage.text =
                    $"ÇARPIŞMA {simulation.Clashes:N0} · DÜŞMAN KAYBI {simulation.FriendlyKills}";
            }

            switch (simulation.LastCommand)
            {
                case BattleCommand.EnemyReinforcement:
                    battleMessage.text = "DÜŞMAN TAKVİYESİ KALE KAPISINDAN ÇIKTI";
                    break;
                case BattleCommand.EnemyShieldWall:
                    battleMessage.text = "DÜŞMAN KALKAN DUVARI KURDU · KANATLARA YÖNEL";
                    break;
                case BattleCommand.EnemyArrowVolley:
                    battleMessage.text = "DÜŞMAN OK YAĞMURU · KALKANLARI KALDIR";
                    break;
                case BattleCommand.EnemyCharge:
                    battleMessage.text = "DÜŞMAN HÜCUMU · HATTI TUT";
                    break;
            }

            timerText.text =
                $"{(int)simulation.Elapsed / 60:00}:{(int)simulation.Elapsed % 60:00}\n" +
                $"MORAL %{simulation.FriendlyMorale:0}";
            if (moraleFill != null)
            {
                moraleFill.anchorMax = new Vector2(
                    Mathf.Clamp01(simulation.FriendlyMorale / 100f),
                    1f);
            }

            if (commanderFill != null)
            {
                commanderFill.anchorMax = new Vector2(
                    Mathf.Clamp01(simulation.EnemyCommanderHealthRatio),
                    1f);
            }
            if (siegeProgressText != null)
            {
                siegeProgressText.text =
                    $"HİSAR SAVUNMASI  %{simulation.EnemyCommanderHealthRatio * 100f:0}";
            }
            UpdateCommandButtons();
        }

        private void UpdateCommandButtons()
        {
            UpdateCommandButton(
                BattleCommand.Charge,
                simulation.CanIssueCharge,
                simulation.ChargeCooldown,
                simulation.ChargeSeconds);
            UpdateCommandButton(
                BattleCommand.ShieldWall,
                simulation.CanRaiseShieldWall,
                simulation.ShieldWallCooldown,
                simulation.ShieldWallSeconds);
            UpdateCommandButton(
                BattleCommand.ArrowVolley,
                simulation.CanLaunchArrowVolley,
                simulation.ArrowVolleyCooldown,
                0f);
            UpdateCommandButton(
                BattleCommand.CannonBarrage,
                simulation.CanLaunchCannonBarrage,
                simulation.CannonBarrageCooldown,
                0f);
            UpdateCommandButton(
                BattleCommand.Rally,
                simulation.CanRally,
                0f,
                0f);

            if (simulation.RallyUsed &&
                commandVisuals.TryGetValue(BattleCommand.Rally, out var rally))
            {
                rally.label.text = $"{rally.readyLabel}\nKULLANILDI";
                rally.cooldownMask.fillAmount = 1f;
            }
        }

        private void UpdateCommandButton(
            BattleCommand command,
            bool canUse,
            float cooldown,
            float activeSeconds)
        {
            if (!commandVisuals.TryGetValue(command, out var visual))
            {
                return;
            }

            visual.button.interactable = canUse;
            if (visual.cooldownMask != null)
            {
                var duration = CommandCooldownDuration(command);
                visual.cooldownMask.fillAmount =
                    duration > 0f ? Mathf.Clamp01(cooldown / duration) : 0f;
            }
            if (activeSeconds > 0f)
            {
                visual.label.text = $"{visual.readyLabel}\nAKTİF {activeSeconds:0.0}";
            }
            else if (cooldown > 0f)
            {
                visual.label.text = $"{visual.readyLabel}\n{cooldown:0.0} sn";
            }
            else
            {
                visual.label.text = visual.readyLabel;
            }
        }

        private static float CommandCooldownDuration(BattleCommand command)
        {
            return command switch
            {
                BattleCommand.Charge => 14f,
                BattleCommand.ShieldWall => 15f,
                BattleCommand.ArrowVolley => 12f,
                BattleCommand.CannonBarrage => 22f,
                _ => 0f
            };
        }

        private static string CommandMessage(BattleCommand command)
        {
            return command switch
            {
                BattleCommand.Charge => "HÜCUM BORUSU ÇALDI · İLERİ!",
                BattleCommand.ShieldWall => "KALKANLAR KENETLENDİ",
                BattleCommand.ArrowVolley => "GÖĞÜ OKLARLA KARARTIN!",
                BattleCommand.CannonBarrage => "ŞAHİ TOPLARI · ATEŞ!",
                BattleCommand.Rally => "CİHAT NARASI · ORDU YENİDEN AYAĞA KALKTI",
                _ => "EMİR UYGULANDI"
            };
        }

        private void ShowResult()
        {
            if (resultShown)
            {
                return;
            }

            resultShown = true;
            CihanAudioDirector.Instance?.PlayOutcome(simulation.Victory);
            resultOverlay = CreatePanel(
                transform,
                "Savaş Sonucu",
                new Color32(5, 9, 12, 244)).gameObject;
            var resultRect = (RectTransform)resultOverlay.transform;
            Stretch(resultRect);
            resultOverlay.transform.SetAsLastSibling();

            var resultTitle = CreateText(
                resultOverlay.transform,
                simulation.Victory ? "ZAFER" : "GERİ ÇEKİLME",
                72,
                simulation.Victory ? Gold : EnemyBright,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            resultTitle.rectTransform.anchorMin = new Vector2(0.08f, 0.58f);
            resultTitle.rectTransform.anchorMax = new Vector2(0.92f, 0.78f);
            resultTitle.rectTransform.offsetMin = Vector2.zero;
            resultTitle.rectTransform.offsetMax = Vector2.zero;

            var report = CreateText(
                resultOverlay.transform,
                (simulation.Victory
                    ? $"{new string('★', simulation.StarRating)}" +
                      $"{new string('☆', 3 - simulation.StarRating)}\n\n"
                    : string.Empty) +
                $"{battleStage.title} sona erdi.\n\n" +
                $"Düşman kaybı  {simulation.FriendlyKills}\n" +
                $"CİHAN kaybı  {simulation.FriendlyCasualties}\n" +
                $"Savaş süresi  {simulation.Elapsed:0.0} sn\n\n" +
                (simulation.Victory
                    ? RewardText(battleStage.reward)
                    : "Yaralılar Darüşşifa'ya taşınacak."),
                27,
                Ivory,
                TextAnchor.MiddleCenter,
                FontStyle.Normal);
            report.rectTransform.anchorMin = new Vector2(0.08f, 0.30f);
            report.rectTransform.anchorMax = new Vector2(0.92f, 0.60f);
            report.rectTransform.offsetMin = Vector2.zero;
            report.rectTransform.offsetMax = Vector2.zero;

            var collect = CreateButton(
                resultOverlay.transform,
                simulation.Victory ? "GANİMETİ BAŞKENTE TAŞI" : "ORDUYU TOPARLA",
                CompleteBattle,
                simulation.Victory
                    ? new Color32(133, 91, 36, 255)
                    : new Color32(71, 79, 83, 255),
                25);
            collect.GetComponent<RectTransform>().anchorMin = new Vector2(0.12f, 0.14f);
            collect.GetComponent<RectTransform>().anchorMax = new Vector2(0.88f, 0.25f);
            collect.GetComponent<RectTransform>().offsetMin = Vector2.zero;
            collect.GetComponent<RectTransform>().offsetMax = Vector2.zero;
        }

        private void CompleteBattle()
        {
            if (resultApplied)
            {
                return;
            }

            resultApplied = true;
            game.ApplyBattleResult(
                simulation.Victory,
                simulation.FriendlyCasualties,
                simulation.FriendlyKills,
                battleStage.id,
                simulation.StarRating);
            closed?.Invoke();
            Destroy(gameObject);
        }

        private void OnDestroy()
        {
            CihanAudioDirector.Instance?.LeaveBattle();
            if (battleRender != null)
            {
                battleRender.Release();
                Destroy(battleRender);
            }

            foreach (var portrait in runtimePortraits)
            {
                if (portrait != null)
                {
                    Destroy(portrait);
                }
            }
        }

        private Sprite LoadPortrait(string resourcePath)
        {
            var texture = Resources.Load<Texture2D>(resourcePath);
            if (texture == null)
            {
                return null;
            }

            var portrait = Sprite.Create(
                texture,
                new Rect(0f, 0f, texture.width, texture.height),
                new Vector2(0.5f, 0.5f),
                100f);
            portrait.name = texture.name;
            runtimePortraits.Add(portrait);
            return portrait;
        }

        private static string RewardText(ResourceCost reward)
        {
            var parts = new List<string>();
            if (reward.food > 0) parts.Add($"{reward.food:N0} erzak");
            if (reward.wood > 0) parts.Add($"{reward.wood:N0} kereste");
            if (reward.stone > 0) parts.Add($"{reward.stone:N0} taş");
            if (reward.gold > 0) parts.Add($"{reward.gold:N0} altın");
            return string.Join(" · ", parts);
        }

        private Image CreatePanel(Transform parent, string name, Color color)
        {
            var panel = new GameObject(name, typeof(RectTransform), typeof(Image));
            panel.transform.SetParent(parent, false);
            var image = panel.GetComponent<Image>();
            image.color = color;
            image.raycastTarget = false;
            return image;
        }

        private Text CreateText(
            Transform parent,
            string value,
            int size,
            Color color,
            TextAnchor alignment,
            FontStyle style)
        {
            var textObject = new GameObject("Metin", typeof(RectTransform), typeof(Text));
            textObject.transform.SetParent(parent, false);
            var text = textObject.GetComponent<Text>();
            text.font = font;
            text.text = value;
            text.fontSize = size;
            text.color = color;
            text.alignment = alignment;
            text.fontStyle = style;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Truncate;
            text.raycastTarget = false;
            var shadow = textObject.AddComponent<Shadow>();
            shadow.effectColor = new Color32(0, 0, 0, 190);
            shadow.effectDistance = new Vector2(2f, -2f);
            shadow.useGraphicAlpha = true;
            return text;
        }

        private Button CreateButton(
            Transform parent,
            string label,
            UnityEngine.Events.UnityAction action,
            Color color,
            int fontSize)
        {
            var buttonObject = new GameObject(
                $"{label} Düğmesi",
                typeof(RectTransform),
                typeof(Image),
                typeof(Button));
            buttonObject.transform.SetParent(parent, false);
            var image = buttonObject.GetComponent<Image>();
            image.color = color;
            var outline = buttonObject.AddComponent<Outline>();
            outline.effectColor = new Color32(218, 172, 79, 150);
            outline.effectDistance = new Vector2(2f, -2f);
            outline.useGraphicAlpha = true;
            var button = buttonObject.GetComponent<Button>();
            button.targetGraphic = image;
            button.transition = Selectable.Transition.ColorTint;
            var colors = button.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = new Color32(255, 239, 198, 255);
            colors.pressedColor = new Color32(196, 156, 82, 255);
            colors.selectedColor = colors.highlightedColor;
            colors.disabledColor = new Color32(95, 99, 102, 175);
            colors.colorMultiplier = 1f;
            colors.fadeDuration = 0.08f;
            button.colors = colors;
            button.onClick.AddListener(action);

            var text = CreateText(
                buttonObject.transform,
                label,
                fontSize,
                Ivory,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            Stretch(text.rectTransform, 8f, 8f, 4f, 4f);
            return button;
        }

        private static void SetHudRect(
            RectTransform rect,
            float anchorMinX,
            float anchorMaxX,
            float horizontalOffset)
        {
            rect.anchorMin = new Vector2(anchorMinX, 0f);
            rect.anchorMax = new Vector2(anchorMaxX, 0.58f);
            rect.offsetMin = new Vector2(horizontalOffset, 0f);
            rect.offsetMax = new Vector2(horizontalOffset, 0f);
        }

        private static string KindTitle(BattleUnitKind kind)
        {
            return kind switch
            {
                BattleUnitKind.Infantry => "PİYADE",
                BattleUnitKind.Archer => "OKÇU",
                BattleUnitKind.Cavalry => "SÜVARİ",
                BattleUnitKind.Siege => "ŞAHİ TOPU",
                BattleUnitKind.Commander => "KALE BEYİ",
                _ => "BİRLİK"
            };
        }

        private static void Stretch(
            RectTransform rect,
            float left = 0f,
            float right = 0f,
            float top = 0f,
            float bottom = 0f)
        {
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = new Vector2(left, bottom);
            rect.offsetMax = new Vector2(-right, -top);
        }
    }
}
