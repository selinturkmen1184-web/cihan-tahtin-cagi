using System;
using System.Collections.Generic;
using System.Linq;
using Cihan.Domain;
using Cihan.Services;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Cihan.UI
{
    public static class MobileGameBootstrap
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        private static void Initialize()
        {
            StartupDiagnostics.MarkPhase("mobil_bootstrap");
            try
            {
                InitializeCore();
                StartupDiagnostics.MarkPhase("bootstrap_tamam");
            }
            catch (Exception exception)
            {
                StartupDiagnostics.RecordFatal("mobil_bootstrap", exception);
                Debug.LogException(exception);
                ShowRecoveryScreen(exception);
            }
        }

        private static void InitializeCore()
        {
            Application.targetFrameRate = 60;
            Screen.sleepTimeout = SleepTimeout.NeverSleep;
            EnsurePresentationCamera();

            if (UnityEngine.Object.FindFirstObjectByType<GameService>() == null)
            {
                var root = new GameObject("CİHAN · Mobil MVP");
                root.AddComponent<CihanAudioDirector>();
                root.AddComponent<CihanCloudGateway>();
                root.AddComponent<CihanOnlineGateway>();
                root.AddComponent<GameService>();
                root.AddComponent<CihanGameApp>();
            }

            if (UnityEngine.Object.FindFirstObjectByType<EventSystem>() == null)
            {
                var eventSystem = new GameObject("EventSystem");
                eventSystem.AddComponent<EventSystem>();
                eventSystem.AddComponent<StandaloneInputModule>();
                UnityEngine.Object.DontDestroyOnLoad(eventSystem);
            }
        }

        internal static void ShowRecoveryScreen(Exception exception)
        {
            if (GameObject.Find("CİHAN · Güvenli Açılış") != null)
            {
                return;
            }

            try
            {
                var recovery = new GameObject("CİHAN · Güvenli Açılış");
                UnityEngine.Object.DontDestroyOnLoad(recovery);

                var canvas = recovery.AddComponent<Canvas>();
                canvas.renderMode = RenderMode.ScreenSpaceOverlay;
                canvas.sortingOrder = 32000;
                var scaler = recovery.AddComponent<CanvasScaler>();
                scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
                scaler.referenceResolution = new Vector2(1080f, 1920f);
                recovery.AddComponent<GraphicRaycaster>();

                var backdrop = new GameObject("Arka Plan", typeof(RectTransform));
                backdrop.transform.SetParent(recovery.transform, false);
                var backdropRect = (RectTransform)backdrop.transform;
                backdropRect.anchorMin = Vector2.zero;
                backdropRect.anchorMax = Vector2.one;
                backdropRect.offsetMin = Vector2.zero;
                backdropRect.offsetMax = Vector2.zero;
                var image = backdrop.AddComponent<Image>();
                image.color = new Color32(7, 11, 16, 255);

                var messageObject = new GameObject("Açılış Mesajı", typeof(RectTransform));
                messageObject.transform.SetParent(backdrop.transform, false);
                var messageRect = (RectTransform)messageObject.transform;
                messageRect.anchorMin = new Vector2(0.08f, 0.25f);
                messageRect.anchorMax = new Vector2(0.92f, 0.75f);
                messageRect.offsetMin = Vector2.zero;
                messageRect.offsetMax = Vector2.zero;

                var message = messageObject.AddComponent<Text>();
                message.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
                message.fontSize = 36;
                message.alignment = TextAnchor.MiddleCenter;
                message.color = new Color32(243, 238, 226, 255);
                message.text =
                    "CİHAN güvenli açılış modunda.\n\n" +
                    "Oyun verilerin korundu. Uygulamayı yeniden açmayı dene. " +
                    "Sorun sürerse cihan-startup.log dosyası hatayı gösterecek.\n\n" +
                    $"Hata: {exception.GetType().Name}";
            }
            catch (Exception recoveryException)
            {
                Debug.LogException(recoveryException);
            }
        }

        private static void EnsurePresentationCamera()
        {
            var existingCamera = GameObject.Find("CİHAN · Sunum Kamerası");
            if (existingCamera != null)
            {
                return;
            }

            var cameraObject = new GameObject("CİHAN · Sunum Kamerası")
            {
                tag = "MainCamera"
            };
            var presentationCamera = cameraObject.AddComponent<Camera>();
            cameraObject.transform.position = new Vector3(0f, 0f, -10f);
            presentationCamera.enabled = true;
            presentationCamera.targetDisplay = 0;
            presentationCamera.rect = new Rect(0f, 0f, 1f, 1f);
            presentationCamera.clearFlags = CameraClearFlags.SolidColor;
            presentationCamera.backgroundColor = new Color32(7, 11, 16, 255);
            presentationCamera.cullingMask = -1;
            presentationCamera.depth = -100f;
            UnityEngine.Object.DontDestroyOnLoad(cameraObject);
        }
    }

    public sealed class SafeAreaFitter : MonoBehaviour
    {
        private Rect lastSafeArea;
        private Vector2Int lastScreenSize;

        private void Awake()
        {
            Apply();
        }

        private void Update()
        {
            var currentSize = new Vector2Int(Screen.width, Screen.height);
            if (lastSafeArea != Screen.safeArea || lastScreenSize != currentSize)
            {
                Apply();
            }
        }

        private void Apply()
        {
            var safeArea = Screen.safeArea;
            var rect = (RectTransform)transform;
            var screenWidth = Mathf.Max(1f, Screen.width);
            var screenHeight = Mathf.Max(1f, Screen.height);

            rect.anchorMin = new Vector2(
                safeArea.xMin / screenWidth,
                safeArea.yMin / screenHeight);
            rect.anchorMax = new Vector2(
                safeArea.xMax / screenWidth,
                safeArea.yMax / screenHeight);
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;

            lastSafeArea = safeArea;
            lastScreenSize = new Vector2Int(Screen.width, Screen.height);
        }
    }

    public sealed class CihanGameApp : MonoBehaviour
    {
        private enum ScreenId
        {
            City,
            Army,
            Heroes,
            Map,
            Alliance
        }

        private static readonly Color32 Ink = new(7, 12, 24, 255);
        private static readonly Color32 Panel = new(14, 25, 45, 255);
        private static readonly Color32 PanelSoft = new(24, 43, 76, 255);
        private static readonly Color32 Gold = new(229, 184, 75, 255);
        private static readonly Color32 GoldBright = new(255, 226, 151, 255);
        private static readonly Color32 Ivory = new(247, 239, 220, 255);
        private static readonly Color32 Muted = new(181, 194, 211, 255);
        private static readonly Color32 Teal = new(52, 112, 220, 255);
        private static readonly Color32 Crimson = new(205, 52, 67, 255);

        private readonly Dictionary<ResourceType, Text> resourceTexts = new();
        private readonly Dictionary<ScreenId, Button> navigationButtons = new();

        private GameService game;
        private Font font;
        private RectTransform content;
        private RectTransform overlayRoot;
        private Text powerText;
        private Text eventText;
        private Text screenTitle;
        private Text activeJobDescription;
        private RectTransform activeJobProgress;
        private TimedJob activeJob;
        private Text selectedBuildingText;
        private Button selectedBuildingButton;
        private Button selectedBuildingActionButton;
        private Text selectedCampaignText;
        private Button selectedCampaignButton;
        private ScreenId currentScreen;
        private int renderedScreenRevision;
        private string selectedCityBuildingId = "palace";
        private string selectedCommanderId = "aybars";
        private int selectedCampaignStage;
        private int campaignPage;
        private float cityPanelAccumulator;
        private GameObject campaignCouncilOverlay;
        private Text campaignCouncilStatus;

        private void Start()
        {
            StartupDiagnostics.MarkPhase("arayuz_hazirlaniyor");
            try
            {
                game = GameService.Instance;
                if (game == null)
                {
                    throw new InvalidOperationException("GameService başlatılamadı.");
                }

                font = LoadFont();
                BuildInterface();
                game.Changed += HandleChanged;
                ShowScreen(ResolveStartupScreen());
                if (HasCommandLineFlag("-cihan-start-battle"))
                {
                    CihanBattleView.Show(
                        game,
                        GameRules.Campaign[0],
                        () =>
                        {
                            RefreshHeader();
                            RenderCurrentScreen();
                        });
                }
                else if (HasCommandLineFlag("-cihan-start-council"))
                {
                    ShowCampaignCouncil(0);
                }
                UnityEngine.Rendering.SplashScreen.Stop(
                    UnityEngine.Rendering.SplashScreen.StopBehavior.StopImmediate);
                StartupDiagnostics.MarkReady();
            }
            catch (Exception exception)
            {
                StartupDiagnostics.RecordFatal("arayuz", exception);
                Debug.LogException(exception);
                MobileGameBootstrap.ShowRecoveryScreen(exception);
            }
        }

        private void OnDestroy()
        {
            if (game != null)
            {
                game.Changed -= HandleChanged;
            }
        }

        private static ScreenId ResolveStartupScreen()
        {
            var arguments = Environment.GetCommandLineArgs();
            var index = Array.IndexOf(arguments, "-cihan-start-screen");
            if (index >= 0 && index + 1 < arguments.Length &&
                string.Equals(arguments[index + 1], "map", StringComparison.OrdinalIgnoreCase))
            {
                return ScreenId.Map;
            }

            return ScreenId.City;
        }

        private static bool HasCommandLineFlag(string flag)
        {
            return Array.Exists(
                Environment.GetCommandLineArgs(),
                item => string.Equals(
                    item,
                    flag,
                    StringComparison.OrdinalIgnoreCase));
        }

        private void Update()
        {
            if (currentScreen == ScreenId.City && selectedBuildingActionButton != null)
            {
                cityPanelAccumulator += Time.unscaledDeltaTime;
                if (cityPanelAccumulator >= 1f)
                {
                    cityPanelAccumulator = 0f;
                    UpdateSelectedBuildingPanel();
                }
            }

            if (activeJob == null ||
                activeJobDescription == null ||
                activeJobProgress == null)
            {
                return;
            }

            activeJobDescription.text =
                $"{JobTitle(activeJob)} · {activeJob.SecondsLeft(GameService.Now):00} sn kaldı";
            activeJobProgress.anchorMax =
                new Vector2(activeJob.Progress(GameService.Now), 1f);
        }

        private static Font LoadFont()
        {
            var loaded = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            if (loaded == null)
            {
                loaded = Resources.GetBuiltinResource<Font>("Arial.ttf");
            }

            return loaded;
        }

        private void BuildInterface()
        {
            var canvasObject = new GameObject("Mobil Arayüz");
            canvasObject.transform.SetParent(transform, false);
            var canvas = canvasObject.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 10;

            var scaler = canvasObject.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1080, 1920);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0.5f;
            canvasObject.AddComponent<GraphicRaycaster>();

            var background = CreatePanel(canvasObject.transform, "Arka Plan", Ink);
            Stretch(background.rectTransform);

            var safeArea = CreatePanel(canvasObject.transform, "Güvenli Alan", Color.clear);
            Stretch(safeArea.rectTransform);
            safeArea.gameObject.AddComponent<SafeAreaFitter>();
            overlayRoot = safeArea.rectTransform;

            BuildHeader(safeArea.transform);
            BuildContent(safeArea.transform);
            BuildNavigation(safeArea.transform);
            BuildEventBar(safeArea.transform);
        }

        private void BuildHeader(Transform parent)
        {
            var header = CreatePanel(parent, "Hükümdarlık Başlığı", Panel);
            SetAnchoredRect(
                header.rectTransform,
                new Vector2(0f, 1f),
                new Vector2(1f, 1f),
                new Vector2(0f, 128f),
                new Vector2(0f, -64f));

            var rulerBadge = CreatePanel(
                header.transform,
                "Hükümdar Seviyesi",
                new Color32(41, 61, 105, 255));
            rulerBadge.rectTransform.anchorMin = new Vector2(0.018f, 0.40f);
            rulerBadge.rectTransform.anchorMax = new Vector2(0.085f, 0.95f);
            rulerBadge.rectTransform.offsetMin = Vector2.zero;
            rulerBadge.rectTransform.offsetMax = Vector2.zero;
            var rulerLevel = CreateText(
                rulerBadge.transform,
                "SV 18",
                16,
                GoldBright,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            Stretch(rulerLevel.rectTransform, 4f, 4f, 4f, 4f);

            var brand = CreateText(
                header.transform,
                "CİHAN",
                25,
                Ivory,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            brand.rectTransform.anchorMin = new Vector2(0.10f, 0.58f);
            brand.rectTransform.anchorMax = new Vector2(0.47f, 0.96f);
            brand.rectTransform.offsetMin = Vector2.zero;
            brand.rectTransform.offsetMax = Vector2.zero;

            var subtitle = CreateText(
                header.transform,
                "V28 · ALTIN SEFER",
                13,
                Gold,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            subtitle.resizeTextForBestFit = true;
            subtitle.rectTransform.anchorMin = new Vector2(0.10f, 0.34f);
            subtitle.rectTransform.anchorMax = new Vector2(0.47f, 0.62f);
            subtitle.rectTransform.offsetMin = Vector2.zero;
            subtitle.rectTransform.offsetMax = Vector2.zero;

            var vip = CreatePanel(
                header.transform,
                "VIP Seviyesi",
                new Color32(121, 78, 31, 255));
            vip.rectTransform.anchorMin = new Vector2(0.70f, 0.62f);
            vip.rectTransform.anchorMax = new Vector2(0.81f, 0.94f);
            vip.rectTransform.offsetMin = Vector2.zero;
            vip.rectTransform.offsetMax = Vector2.zero;
            var vipText = CreateText(
                vip.transform,
                "VIP 4",
                13,
                GoldBright,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            Stretch(vipText.rectTransform, 4f, 4f, 2f, 2f);

            powerText = CreateText(
                header.transform,
                "GÜÇ 0",
                15,
                GoldBright,
                TextAnchor.MiddleRight,
                FontStyle.Bold);
            powerText.rectTransform.anchorMin = new Vector2(0.82f, 0.62f);
            powerText.rectTransform.anchorMax = new Vector2(0.98f, 0.94f);
            powerText.rectTransform.offsetMin = Vector2.zero;
            powerText.rectTransform.offsetMax = Vector2.zero;

            var resources = new GameObject("Kaynaklar", typeof(RectTransform));
            resources.transform.SetParent(header.transform, false);
            var resourceRect = (RectTransform)resources.transform;
            resourceRect.anchorMin = new Vector2(0.10f, 0.04f);
            resourceRect.anchorMax = new Vector2(0.98f, 0.33f);
            resourceRect.offsetMin = Vector2.zero;
            resourceRect.offsetMax = Vector2.zero;
            var layout = resources.AddComponent<HorizontalLayoutGroup>();
            layout.spacing = 6f;
            layout.childAlignment = TextAnchor.MiddleCenter;
            layout.childControlWidth = true;
            layout.childControlHeight = true;
            layout.childForceExpandWidth = true;
            layout.childForceExpandHeight = true;

            AddResourceCell(resources.transform, ResourceType.Food, "ERZAK", "●");
            AddResourceCell(resources.transform, ResourceType.Wood, "KERES.", "╱");
            AddResourceCell(resources.transform, ResourceType.Stone, "TAŞ", "◆");
            AddResourceCell(resources.transform, ResourceType.Gold, "ALTIN", "◉");
        }

        private void AddResourceCell(
            Transform parent,
            ResourceType type,
            string label,
            string icon)
        {
            var cell = CreatePanel(parent, $"{label} Kaynağı", PanelSoft);
            var layoutElement = cell.gameObject.AddComponent<LayoutElement>();
            layoutElement.flexibleWidth = 1f;

            var iconText = CreateText(
                cell.transform,
                icon,
                18,
                GoldBright,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            SetAnchoredRect(
                iconText.rectTransform,
                new Vector2(0f, 0f),
                new Vector2(0.3f, 1f),
                Vector2.zero,
                new Vector2(12f, 0f));

            var valueText = CreateText(
                cell.transform,
                $"{label}  0",
                14,
                Ivory,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            valueText.resizeTextForBestFit = true;
            valueText.resizeTextMinSize = 9;
            valueText.resizeTextMaxSize = 14;
            SetAnchoredRect(
                valueText.rectTransform,
                new Vector2(0.28f, 0f),
                new Vector2(1f, 1f),
                new Vector2(-8f, 0f),
                new Vector2(2f, 0f));
            resourceTexts[type] = valueText;
        }

        private void BuildContent(Transform parent)
        {
            var viewport = CreatePanel(parent, "İçerik Alanı", Ink);
            viewport.raycastTarget = true;
            viewport.gameObject.AddComponent<Mask>().showMaskGraphic = false;
            viewport.rectTransform.anchorMin = Vector2.zero;
            viewport.rectTransform.anchorMax = Vector2.one;
            viewport.rectTransform.offsetMin = new Vector2(6f, 116f);
            viewport.rectTransform.offsetMax = new Vector2(-6f, -128f);

            var scroll = viewport.gameObject.AddComponent<ScrollRect>();
            scroll.horizontal = false;
            scroll.vertical = true;
            scroll.movementType = ScrollRect.MovementType.Elastic;
            scroll.scrollSensitivity = 70f;
            scroll.viewport = viewport.rectTransform;

            var contentObject = new GameObject("Akış", typeof(RectTransform));
            contentObject.transform.SetParent(viewport.transform, false);
            content = (RectTransform)contentObject.transform;
            content.anchorMin = new Vector2(0f, 1f);
            content.anchorMax = new Vector2(1f, 1f);
            content.pivot = new Vector2(0.5f, 1f);
            content.offsetMin = Vector2.zero;
            content.offsetMax = Vector2.zero;

            var layout = contentObject.AddComponent<VerticalLayoutGroup>();
            layout.padding = new RectOffset(4, 4, 4, 4);
            layout.spacing = 8f;
            layout.childAlignment = TextAnchor.UpperCenter;
            layout.childControlWidth = true;
            layout.childControlHeight = true;
            layout.childForceExpandWidth = true;
            layout.childForceExpandHeight = false;

            var fitter = contentObject.AddComponent<ContentSizeFitter>();
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
            scroll.content = content;
        }

        private void BuildNavigation(Transform parent)
        {
            var navigation = CreatePanel(parent, "Alt Menü", Panel);
            SetAnchoredRect(
                navigation.rectTransform,
                new Vector2(0f, 0f),
                new Vector2(1f, 0f),
                new Vector2(0f, 88f),
                new Vector2(0f, 44f));

            var layout = navigation.gameObject.AddComponent<HorizontalLayoutGroup>();
            layout.padding = new RectOffset(8, 8, 7, 7);
            layout.spacing = 5f;
            layout.childAlignment = TextAnchor.MiddleCenter;
            layout.childControlWidth = true;
            layout.childControlHeight = true;
            layout.childForceExpandWidth = true;
            layout.childForceExpandHeight = true;

            AddNavigationButton(navigation.transform, ScreenId.City, "♜\nBAŞKENT");
            AddNavigationButton(navigation.transform, ScreenId.Army, "⚔\nORDU");
            AddNavigationButton(navigation.transform, ScreenId.Heroes, "✦\nKOMUTAN");
            AddNavigationButton(navigation.transform, ScreenId.Map, "⌖\nDÜNYA");
            AddNavigationButton(navigation.transform, ScreenId.Alliance, "⚑\nSANCAK");
        }

        private void AddNavigationButton(Transform parent, ScreenId id, string label)
        {
            var button = CreateButton(
                parent,
                label,
                () => ShowScreen(id),
                PanelSoft,
                15);
            navigationButtons[id] = button;
        }

        private void BuildEventBar(Transform parent)
        {
            var bar = CreatePanel(parent, "Haberci", new Color32(21, 29, 36, 255));
            SetAnchoredRect(
                bar.rectTransform,
                new Vector2(0f, 0f),
                new Vector2(1f, 0f),
                new Vector2(0f, 28f),
                new Vector2(0f, 102f));

            eventText = CreateText(
                bar.transform,
                "Payitaht emre hazır.",
                13,
                GoldBright,
                TextAnchor.MiddleCenter,
                FontStyle.Italic);
            eventText.resizeTextForBestFit = true;
            eventText.resizeTextMinSize = 10;
            eventText.resizeTextMaxSize = 13;
            Stretch(eventText.rectTransform, 12f, 12f, 2f, 2f);
        }

        private void ShowScreen(ScreenId id)
        {
            currentScreen = id;
            RefreshHeader();
            foreach (var pair in navigationButtons)
            {
                SetButtonColor(
                    pair.Value,
                    pair.Key == id ? new Color32(102, 73, 33, 255) : PanelSoft);
            }

            RenderCurrentScreen();
        }

        private void RenderCurrentScreen()
        {
            ClearChildren(content);
            screenTitle = null;
            activeJob = null;
            activeJobDescription = null;
            activeJobProgress = null;
            selectedBuildingText = null;
            selectedBuildingButton = null;
            selectedCampaignText = null;
            selectedCampaignButton = null;

            switch (currentScreen)
            {
                case ScreenId.City:
                    RenderCity();
                    break;
                case ScreenId.Army:
                    RenderArmy();
                    break;
                case ScreenId.Heroes:
                    RenderHeroes();
                    break;
                case ScreenId.Map:
                    RenderMap();
                    break;
                case ScreenId.Alliance:
                    RenderAlliance();
                    break;
            }

            LayoutRebuilder.ForceRebuildLayoutImmediate(content);
            renderedScreenRevision = ComputeScreenRevision();
        }

        private void RenderCity()
        {
            AddCityWorldCard();
        }

        private void RenderArmy()
        {
            AddHeroCard(
                "ORDUGÂH · SEFER HAZIRLIĞI",
                "Sancakları Doldur",
                "Dört birlik sınıfını dengeli eğit; her sınıf savaş alanında farklı bir rol üstlenir.",
                Teal);

            AddFormationCommandCard();

            AddSectionTitle(
                "EĞİTİM VE BİRLİKLER",
                $"Toplam güç {game.State.Power:N0} · Yaralı {game.State.wounded:N0}");
            AddJobCard(game.State.training, "EĞİTİM KUYRUĞU", "Kışla yeni birlik emrini bekliyor.");

            foreach (var spec in GameRules.Units)
            {
                var unit = game.State.GetUnit(spec.id);
                var barracksLevel = game.State.GetBuilding("barracks").level;
                var batch = GameRules.TrainingBatch(spec, barracksLevel);
                var duration = GameRules.TrainingDuration(spec, barracksLevel);
                var canTrain = game.State.CanTrainUnit(spec.id);
                AddActionCard(
                    spec.icon,
                    spec.title,
                    $"{unit.count:N0} asker · Kışla {spec.requiredBarracksLevel} gerekir · {spec.description}",
                    $"{CostText(spec.cost)} · +{batch} · {duration} sn · {game.State.UnitTrainingStatus(spec.id)}",
                    barracksLevel >= spec.requiredBarracksLevel ? "EĞİT" : "KİLİTLİ",
                    canTrain,
                    () =>
                    {
                        game.TrainUnit(spec.id);
                        RenderCurrentScreen();
                    });
            }
        }

        private void RenderHeroes()
        {
            var assignedCount = game.State.heroes.Count(item => item.assigned);
            AddHeroCard(
                "DİVAN · KOMUTAN KOLEKSİYONU",
                "İmparatorluk Kumandanları",
                "Portreye dokun, komutanı incele; seviye, yıldız ve teçhizatını geliştir.",
                Gold);

            AddSectionTitle(
                "KOMUTAN GALERİSİ",
                $"{assignedCount}/2 kahraman sefer ordusunda · Güçlü kadro savaş düzenini değiştirir");
            AddCommanderCollectionCard();

            var selectedSpec = GameRules.Heroes.FirstOrDefault(item => item.id == selectedCommanderId)
                               ?? GameRules.Heroes[0];
            selectedCommanderId = selectedSpec.id;
            AddHeroManagementCard(selectedSpec, game.State.GetHero(selectedSpec.id));
        }

        private void RenderMap()
        {
            game.State.EnsureCompatibility();
            game.State.EnsureDailyOrder(GameService.Now);
            selectedCampaignStage = Mathf.Clamp(
                selectedCampaignStage,
                0,
                GameRules.Campaign.Length - 1);
            if (selectedCampaignStage > game.State.campaignProgress)
            {
                selectedCampaignStage = Mathf.Clamp(
                    game.State.campaignProgress,
                    0,
                    GameRules.Campaign.Length - 1);
            }
            var pageCount = Mathf.CeilToInt(GameRules.Campaign.Length / 4f);
            campaignPage = Mathf.Clamp(campaignPage, 0, Mathf.Max(0, pageCount - 1));
            AddCampaignMapCard();
        }

        private void RenderAlliance()
        {
            game.State.EnsureImperialSystems(GameService.Now);
            AddHeroCard(
                $"{game.State.serverRegion} · " +
                (CihanOnlineGateway.Instance?.StatusText ?? "KRALLIK MERKEZİ"),
                game.State.allianceName,
                $"{game.State.allianceMembers}/50 üye · Dünya sırası #{game.State.allianceRank} · " +
                $"{game.State.allianceWarPoints:N0} savaş puanı",
                Crimson);
            AddAllianceProfileCard();
            AddAllianceRallyCard();
            AddAllianceChatCard();
            AddPvpArenaCard();
            AddAllianceLeaderboard();
        }

        private void AddCapitalStatusCard()
        {
            var state = game.State;
            var card = CreatePanel(content, "Payitaht Devlet Raporu", Panel);
            var element = card.gameObject.AddComponent<LayoutElement>();
            element.preferredHeight = 300f;

            var title = CreateText(
                card.transform,
                state.CityEraTitle,
                32,
                GoldBright,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            SetAnchoredRect(
                title.rectTransform,
                new Vector2(0.04f, 0.72f),
                new Vector2(0.96f, 0.96f),
                Vector2.zero,
                Vector2.zero);

            var subtitle = CreateText(
                card.transform,
                "Şehirdeki her yükseltme nüfusu, refahı, üretimi ve askerî hazırlığı değiştirir.",
                20,
                Muted,
                TextAnchor.MiddleLeft,
                FontStyle.Normal);
            SetAnchoredRect(
                subtitle.rectTransform,
                new Vector2(0.04f, 0.57f),
                new Vector2(0.96f, 0.73f),
                Vector2.zero,
                Vector2.zero);

            var row = new GameObject("Devlet Göstergeleri", typeof(RectTransform));
            row.transform.SetParent(card.transform, false);
            SetAnchoredRect(
                (RectTransform)row.transform,
                new Vector2(0.03f, 0.06f),
                new Vector2(0.97f, 0.53f),
                Vector2.zero,
                Vector2.zero);
            var layout = row.AddComponent<HorizontalLayoutGroup>();
            layout.spacing = 10f;
            layout.childControlWidth = true;
            layout.childControlHeight = true;
            layout.childForceExpandWidth = true;
            layout.childForceExpandHeight = true;
            AddMetricCell(row.transform, "NÜFUS", state.Population.ToString("N0"), "♟");
            AddMetricCell(row.transform, "REFAH", $"%{state.Prosperity}", "◈");
            AddMetricCell(row.transform, "BÖLGE", state.TerritoriesControlled.ToString(), "⌖");
            AddMetricCell(
                row.transform,
                "KURUMLAR",
                (state.GetBuilding("academy").level +
                 state.GetBuilding("embassy").level).ToString(),
                "♜");
        }

        private void AddMetricCell(
            Transform parent,
            string label,
            string value,
            string icon)
        {
            var cell = CreatePanel(parent, $"{label} Göstergesi", PanelSoft);
            var iconText = CreateText(
                cell.transform,
                icon,
                24,
                Gold,
                TextAnchor.UpperCenter,
                FontStyle.Bold);
            SetAnchoredRect(
                iconText.rectTransform,
                new Vector2(0f, 0.62f),
                Vector2.one,
                Vector2.zero,
                Vector2.zero);
            var text = CreateText(
                cell.transform,
                $"{label}\n{value}",
                20,
                Ivory,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            text.resizeTextForBestFit = true;
            text.resizeTextMinSize = 12;
            SetAnchoredRect(
                text.rectTransform,
                Vector2.zero,
                new Vector2(1f, 0.70f),
                Vector2.zero,
                Vector2.zero);
        }

        private void AddResearchCard(ResearchSpec research)
        {
            var level = game.State.ResearchLevel(research.id);
            var completed = level >= research.maximumLevel;
            var canResearch = game.State.CanResearch(research.id);
            var status = completed
                ? "USTALIK TAMAM"
                : game.State.research != null
                    ? "ENDERUN MEŞGUL"
                    : $"SV {level + 1} İÇİN ARAŞTIR";
            AddActionCard(
                research.icon,
                $"{research.branch} · {research.title}  {level}/{research.maximumLevel}",
                research.description,
                completed
                    ? "Bütün ilim kademeleri tamamlandı."
                    : $"{CostText(game.State.ResearchCost(research.id))} · " +
                      $"{research.baseDuration + level * 3} sn",
                status,
                canResearch,
                () =>
                {
                    game.BeginResearch(research.id);
                    RenderCurrentScreen();
                });
        }

        private void AddFormationCommandCard()
        {
            var state = game.State;
            var card = CreatePanel(content, "Sefer Formasyonu", Panel);
            var element = card.gameObject.AddComponent<LayoutElement>();
            element.preferredHeight = 900f;

            var title = CreateText(
                card.transform,
                $"SAVAŞ MECLİSİ · {state.FormationDoctrineTitle.ToUpperInvariant()}",
                30,
                GoldBright,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            SetAnchoredRect(
                title.rectTransform,
                new Vector2(0.04f, 0.90f),
                new Vector2(0.96f, 0.98f),
                Vector2.zero,
                Vector2.zero);

            var summary = CreateText(
                card.transform,
                $"Formasyon gücü {state.FormationPower:N0} · Komutan ve birlik kartlarına dokunarak düzeni değiştir.",
                19,
                Muted,
                TextAnchor.MiddleLeft,
                FontStyle.Normal);
            SetAnchoredRect(
                summary.rectTransform,
                new Vector2(0.04f, 0.835f),
                new Vector2(0.96f, 0.91f),
                Vector2.zero,
                Vector2.zero);

            var doctrineRow = new GameObject("Doktrin Seçimi", typeof(RectTransform));
            doctrineRow.transform.SetParent(card.transform, false);
            SetAnchoredRect(
                (RectTransform)doctrineRow.transform,
                new Vector2(0.035f, 0.70f),
                new Vector2(0.965f, 0.82f),
                Vector2.zero,
                Vector2.zero);
            var doctrineLayout = doctrineRow.AddComponent<HorizontalLayoutGroup>();
            doctrineLayout.spacing = 10f;
            doctrineLayout.childControlWidth = true;
            doctrineLayout.childControlHeight = true;
            doctrineLayout.childForceExpandWidth = true;
            doctrineLayout.childForceExpandHeight = true;
            AddDoctrineButton(doctrineRow.transform, "crescent", "☾\nHİLAL");
            AddDoctrineButton(doctrineRow.transform, "shield", "⬟\nKALKAN");
            AddDoctrineButton(doctrineRow.transform, "raid", "♞\nYILDIRIM");

            for (var slot = 0; slot < 3; slot += 1)
            {
                AddFormationSlot(card.transform, slot, 0.49f - slot * 0.20f);
            }

            var counter = CreateText(
                card.transform,
                "KARŞITLIK: Hilal > Kalkan · Kalkan > Yıldırım · Yıldırım > Hilal",
                19,
                Gold,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            SetAnchoredRect(
                counter.rectTransform,
                new Vector2(0.04f, 0.02f),
                new Vector2(0.96f, 0.10f),
                Vector2.zero,
                Vector2.zero);
        }

        private void AddDoctrineButton(Transform parent, string doctrine, string label)
        {
            var selected = game.State.formationDoctrine == doctrine;
            CreateButton(
                parent,
                label,
                () =>
                {
                    game.SetFormationDoctrine(doctrine);
                    RenderCurrentScreen();
                },
                selected
                    ? new Color32(139, 92, 32, 255)
                    : new Color32(44, 56, 61, 255),
                18);
        }

        private void AddFormationSlot(Transform parent, int slot, float anchorMinY)
        {
            var heroId = game.State.formationHeroes[slot];
            var unitId = game.State.formationUnits[slot];
            var heroSpec = GameRules.Heroes.First(item => item.id == heroId);
            var unitSpec = GameRules.Units.First(item => item.id == unitId);
            var row = CreatePanel(
                parent,
                $"Formasyon Hattı {slot + 1}",
                slot == 0
                    ? new Color32(27, 55, 56, 255)
                    : new Color32(24, 34, 42, 255));
            SetAnchoredRect(
                row.rectTransform,
                new Vector2(0.035f, anchorMinY),
                new Vector2(0.965f, anchorMinY + 0.17f),
                Vector2.zero,
                Vector2.zero);

            var text = CreateText(
                row.transform,
                $"{slot + 1}. HAT · {heroSpec.name.ToUpperInvariant()}\n" +
                $"{unitSpec.title} · {game.State.GetUnit(unitId).count:N0} mevcut · " +
                $"Kumandan {game.State.CommanderPower(heroId):N0}",
                20,
                Ivory,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            text.resizeTextForBestFit = true;
            text.resizeTextMinSize = 14;
            SetAnchoredRect(
                text.rectTransform,
                new Vector2(0.03f, 0f),
                new Vector2(0.60f, 1f),
                Vector2.zero,
                Vector2.zero);

            var heroButton = CreateButton(
                row.transform,
                "KOMUTAN ↻",
                () =>
                {
                    game.CycleFormationHero(slot);
                    RenderCurrentScreen();
                },
                new Color32(72, 57, 38, 255),
                16);
            SetAnchoredRect(
                heroButton.GetComponent<RectTransform>(),
                new Vector2(0.62f, 0.53f),
                new Vector2(0.97f, 0.94f),
                Vector2.zero,
                Vector2.zero);

            var unitButton = CreateButton(
                row.transform,
                "BİRLİK ↻",
                () =>
                {
                    game.CycleFormationUnit(slot);
                    RenderCurrentScreen();
                },
                new Color32(42, 70, 73, 255),
                16);
            SetAnchoredRect(
                unitButton.GetComponent<RectTransform>(),
                new Vector2(0.62f, 0.06f),
                new Vector2(0.97f, 0.47f),
                Vector2.zero,
                Vector2.zero);
        }

        private void AddWorldOperations()
        {
            AddSectionTitle(
                "AÇIK DÜNYA SEFERLERİ",
                $"{game.State.TerritoriesControlled}/{ImperialRules.WorldNodes.Length} bölge · " +
                "keşif, yürüyüş ve kaynak devriyesi");
            AddJobCard(
                game.State.worldMarch,
                "YÜRÜYÜŞ KOLU",
                "Dünya haritasında yeni bir hedef seç ve sancak ordusunu gönder.");

            for (var index = 0; index < ImperialRules.WorldNodes.Length; index += 1)
            {
                var nodeIndex = index;
                var node = ImperialRules.WorldNodes[nodeIndex];
                var unlocked = game.State.IsWorldNodeUnlocked(nodeIndex);
                var scouted = game.State.IsWorldNodeScouted(nodeIndex);
                var claimed = game.State.IsWorldNodeClaimed(nodeIndex);
                var marching = game.State.worldMarch != null;
                var action = !unlocked
                    ? "YOL KAPALI"
                    : !scouted
                        ? "90 ALTIN · KEŞFET"
                        : claimed
                            ? "DEVRİYE GÖNDER"
                            : "SANCAĞI GÖNDER";
                AddActionCard(
                    node.icon,
                    $"{node.region} · {node.title}",
                    scouted
                        ? $"{node.kind} · {node.defenders} · Güç {node.recommendedPower:N0}"
                        : "Savunma bilinmiyor · önce Akıncı keşfi gönder.",
                    claimed
                        ? $"FETHEDİLDİ · {new string('★', game.State.worldNodeStars[nodeIndex])} · " +
                          $"{CostText(node.reward)}"
                        : $"{node.marchFood:N0} erzak · {node.duration} sn · {CostText(node.reward)}",
                    action,
                    unlocked && (!scouted || !marching),
                    () =>
                    {
                        if (!game.State.IsWorldNodeScouted(nodeIndex))
                        {
                            game.ScoutWorldNode(nodeIndex);
                        }
                        else
                        {
                            game.BeginWorldMarch(nodeIndex);
                        }

                        RenderCurrentScreen();
                    });
            }
        }

        private void AddAllianceProfileCard()
        {
            var card = CreatePanel(content, "Sancak Karargâhı", Panel);
            var element = card.gameObject.AddComponent<LayoutElement>();
            element.preferredHeight = 330f;
            var title = CreateText(
                card.transform,
                $"{game.State.accountName} · {game.State.PvpLeague}",
                30,
                Ivory,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            SetAnchoredRect(
                title.rectTransform,
                new Vector2(0.04f, 0.70f),
                new Vector2(0.96f, 0.95f),
                Vector2.zero,
                Vector2.zero);
            var body = CreateText(
                card.transform,
                $"Katkı {game.State.allianceContribution:N0} · Yardım mührü {game.State.allianceHelpTokens} · " +
                $"PvP {game.State.pvpRating} · {game.State.pvpWins}G/{game.State.pvpLosses}M",
                21,
                Muted,
                TextAnchor.MiddleLeft,
                FontStyle.Normal);
            SetAnchoredRect(
                body.rectTransform,
                new Vector2(0.04f, 0.43f),
                new Vector2(0.96f, 0.72f),
                Vector2.zero,
                Vector2.zero);
            var donate = CreateButton(
                card.transform,
                "HAZİNEYE BAĞIŞ",
                () =>
                {
                    game.DonateAlliance();
                    RenderCurrentScreen();
                },
                new Color32(123, 82, 35, 255),
                18);
            SetAnchoredRect(
                donate.GetComponent<RectTransform>(),
                new Vector2(0.04f, 0.08f),
                new Vector2(0.48f, 0.37f),
                Vector2.zero,
                Vector2.zero);
            var help = CreateButton(
                card.transform,
                "İTTİFAK YARDIMI",
                () =>
                {
                    game.RequestAllianceHelp();
                    RenderCurrentScreen();
                },
                new Color32(43, 85, 80, 255),
                18);
            SetAnchoredRect(
                help.GetComponent<RectTransform>(),
                new Vector2(0.52f, 0.08f),
                new Vector2(0.96f, 0.37f),
                Vector2.zero,
                Vector2.zero);
        }

        private void AddAllianceRallyCard()
        {
            var active = game.State.allianceRallyEndsAt > GameService.Now;
            AddActionCard(
                "⚔",
                active
                    ? $"ORTAK SEFER · {game.State.allianceRallyTarget}"
                    : "İTTİFAK ORTAK SEFERİ",
                active
                    ? $"{game.State.AllianceRallySecondsLeft(GameService.Now)} sn sonra birlikler hedefe vuracak."
                    : "İttifak üyelerini aynı hedefe topla; tamamlandığında herkes savaş payı kazanır.",
                active
                    ? $"{game.State.allianceMembers} üye hazırlanıyor"
                    : "700 erzak · ortak ganimet 620 altın · 260+ savaş puanı",
                active ? "ORDULAR TOPLANIYOR" : "ORTAK SEFER BAŞLAT",
                !active,
                () =>
                {
                    game.LaunchAllianceRally();
                    RenderCurrentScreen();
                });
        }

        private void AddAllianceChatCard()
        {
            var card = CreatePanel(content, "Gerçek Zamanlı Sancak Sohbeti", Panel);
            var element = card.gameObject.AddComponent<LayoutElement>();
            element.preferredHeight = 470f;
            var title = CreateText(
                card.transform,
                "SANCAK SOHBETİ · OTOMATİK ÇEVİRİ HAZIR",
                24,
                Gold,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            SetAnchoredRect(
                title.rectTransform,
                new Vector2(0.04f, 0.84f),
                new Vector2(0.96f, 0.97f),
                Vector2.zero,
                Vector2.zero);
            var messages = string.Join(
                "\n\n",
                game.State.allianceChat.Skip(
                    Math.Max(0, game.State.allianceChat.Length - 4)));
            var chat = CreateText(
                card.transform,
                messages,
                19,
                Ivory,
                TextAnchor.UpperLeft,
                FontStyle.Normal);
            SetAnchoredRect(
                chat.rectTransform,
                new Vector2(0.04f, 0.20f),
                new Vector2(0.96f, 0.84f),
                Vector2.zero,
                Vector2.zero);
            var send = CreateButton(
                card.transform,
                "“SEFERE HAZIRIM” MESAJI GÖNDER",
                () =>
                {
                    game.PostAllianceMessage("Sancağım ve ordum ortak sefere hazır!");
                    RenderCurrentScreen();
                },
                new Color32(42, 76, 73, 255),
                17);
            SetAnchoredRect(
                send.GetComponent<RectTransform>(),
                new Vector2(0.12f, 0.04f),
                new Vector2(0.88f, 0.17f),
                Vector2.zero,
                Vector2.zero);
        }

        private void AddPvpArenaCard()
        {
            var opponent = game.State.pvpOpponent;
            var card = CreatePanel(content, "Hudut Meydanı PvP", Panel);
            var element = card.gameObject.AddComponent<LayoutElement>();
            element.preferredHeight = 430f;
            var title = CreateText(
                card.transform,
                opponent == null
                    ? $"HUDUT MEYDANI · {game.State.PvpLeague}"
                    : $"RAKİP BULUNDU · {opponent.name}",
                30,
                GoldBright,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            SetAnchoredRect(
                title.rectTransform,
                new Vector2(0.04f, 0.76f),
                new Vector2(0.96f, 0.95f),
                Vector2.zero,
                Vector2.zero);
            var body = CreateText(
                card.transform,
                opponent == null
                    ? $"Formasyon gücün {game.State.FormationPower:N0} · Derece {game.State.pvpRating}\n" +
                      "Rakip ara, doktrin karşıtlığını değerlendir ve meydan düellosuna gir."
                    : $"{opponent.alliance} · Güç {opponent.power:N0} · Derece {opponent.rating}\n" +
                      $"Rakip düzeni: {DoctrineTitle(opponent.doctrine)} · Ödül {opponent.rewardGold} altın",
                21,
                Ivory,
                TextAnchor.MiddleLeft,
                FontStyle.Normal);
            SetAnchoredRect(
                body.rectTransform,
                new Vector2(0.04f, 0.35f),
                new Vector2(0.96f, 0.76f),
                Vector2.zero,
                Vector2.zero);
            var button = CreateButton(
                card.transform,
                opponent == null ? "120 ERZAK · RAKİP ARA" : "MEYDAN DÜELLOSUNA GİR",
                () =>
                {
                    if (game.State.pvpOpponent == null)
                    {
                        game.SearchPvpOpponent();
                    }
                    else
                    {
                        game.ResolvePvpSkirmish();
                    }

                    RenderCurrentScreen();
                },
                opponent == null
                    ? new Color32(66, 74, 78, 255)
                    : new Color32(139, 52, 48, 255),
                19);
            SetAnchoredRect(
                button.GetComponent<RectTransform>(),
                new Vector2(0.10f, 0.07f),
                new Vector2(0.90f, 0.27f),
                Vector2.zero,
                Vector2.zero);
        }

        private void AddAllianceLeaderboard()
        {
            var card = CreatePanel(content, "İttifak Sıralaması", Panel);
            var element = card.gameObject.AddComponent<LayoutElement>();
            element.preferredHeight = 360f;
            var title = CreateText(
                card.transform,
                "KRALLIK İTTİFAK SIRALAMASI",
                25,
                Gold,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            SetAnchoredRect(
                title.rectTransform,
                new Vector2(0.04f, 0.79f),
                new Vector2(0.96f, 0.96f),
                Vector2.zero,
                Vector2.zero);
            var ranking = CreateText(
                card.transform,
                $"01  BOZKIR OCAĞI              18.420\n" +
                $"02  MAVİ SANCAK                17.960\n" +
                $"03  ŞARK MUHAFIZLARI           16.880\n" +
                $"{game.State.allianceRank:00}  {game.State.allianceName,-26} {game.State.allianceWarPoints,6:N0}",
                20,
                Ivory,
                TextAnchor.UpperLeft,
                FontStyle.Bold);
            SetAnchoredRect(
                ranking.rectTransform,
                new Vector2(0.04f, 0.10f),
                new Vector2(0.96f, 0.79f),
                Vector2.zero,
                Vector2.zero);
        }

        private static string DoctrineTitle(string doctrine)
        {
            return doctrine switch
            {
                "shield" => "Kalkan Duvarı",
                "raid" => "Yıldırım Baskını",
                _ => "Hilal Taktiği"
            };
        }

        private void AddCampaignKeyArtCard()
        {
            var card = CreatePanel(
                content,
                "CİHAN V11 Kuşatma Sanatı",
                new Color32(10, 16, 21, 255));
            var element = card.gameObject.AddComponent<LayoutElement>();
            element.preferredHeight = 520f;

            var artObject = new GameObject(
                "Cihan Kuşatma Ana Görseli",
                typeof(RectTransform),
                typeof(RawImage),
                typeof(AspectRatioFitter));
            artObject.transform.SetParent(card.transform, false);
            var art = artObject.GetComponent<RawImage>();
            art.texture = Resources.Load<Texture2D>("Art/cihan-siege-keyart-v11");
            art.color = Color.white;
            art.raycastTarget = false;
            Stretch(art.rectTransform);
            var aspect = artObject.GetComponent<AspectRatioFitter>();
            aspect.aspectMode = AspectRatioFitter.AspectMode.EnvelopeParent;
            aspect.aspectRatio = 1672f / 941f;

            var shade = CreatePanel(
                card.transform,
                "Kuşatma Yazı Gölgesi",
                new Color32(4, 8, 11, 172));
            shade.rectTransform.anchorMin = new Vector2(0f, 0f);
            shade.rectTransform.anchorMax = new Vector2(1f, 0.32f);
            shade.rectTransform.offsetMin = Vector2.zero;
            shade.rectTransform.offsetMax = Vector2.zero;

            var title = CreateText(
                card.transform,
                "CİHAN SEFERİ · V18",
                34,
                GoldBright,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            title.rectTransform.anchorMin = new Vector2(0.04f, 0.14f);
            title.rectTransform.anchorMax = new Vector2(0.96f, 0.30f);
            title.rectTransform.offsetMin = Vector2.zero;
            title.rectTransform.offsetMax = Vector2.zero;

            var subtitle = CreateText(
                card.transform,
                "Şahi topları hazır · Sipahiler kanatta · Divan emrini bekliyor",
                20,
                Ivory,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            subtitle.resizeTextForBestFit = true;
            subtitle.resizeTextMinSize = 14;
            subtitle.rectTransform.anchorMin = new Vector2(0.04f, 0.025f);
            subtitle.rectTransform.anchorMax = new Vector2(0.96f, 0.16f);
            subtitle.rectTransform.offsetMin = Vector2.zero;
            subtitle.rectTransform.offsetMax = Vector2.zero;
        }

        private void AddDivanOrders()
        {
            AddSectionTitle(
                "DİVAN EMİRLERİ",
                $"{game.State.seasonPoints:N0} şöhret · " +
                (CihanCloudGateway.Instance?.StatusText ?? "KAYIT HAZIR"));

            var daily = game.State.CurrentDailyOrder;
            var dailyComplete = game.State.IsDailyOrderComplete();
            AddActionCard(
                "☀",
                $"GÜNÜN EMRİ · {daily.title}",
                $"{daily.description} · {game.State.DailyOrderProgress()}",
                $"Mükâfat: {CostText(daily.reward)} · +{daily.gloryReward} şöhret",
                game.State.dailyOrderClaimed
                    ? "MÜHÜR ALINDI"
                    : dailyComplete
                        ? "DİVAN MÜHRÜNÜ AL"
                        : "EMİR DEVAM EDİYOR",
                dailyComplete && !game.State.dailyOrderClaimed,
                () =>
                {
                    game.ClaimDailyOrderReward();
                    RenderCurrentScreen();
                });

            for (var index = 0; index < GameRules.Missions.Length; index += 1)
            {
                var missionIndex = index;
                var mission = GameRules.Missions[missionIndex];
                var complete = game.State.IsMissionComplete(missionIndex);
                var claimed = game.State.IsMissionClaimed(missionIndex);
                AddActionCard(
                    complete ? "◆" : "◇",
                    mission.title,
                    $"{mission.description} · {game.State.MissionProgress(missionIndex)}",
                    $"Mükâfat: {CostText(mission.reward)} · +{mission.gloryReward} şöhret",
                    claimed
                        ? "MÜKÂFAT ALINDI"
                        : complete
                            ? "MÜKÂFATI AL"
                            : "EMİR DEVAM EDİYOR",
                    complete && !claimed,
                    () =>
                    {
                        game.ClaimMissionReward(missionIndex);
                        RenderCurrentScreen();
                    });
            }
        }

        private void AddCampaignMapCard()
        {
            var card = CreatePanel(
                content,
                "V26 Köz Cihan Sefer Haritası",
                new Color32(16, 29, 34, 255));
            var element = card.gameObject.AddComponent<LayoutElement>();
            element.preferredHeight = 1660f;

            var mapWorldObject = new GameObject(
                "V26 Dokunulabilir Sefer Dünyası",
                typeof(RectTransform),
                typeof(RawImage),
                typeof(Mask));
            mapWorldObject.transform.SetParent(card.transform, false);
            Stretch((RectTransform)mapWorldObject.transform);
            var mapImage = mapWorldObject.GetComponent<RawImage>();
            mapImage.texture = Resources.Load<Texture2D>("Art/cihan-world-v26");
            mapImage.color = Color.white;
            mapImage.raycastTarget = true;
            mapWorldObject.GetComponent<Mask>().showMaskGraphic = true;
            var mapWorld = mapWorldObject.AddComponent<CihanPremiumWorldOverlay>();
            mapWorld.ConfigureCampaign(
                game,
                stageIndex =>
                {
                    selectedCampaignStage = stageIndex;
                    UpdateSelectedCampaignPanel();
                });

            var mapShade = CreatePanel(
                card.transform,
                "Harita Savaş Gölgesi",
                new Color32(5, 10, 14, 28));
            Stretch(mapShade.rectTransform);
            mapShade.raycastTarget = false;

            var topShade = CreatePanel(
                card.transform,
                "Harita Üst Gölgesi",
                new Color32(8, 14, 18, 208));
            topShade.rectTransform.anchorMin = new Vector2(0f, 0.91f);
            topShade.rectTransform.anchorMax = Vector2.one;
            topShade.rectTransform.offsetMin = Vector2.zero;
            topShade.rectTransform.offsetMax = Vector2.zero;
            topShade.raycastTarget = false;

            var title = CreateText(
                card.transform,
                $"CİHAN HARİTASI  ·  " +
                $"{game.State.campaignProgress}/{GameRules.Campaign.Length} BÖLGE  ·  " +
                $"{game.State.seasonPoints:N0} ŞÖHRET",
                20,
                GoldBright,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            title.rectTransform.anchorMin = new Vector2(0.035f, 0.945f);
            title.rectTransform.anchorMax = new Vector2(0.965f, 0.992f);
            title.rectTransform.offsetMin = Vector2.zero;
            title.rectTransform.offsetMax = Vector2.zero;

            var gestureHint = CreateText(
                card.transform,
                "Hedef halkasına dokun · orduyu yürüt · kaleyi fethet",
                14,
                Ivory,
                TextAnchor.MiddleLeft,
                FontStyle.Italic);
            gestureHint.rectTransform.anchorMin = new Vector2(0.035f, 0.914f);
            gestureHint.rectTransform.anchorMax = new Vector2(0.965f, 0.945f);
            gestureHint.rectTransform.offsetMin = Vector2.zero;
            gestureHint.rectTransform.offsetMax = Vector2.zero;

            var commandPanel = CreatePanel(
                card.transform,
                "Sefer Emri",
                new Color32(8, 14, 18, 240));
            commandPanel.rectTransform.anchorMin = new Vector2(0f, 0f);
            commandPanel.rectTransform.anchorMax = new Vector2(1f, 0.135f);
            commandPanel.rectTransform.offsetMin = Vector2.zero;
            commandPanel.rectTransform.offsetMax = Vector2.zero;

            selectedCampaignText = CreateText(
                card.transform,
                "Cephe seçiliyor…",
                15,
                Ivory,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            selectedCampaignText.resizeTextForBestFit = true;
            selectedCampaignText.resizeTextMinSize = 10;
            selectedCampaignText.rectTransform.anchorMin = new Vector2(0.035f, 0.018f);
            selectedCampaignText.rectTransform.anchorMax = new Vector2(0.68f, 0.122f);
            selectedCampaignText.rectTransform.offsetMin = Vector2.zero;
            selectedCampaignText.rectTransform.offsetMax = Vector2.zero;

            selectedCampaignButton = CreateButton(
                card.transform,
                "SEFER MECLİSİ",
                () => ShowCampaignCouncil(selectedCampaignStage),
                new Color32(139, 52, 48, 255),
                16);
            var battleRect = selectedCampaignButton.GetComponent<RectTransform>();
            battleRect.anchorMin = new Vector2(0.71f, 0.028f);
            battleRect.anchorMax = new Vector2(0.965f, 0.112f);
            battleRect.offsetMin = Vector2.zero;
            battleRect.offsetMax = Vector2.zero;
            UpdateSelectedCampaignPanel();
        }

        private void ChangeCampaignPage(int direction)
        {
            var pageCount = Mathf.CeilToInt(GameRules.Campaign.Length / 4f);
            campaignPage = Mathf.Clamp(
                campaignPage + direction,
                0,
                Mathf.Max(0, pageCount - 1));
            var firstStage = campaignPage * 4;
            selectedCampaignStage = Mathf.Clamp(
                firstStage,
                0,
                GameRules.Campaign.Length - 1);
            RenderCurrentScreen();
        }

        private void ShowCampaignCouncil(int stageIndex)
        {
            if (overlayRoot == null ||
                stageIndex < 0 ||
                stageIndex >= GameRules.Campaign.Length)
            {
                return;
            }

            CloseCampaignCouncil();
            var stage = GameRules.Campaign[stageIndex];
            var overlay = CreatePanel(
                overlayRoot,
                "V26 Köz Sefer Meclisi",
                new Color32(4, 8, 11, 252));
            overlay.raycastTarget = true;
            Stretch(overlay.rectTransform);
            campaignCouncilOverlay = overlay.gameObject;
            campaignCouncilOverlay.transform.SetAsLastSibling();

            var artObject = new GameObject(
                "Sefer Meclisi Arka Planı",
                typeof(RectTransform),
                typeof(RawImage));
            artObject.transform.SetParent(overlay.transform, false);
            var art = artObject.GetComponent<RawImage>();
            art.texture = Resources.Load<Texture2D>("Art/cihan-council-v26") ??
                          Resources.Load<Texture2D>("Art/cihan-world-v26");
            art.color = new Color32(255, 255, 255, 255);
            art.raycastTarget = false;
            Stretch(art.rectTransform);

            var shade = CreatePanel(
                overlay.transform,
                "Meclis Okunabilirlik Gölgesi",
                new Color32(3, 7, 12, 66));
            Stretch(shade.rectTransform);

            var council = CreatePanel(
                overlay.transform,
                "Harp Divanı Levhası",
                new Color32(8, 18, 24, 158));
            council.rectTransform.anchorMin = new Vector2(0.055f, 0.055f);
            council.rectTransform.anchorMax = new Vector2(0.945f, 0.64f);
            council.rectTransform.offsetMin = Vector2.zero;
            council.rectTransform.offsetMax = Vector2.zero;

            var eyebrow = CreateText(
                overlay.transform,
                $"{stage.region.ToUpperInvariant()} · V26 KÖZ HARP DİVANI",
                15,
                GoldBright,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            SetAnchoredRect(
                eyebrow.rectTransform,
                new Vector2(0.08f, 0.91f),
                new Vector2(0.92f, 0.96f),
                Vector2.zero,
                Vector2.zero);

            var title = CreateText(
                overlay.transform,
                stage.title.ToUpperInvariant(),
                34,
                Ivory,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            title.resizeTextForBestFit = true;
            title.resizeTextMinSize = 22;
            SetAnchoredRect(
                title.rectTransform,
                new Vector2(0.08f, 0.845f),
                new Vector2(0.92f, 0.91f),
                Vector2.zero,
                Vector2.zero);

            var riskRatio = game.State.FormationPower /
                            Mathf.Max(1f, stage.recommendedPower);
            var risk = riskRatio >= 1.18f
                ? "ÜSTÜN DURUM"
                : riskRatio >= 0.92f
                    ? "DENGELİ MUHAREBE"
                    : "YÜKSEK RİSK";
            var intelligence = CreateText(
                council.transform,
                $"ORDU {game.State.FormationPower:N0}  ·  DÜŞMAN {stage.recommendedPower:N0}  ·  {risk}\n" +
                $"Yürüyüş: {stage.marchFood:N0} erzak  ·  Keşif: {EnemyCampaignPreview(stage.enemyTier)}",
                17,
                GoldBright,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            intelligence.resizeTextForBestFit = true;
            intelligence.resizeTextMinSize = 12;
            SetAnchoredRect(
                intelligence.rectTransform,
                new Vector2(0.05f, 0.82f),
                new Vector2(0.95f, 0.96f),
                Vector2.zero,
                Vector2.zero);

            AddCampaignOperationButton(
                council.transform,
                stageIndex,
                "assault",
                "⚔  DOĞRUDAN HÜCUM",
                "Kaynak harcamadan bütün gücünle saldır · düşman değişmez",
                new Vector2(0.055f, 0.625f),
                new Vector2(0.945f, 0.79f),
                new Color32(150, 58, 38, 218));
            AddCampaignOperationButton(
                council.transform,
                stageIndex,
                "intelligence",
                "◈  CASUS AĞI",
                "Gizli yolları aç · düşman morali ağır darbe alsın",
                new Vector2(0.055f, 0.435f),
                new Vector2(0.945f, 0.60f),
                new Color32(20, 103, 99, 218));
            AddCampaignOperationButton(
                council.transform,
                stageIndex,
                "sabotage",
                "✦  SABOTAJ",
                "Cephaneliği yak · düşman hasarı ve dayanıklılığı düşsün",
                new Vector2(0.055f, 0.245f),
                new Vector2(0.945f, 0.41f),
                new Color32(142, 89, 28, 218));
            AddCampaignOperationButton(
                council.transform,
                stageIndex,
                "bribery",
                "◉  RÜŞVET",
                "Kapı muhafızlarını satın al · düşman asker sayısı azalsın",
                new Vector2(0.055f, 0.055f),
                new Vector2(0.945f, 0.22f),
                new Color32(117, 42, 69, 218));

            campaignCouncilStatus = CreateText(
                overlay.transform,
                "Bir harp planı seç; bedel hemen hazineden düşer ve kuşatma başlar.",
                14,
                Muted,
                TextAnchor.MiddleCenter,
                FontStyle.Italic);
            campaignCouncilStatus.resizeTextForBestFit = true;
            campaignCouncilStatus.resizeTextMinSize = 10;
            SetAnchoredRect(
                campaignCouncilStatus.rectTransform,
                new Vector2(0.08f, 0.012f),
                new Vector2(0.78f, 0.052f),
                Vector2.zero,
                Vector2.zero);

            var close = CreateButton(
                overlay.transform,
                "VAZGEÇ",
                CloseCampaignCouncil,
                new Color32(48, 56, 62, 255),
                13);
            SetAnchoredRect(
                close.GetComponent<RectTransform>(),
                new Vector2(0.80f, 0.012f),
                new Vector2(0.94f, 0.052f),
                Vector2.zero,
                Vector2.zero);
        }

        private void AddCampaignOperationButton(
            Transform parent,
            int stageIndex,
            string planId,
            string title,
            string description,
            Vector2 anchorMin,
            Vector2 anchorMax,
            Color color)
        {
            var stage = GameRules.Campaign[stageIndex];
            var cost = GameRules.CampaignOperationCost(planId, stage.enemyTier);
            var costLabel = string.IsNullOrWhiteSpace(CostText(cost))
                ? "Hazırlık bedeli yok"
                : CostText(cost);
            var button = CreateButton(
                parent,
                $"{title}\n{description}\nBEDEL · {costLabel}",
                () => ExecuteCampaignOperation(stageIndex, planId),
                color,
                17);
            var rect = button.GetComponent<RectTransform>();
            rect.anchorMin = anchorMin;
            rect.anchorMax = anchorMax;
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;
            var label = button.GetComponentInChildren<Text>();
            label.resizeTextForBestFit = true;
            label.resizeTextMinSize = 12;
            label.resizeTextMaxSize = 17;
        }

        private void ExecuteCampaignOperation(int stageIndex, string planId)
        {
            if (!game.BeginCampaignOperation(
                    stageIndex,
                    planId,
                    out var preparation))
            {
                if (campaignCouncilStatus != null)
                {
                    campaignCouncilStatus.text = game.State.lastEvent;
                    campaignCouncilStatus.color = new Color32(238, 122, 105, 255);
                }

                RefreshHeader();
                return;
            }

            var stage = GameRules.Campaign[stageIndex];
            CihanBattleView.PrepareNextBattle(
                preparation.moralePenalty,
                preparation.powerMultiplier,
                preparation.countMultiplier,
                $"{preparation.title}: {preparation.report}");
            CloseCampaignCouncil();
            RefreshHeader();
            CihanBattleView.Show(
                game,
                stage,
                () =>
                {
                    RefreshHeader();
                    RenderCurrentScreen();
                });
        }

        private void CloseCampaignCouncil()
        {
            if (campaignCouncilOverlay != null)
            {
                Destroy(campaignCouncilOverlay);
            }

            campaignCouncilOverlay = null;
            campaignCouncilStatus = null;
        }

        private static string EnemyCampaignPreview(int tier)
        {
            return tier switch
            {
                1 => "ağır piyade · mızraklı hat",
                2 => "seçkin muhafız · süvari kanadı",
                3 => "iki savunma hattı · takviye",
                4 => "zırhlı muhafız · ağır topçu",
                5 => "taht kumandanı · Şahi bataryası",
                _ => "piyade hattı · okçu kulesi"
            };
        }

        private void AddCityWorldCard()
        {
            var card = CreatePanel(content, "V26 Köz Payitaht", Panel);
            var element = card.gameObject.AddComponent<LayoutElement>();
            element.preferredHeight = 1660f;

            var cityWorldObject = new GameObject(
                "V26 Dokunulabilir Köz Payitaht",
                typeof(RectTransform),
                typeof(RawImage),
                typeof(Mask));
            cityWorldObject.transform.SetParent(card.transform, false);
            Stretch((RectTransform)cityWorldObject.transform);
            var cityImage = cityWorldObject.GetComponent<RawImage>();
            cityImage.texture = Resources.Load<Texture2D>("Art/cihan-capital-v26");
            cityImage.color = Color.white;
            cityImage.raycastTarget = true;
            cityWorldObject.GetComponent<Mask>().showMaskGraphic = true;
            var cityWorld = cityWorldObject.AddComponent<CihanPremiumWorldOverlay>();
            cityWorld.ConfigureCity(
                game,
                buildingId =>
                {
                    selectedCityBuildingId = buildingId;
                    UpdateSelectedBuildingPanel();
                });

            var atmosphere = CreatePanel(
                card.transform,
                "Payitaht Atmosfer Gölgesi",
                new Color32(7, 12, 14, 22));
            Stretch(atmosphere.rectTransform);
            atmosphere.raycastTarget = false;

            var topShade = CreatePanel(
                card.transform,
                "Başkent Üst Gölgesi",
                new Color32(8, 14, 18, 210));
            topShade.rectTransform.anchorMin = new Vector2(0f, 0.91f);
            topShade.rectTransform.anchorMax = Vector2.one;
            topShade.rectTransform.offsetMin = Vector2.zero;
            topShade.rectTransform.offsetMax = Vector2.zero;
            topShade.raycastTarget = false;

            var cityTitle = CreateText(
                card.transform,
                $"PAYİTAHT  ·  SARAY {game.State.GetBuilding("palace").level}  ·  " +
                $"{game.State.units.Sum(item => item.count):N0} ASKER  ·  " +
                $"{game.State.TerritoriesControlled} BÖLGE",
                20,
                GoldBright,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            cityTitle.resizeTextForBestFit = true;
            SetAnchoredRect(
                cityTitle.rectTransform,
                new Vector2(0.035f, 0.945f),
                new Vector2(0.965f, 0.992f),
                Vector2.zero,
                Vector2.zero);

            var gestureHint = CreateText(
                card.transform,
                "Yapıya dokun · üretimi topla · yapıyı geliştir",
                14,
                Ivory,
                TextAnchor.MiddleLeft,
                FontStyle.Italic);
            SetAnchoredRect(
                gestureHint.rectTransform,
                new Vector2(0.035f, 0.914f),
                new Vector2(0.965f, 0.945f),
                Vector2.zero,
                Vector2.zero);

            AddCityMissionGuide(card.transform);

            AddCityQuickAction(
                card.transform,
                "⚔  SEFERE ÇIK",
                ScreenId.Map,
                new Vector2(0.68f, 0.185f),
                new Vector2(0.965f, 0.245f),
                new Color32(139, 52, 48, 246));

            var commandPanel = CreatePanel(
                card.transform,
                "Yapı Emri",
                new Color32(8, 14, 18, 242));
            commandPanel.rectTransform.anchorMin = Vector2.zero;
            commandPanel.rectTransform.anchorMax = new Vector2(1f, 0.165f);
            commandPanel.rectTransform.offsetMin = Vector2.zero;
            commandPanel.rectTransform.offsetMax = Vector2.zero;

            selectedBuildingText = CreateText(
                card.transform,
                "Yapı seçiliyor…",
                15,
                Ivory,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            selectedBuildingText.resizeTextForBestFit = true;
            selectedBuildingText.resizeTextMinSize = 10;
            selectedBuildingText.resizeTextMaxSize = 15;
            SetAnchoredRect(
                selectedBuildingText.rectTransform,
                new Vector2(0.035f, 0.085f),
                new Vector2(0.965f, 0.153f),
                Vector2.zero,
                Vector2.zero);

            selectedBuildingActionButton = CreateButton(
                card.transform,
                "TOPLA",
                UseSelectedBuildingAction,
                new Color32(37, 91, 82, 255),
                15);
            SetAnchoredRect(
                selectedBuildingActionButton.GetComponent<RectTransform>(),
                new Vector2(0.035f, 0.018f),
                new Vector2(0.485f, 0.078f),
                Vector2.zero,
                Vector2.zero);

            selectedBuildingButton = CreateButton(
                card.transform,
                "GELİŞTİR",
                () =>
                {
                    game.UpgradeBuilding(selectedCityBuildingId);
                    RenderCurrentScreen();
                },
                new Color32(133, 91, 36, 255),
                15);
            SetAnchoredRect(
                selectedBuildingButton.GetComponent<RectTransform>(),
                new Vector2(0.515f, 0.018f),
                new Vector2(0.965f, 0.078f),
                Vector2.zero,
                Vector2.zero);

            UpdateSelectedBuildingPanel();
        }

        private void AddCityBuildingHotspot(
            Transform parent,
            string buildingId,
            string label,
            Vector2 anchor)
        {
            var selected = selectedCityBuildingId == buildingId;
            var button = CreateButton(
                parent,
                label,
                () =>
                {
                    selectedCityBuildingId = buildingId;
                    UpdateSelectedBuildingPanel();
                },
                selected
                    ? new Color32(157, 100, 32, 246)
                    : new Color32(11, 28, 30, 222),
                12);
            var rect = button.GetComponent<RectTransform>();
            rect.anchorMin = new Vector2(anchor.x - 0.066f, anchor.y - 0.026f);
            rect.anchorMax = new Vector2(anchor.x + 0.066f, anchor.y + 0.026f);
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;
        }

        private void AddCityQuickAction(
            Transform parent,
            string label,
            ScreenId screen,
            Vector2 anchorMin,
            Vector2 anchorMax,
            Color color)
        {
            var button = CreateButton(
                parent,
                label,
                () => ShowScreen(screen),
                color,
                16);
            var rect = button.GetComponent<RectTransform>();
            rect.anchorMin = anchorMin;
            rect.anchorMax = anchorMax;
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;
        }

        private void AddCityMissionGuide(Transform parent)
        {
            var missionIndex = PrimaryMissionIndex();
            var guide = CreatePanel(
                parent,
                "Lale Hatun Görev Rehberi",
                new Color32(8, 16, 20, 232));
            guide.rectTransform.anchorMin = new Vector2(0.02f, 0.795f);
            guide.rectTransform.anchorMax = new Vector2(0.98f, 0.88f);
            guide.rectTransform.offsetMin = Vector2.zero;
            guide.rectTransform.offsetMax = Vector2.zero;

            var portraitObject = new GameObject(
                "Lale Hatun Rehber Portresi",
                typeof(RectTransform),
                typeof(RawImage));
            portraitObject.transform.SetParent(guide.transform, false);
            var portrait = portraitObject.GetComponent<RawImage>();
            portrait.texture = Resources.Load<Texture2D>("Art/cihan-commander-leyla-v16");
            portrait.color = Color.white;
            portrait.raycastTarget = false;
            SetAnchoredRect(
                portrait.rectTransform,
                new Vector2(0.01f, 0.08f),
                new Vector2(0.105f, 0.92f),
                Vector2.zero,
                Vector2.zero);

            string title;
            string progress;
            string buttonLabel;
            var canClaim = false;
            if (missionIndex < 0)
            {
                title = "DİVAN EMİRLERİ TAMAMLANDI";
                progress = "Yeni fetih hedefi için dünya haritasını aç.";
                buttonLabel = "HARİTA";
            }
            else
            {
                var mission = GameRules.Missions[missionIndex];
                canClaim = game.State.IsMissionComplete(missionIndex) &&
                           !game.State.IsMissionClaimed(missionIndex);
                title = canClaim
                    ? $"MÜKÂFAT HAZIR · {mission.title}"
                    : $"SIRADAKİ EMİR · {mission.title}";
                progress = $"{game.State.MissionProgress(missionIndex)} · +{mission.gloryReward} şöhret";
                buttonLabel = canClaim ? "MÜKÂFATI AL" : "GİT";
            }

            var guideText = CreateText(
                guide.transform,
                $"{title}\n{progress}",
                17,
                canClaim ? GoldBright : Ivory,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            guideText.resizeTextForBestFit = true;
            guideText.resizeTextMinSize = 12;
            guideText.resizeTextMaxSize = 17;
            SetAnchoredRect(
                guideText.rectTransform,
                new Vector2(0.12f, 0.08f),
                new Vector2(0.76f, 0.92f),
                Vector2.zero,
                Vector2.zero);

            var capturedMissionIndex = missionIndex;
            var button = CreateButton(
                guide.transform,
                buttonLabel,
                () => OpenPrimaryMission(capturedMissionIndex),
                canClaim
                    ? new Color32(150, 95, 28, 255)
                    : new Color32(52, 91, 86, 255),
                14);
            SetAnchoredRect(
                button.GetComponent<RectTransform>(),
                new Vector2(0.78f, 0.16f),
                new Vector2(0.985f, 0.84f),
                Vector2.zero,
                Vector2.zero);
        }

        private int PrimaryMissionIndex()
        {
            for (var index = 0; index < GameRules.Missions.Length; index += 1)
            {
                if (game.State.IsMissionComplete(index) &&
                    !game.State.IsMissionClaimed(index))
                {
                    return index;
                }
            }

            for (var index = 0; index < GameRules.Missions.Length; index += 1)
            {
                if (!game.State.IsMissionClaimed(index))
                {
                    return index;
                }
            }

            return -1;
        }

        private int UnclaimedMissionCount()
        {
            return Enumerable.Range(0, GameRules.Missions.Length)
                .Count(index => !game.State.IsMissionClaimed(index));
        }

        private void OpenPrimaryMission(int missionIndex)
        {
            if (missionIndex < 0)
            {
                ShowScreen(ScreenId.Map);
                return;
            }

            if (game.State.IsMissionComplete(missionIndex) &&
                !game.State.IsMissionClaimed(missionIndex))
            {
                game.ClaimMissionReward(missionIndex);
                RenderCurrentScreen();
                return;
            }

            var missionId = GameRules.Missions[missionIndex].id;
            switch (missionId)
            {
                case "palace_four":
                    selectedCityBuildingId = "palace";
                    RenderCurrentScreen();
                    break;
                case "army_four_hundred":
                case "siege_column":
                    ShowScreen(ScreenId.Army);
                    break;
                case "master_commander":
                    ShowScreen(ScreenId.Heroes);
                    break;
                default:
                    ShowScreen(ScreenId.Map);
                    break;
            }
        }

        private void BeginFirstAvailableResearch()
        {
            var research = ImperialRules.Research.FirstOrDefault(item =>
                game.State.CanResearch(item.id));
            game.BeginResearch((research ?? ImperialRules.Research[0]).id);
            RenderCurrentScreen();
        }

        private void UpdateSelectedCampaignPanel()
        {
            if (selectedCampaignText == null || selectedCampaignButton == null)
            {
                return;
            }

            var stage = GameRules.Campaign[selectedCampaignStage];
            var completed = selectedCampaignStage < game.State.campaignProgress;
            var locked = selectedCampaignStage > game.State.campaignProgress;
            var stars = game.State.CampaignStars(selectedCampaignStage);
            var status = completed
                ? $"FETHEDİLDİ · {new string('★', stars)}{new string('☆', 3 - stars)}"
                : locked
                    ? "SINIR KAPALI"
                    : "ORDU YÜRÜYÜŞE HAZIR";
            selectedCampaignText.text =
                $"{stage.title} · {status} · Güç {stage.recommendedPower:N0} · {stage.marchFood:N0} erzak";

            var canLaunch = game.State.CanLaunchCampaign(selectedCampaignStage);
            selectedCampaignButton.interactable = canLaunch;
            var label = selectedCampaignButton.GetComponentInChildren<Text>();
            if (label != null)
            {
                label.text = locked
                    ? "KİLİTLİ"
                    : completed
                        ? "YENİDEN SAVAŞ"
                        : "SEFERE ÇIK";
            }

            SetButtonColor(
                selectedCampaignButton,
                canLaunch
                    ? new Color32(139, 52, 48, 255)
                    : new Color32(55, 58, 60, 255));
        }

        private void UpdateSelectedBuildingPanel()
        {
            if (selectedBuildingText == null ||
                selectedBuildingButton == null ||
                selectedBuildingActionButton == null)
            {
                return;
            }

            var spec = GameRules.Buildings.First(item => item.id == selectedCityBuildingId);
            var building = game.State.GetBuilding(selectedCityBuildingId);
            var production = GameRules.ProductionPerMinute(spec.id, building.level);
            var productionText = production > 0d
                ? $" · {production:N0}/dk"
                : string.Empty;
            var constructionText = game.State.construction != null &&
                                   game.State.construction.targetId == spec.id
                ? $"İNŞA %{Mathf.RoundToInt(game.State.construction.Progress(GameService.Now) * 100f)}"
                : game.State.BuildingUpgradeStatus(spec.id);
            selectedBuildingText.text =
                $"{spec.title} · SV {building.level}{productionText}\n{constructionText}";

            var canUpgrade = game.State.CanUpgradeBuilding(spec.id);
            selectedBuildingButton.interactable = canUpgrade;
            var buttonText = selectedBuildingButton.GetComponentInChildren<Text>();
            if (buttonText != null)
            {
                buttonText.text = building.level >= GameRules.MaximumBuildingLevel
                    ? "TAMAMLANDI"
                    : "GELİŞTİR";
            }

            SetButtonColor(
                selectedBuildingButton,
                canUpgrade
                    ? new Color32(133, 91, 36, 255)
                    : new Color32(55, 58, 60, 255));

            var actionLabel = selectedBuildingActionButton.GetComponentInChildren<Text>();
            var actionReady = true;
            var actionColor = new Color32(37, 91, 82, 255);
            switch (spec.id)
            {
                case "palace":
                case "farm":
                case "lumber":
                case "quarry":
                    actionReady = game.State.CanClaimProduction(spec.id, GameService.Now);
                    var seconds = game.State.ProductionClaimSecondsLeft(
                        spec.id,
                        GameService.Now);
                    if (actionLabel != null)
                    {
                        actionLabel.text = actionReady ? "ÜRETİMİ TOPLA" : $"{seconds:00} SN";
                    }
                    break;
                case "barracks":
                    if (actionLabel != null) actionLabel.text = "ASKER EĞİT";
                    break;
                case "academy":
                    actionReady = game.State.research == null;
                    if (actionLabel != null) actionLabel.text = actionReady ? "ARAŞTIR" : "ARAŞTIRILIYOR";
                    break;
                case "embassy":
                    if (actionLabel != null) actionLabel.text = "İTTİFAK MERKEZİ";
                    break;
                case "hospital":
                    if (actionLabel != null) actionLabel.text = "YARALILARI GÖR";
                    break;
                default:
                    if (actionLabel != null) actionLabel.text = "YAPIYI AÇ";
                    break;
            }

            selectedBuildingActionButton.interactable = actionReady;
            SetButtonColor(
                selectedBuildingActionButton,
                actionReady ? actionColor : new Color32(55, 58, 60, 255));
        }

        private void UseSelectedBuildingAction()
        {
            switch (selectedCityBuildingId)
            {
                case "palace":
                case "farm":
                case "lumber":
                case "quarry":
                    game.ClaimBuildingProduction(selectedCityBuildingId);
                    RefreshHeader();
                    UpdateSelectedBuildingPanel();
                    break;
                case "barracks":
                case "hospital":
                    ShowScreen(ScreenId.Army);
                    break;
                case "academy":
                    BeginFirstAvailableResearch();
                    break;
                case "embassy":
                    ShowScreen(ScreenId.Alliance);
                    break;
            }
        }

        private void AddCommanderCollectionCard()
        {
            var gallery = CreatePanel(
                content,
                "V20 Komutan Koleksiyonu",
                new Color32(11, 18, 25, 255));
            var galleryElement = gallery.gameObject.AddComponent<LayoutElement>();
            galleryElement.preferredHeight = 650f;

            var title = CreateText(
                gallery.transform,
                $"KADRO GÜCÜ {game.State.heroes.Sum(item => game.State.CommanderPower(item.id)):N0}  ·  " +
                $"{game.State.heroes.Count(item => item.assigned)}/2 SEFERDE",
                20,
                GoldBright,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            SetAnchoredRect(
                title.rectTransform,
                new Vector2(0.025f, 0.91f),
                new Vector2(0.975f, 0.985f),
                Vector2.zero,
                Vector2.zero);

            for (var index = 0; index < GameRules.Heroes.Length; index += 1)
            {
                var spec = GameRules.Heroes[index];
                var hero = game.State.GetHero(spec.id);
                var profile = game.State.CommanderProfile(spec.id);
                var selected = spec.id == selectedCommanderId;
                var xMin = 0.02f + index * 0.325f;
                var xMax = xMin + 0.305f;
                var commanderCard = CreatePanel(
                    gallery.transform,
                    $"{spec.name} Koleksiyon Kartı",
                    selected
                        ? new Color32(105, 72, 31, 255)
                        : new Color32(28, 38, 47, 255));
                SetAnchoredRect(
                    commanderCard.rectTransform,
                    new Vector2(xMin, 0.055f),
                    new Vector2(xMax, 0.89f),
                    Vector2.zero,
                    Vector2.zero);

                var portraitFrame = CreatePanel(
                    commanderCard.transform,
                    "Portre Çerçevesi",
                    hero.assigned
                        ? new Color32(47, 104, 94, 255)
                        : new Color32(46, 51, 55, 255));
                SetAnchoredRect(
                    portraitFrame.rectTransform,
                    new Vector2(0.035f, 0.39f),
                    new Vector2(0.965f, 0.965f),
                    Vector2.zero,
                    Vector2.zero);

                var portraitObject = new GameObject(
                    $"{spec.name} Tam Portre",
                    typeof(RectTransform),
                    typeof(RawImage));
                portraitObject.transform.SetParent(portraitFrame.transform, false);
                var portrait = portraitObject.GetComponent<RawImage>();
                portrait.texture = Resources.Load<Texture2D>($"Art/cihan-commander-{spec.id}-v16");
                portrait.color = Color.white;
                portrait.raycastTarget = false;
                Stretch(portrait.rectTransform, 5f, 5f, 5f, 5f);

                var rarity = CreateText(
                    portraitFrame.transform,
                    hero.assigned ? "⚔ SEFERDE" : profile.rarity,
                    14,
                    GoldBright,
                    TextAnchor.MiddleCenter,
                    FontStyle.Bold);
                rarity.rectTransform.anchorMin = new Vector2(0f, 0f);
                rarity.rectTransform.anchorMax = new Vector2(1f, 0.14f);
                rarity.rectTransform.offsetMin = Vector2.zero;
                rarity.rectTransform.offsetMax = Vector2.zero;

                var detail = CreateText(
                    commanderCard.transform,
                    $"{spec.name}\n{new string('★', hero.stars)}{new string('☆', 5 - hero.stars)}\n" +
                    $"SV {hero.level} · GÜÇ {game.State.CommanderPower(spec.id):N0}",
                    18,
                    selected ? GoldBright : Ivory,
                    TextAnchor.MiddleCenter,
                    FontStyle.Bold);
                detail.resizeTextForBestFit = true;
                detail.resizeTextMinSize = 12;
                detail.resizeTextMaxSize = 18;
                SetAnchoredRect(
                    detail.rectTransform,
                    new Vector2(0.03f, 0.15f),
                    new Vector2(0.97f, 0.39f),
                    Vector2.zero,
                    Vector2.zero);

                var capturedId = spec.id;
                var selectButton = CreateButton(
                    commanderCard.transform,
                    selected ? "SEÇİLİ" : "İNCELE",
                    () =>
                    {
                        selectedCommanderId = capturedId;
                        RenderCurrentScreen();
                    },
                    selected
                        ? new Color32(142, 91, 29, 255)
                        : new Color32(44, 79, 77, 255),
                    15);
                SetAnchoredRect(
                    selectButton.GetComponent<RectTransform>(),
                    new Vector2(0.08f, 0.025f),
                    new Vector2(0.92f, 0.14f),
                    Vector2.zero,
                    Vector2.zero);
            }
        }

        private void AddHeroManagementCard(HeroSpec spec, HeroState hero)
        {
            var profile = game.State.CommanderProfile(spec.id);
            var card = CreatePanel(content, $"{spec.name} Komutan Kartı", Panel);
            var element = card.gameObject.AddComponent<LayoutElement>();
            element.preferredHeight = 540f;

            var color = hero.assigned ? Teal : new Color32(75, 79, 82, 255);
            var portrait = CreatePanel(card.transform, "Komutan Mührü", color);
            SetAnchoredRect(
                portrait.rectTransform,
                new Vector2(0.03f, 0.31f),
                new Vector2(0.36f, 0.95f),
                Vector2.zero,
                Vector2.zero);

            var portraitImageObject = new GameObject(
                "V12 Komutan Portresi",
                typeof(RectTransform),
                typeof(RawImage));
            portraitImageObject.transform.SetParent(portrait.transform, false);
            var portraitImage = portraitImageObject.GetComponent<RawImage>();
            var fullPortrait = Resources.Load<Texture2D>($"Art/cihan-commander-{spec.id}-v16");
            portraitImage.texture = fullPortrait ?? Resources.Load<Texture2D>("Art/cihan-commanders-v12");
            portraitImage.uvRect = fullPortrait != null
                ? new Rect(0f, 0f, 1f, 1f)
                : new Rect(profile.portraitIndex / 3f, 0f, 1f / 3f, 1f);
            portraitImage.color = Color.white;
            portraitImage.raycastTarget = false;
            Stretch(portraitImage.rectTransform, 4f, 4f, 4f, 4f);

            var rarity = CreateText(
                portrait.transform,
                profile.rarity,
                15,
                GoldBright,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            rarity.rectTransform.anchorMin = new Vector2(0f, 0f);
            rarity.rectTransform.anchorMax = new Vector2(1f, 0.15f);
            rarity.rectTransform.offsetMin = Vector2.zero;
            rarity.rectTransform.offsetMax = Vector2.zero;

            var name = CreateText(
                card.transform,
                $"{spec.name} · {spec.title}\n{new string('★', hero.stars)}{new string('☆', 5 - hero.stars)}",
                30,
                Ivory,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            SetAnchoredRect(
                name.rectTransform,
                new Vector2(0.39f, 0.72f),
                new Vector2(0.97f, 0.96f),
                Vector2.zero,
                Vector2.zero);

            var level = CreateText(
                card.transform,
                $"{profile.role} · Güç {game.State.CommanderPower(spec.id):N0}\n" +
                $"Seviye {hero.level}/40 · Yetenek {hero.skillLevel}/5\n" +
                $"Silah T{hero.weaponTier} · Zırh T{hero.armorTier} · Nişan {hero.shards}\n" +
                $"{profile.skillName}: {spec.bonus}\n\n{profile.biography}",
                18,
                hero.assigned ? GoldBright : Muted,
                TextAnchor.UpperLeft,
                FontStyle.Normal);
            level.resizeTextForBestFit = true;
            level.resizeTextMinSize = 14;
            level.resizeTextMaxSize = 18;
            SetAnchoredRect(
                level.rectTransform,
                new Vector2(0.39f, 0.30f),
                new Vector2(0.97f, 0.72f),
                Vector2.zero,
                Vector2.zero);

            var assign = CreateButton(
                card.transform,
                hero.assigned ? "ORDUDAN\nÇIKAR" : "ORDUYA\nATA",
                () =>
                {
                    game.ToggleHero(spec.id);
                    RenderCurrentScreen();
                },
                hero.assigned
                    ? new Color32(55, 83, 79, 255)
                    : new Color32(92, 68, 38, 255),
                18);
            SetAnchoredRect(
                assign.GetComponent<RectTransform>(),
                new Vector2(0.03f, 0.04f),
                new Vector2(0.26f, 0.25f),
                Vector2.zero,
                Vector2.zero);

            var levelCost = game.State.CommanderLevelCost(spec.id);
            var canLevel = hero.level < 40 && game.State.CanAfford(levelCost);
            var levelUp = CreateButton(
                card.transform,
                hero.level >= 40 ? "SEVİYE\nTAMAM" : "SEVİYE\nYÜKSELT",
                () =>
                {
                    game.UpgradeCommanderLevel(spec.id);
                    RenderCurrentScreen();
                },
                canLevel
                    ? new Color32(133, 91, 36, 255)
                    : new Color32(55, 58, 60, 255),
                15);
            levelUp.interactable = canLevel;
            SetAnchoredRect(
                levelUp.GetComponent<RectTransform>(),
                new Vector2(0.275f, 0.04f),
                new Vector2(0.50f, 0.25f),
                Vector2.zero,
                Vector2.zero);

            var equipmentCost = game.State.CommanderEquipmentCost(spec.id);
            var canEquip =
                (hero.weaponTier < 5 || hero.armorTier < 5) &&
                game.State.CanAfford(equipmentCost);
            var equipment = CreateButton(
                card.transform,
                canEquip ? "TEÇHİZAT\nGELİŞTİR" : "TEÇHİZAT\nBEKLİYOR",
                () =>
                {
                    game.UpgradeCommanderEquipment(spec.id);
                    RenderCurrentScreen();
                },
                canEquip
                    ? new Color32(48, 84, 81, 255)
                    : new Color32(55, 58, 60, 255),
                15);
            equipment.interactable = canEquip;
            SetAnchoredRect(
                equipment.GetComponent<RectTransform>(),
                new Vector2(0.515f, 0.04f),
                new Vector2(0.74f, 0.25f),
                Vector2.zero,
                Vector2.zero);

            var requiredShards = hero.stars * 15;
            var canPromote = hero.stars < 5 && hero.shards >= requiredShards;
            var promote = CreateButton(
                card.transform,
                hero.stars >= 5 ? "YILDIZ\nTAMAM" : $"YILDIZ +\n{requiredShards} NİŞAN",
                () =>
                {
                    game.PromoteCommander(spec.id);
                    RenderCurrentScreen();
                },
                canPromote
                    ? new Color32(111, 70, 37, 255)
                    : new Color32(55, 58, 60, 255),
                14);
            promote.interactable = canPromote;
            SetAnchoredRect(
                promote.GetComponent<RectTransform>(),
                new Vector2(0.755f, 0.04f),
                new Vector2(0.97f, 0.25f),
                Vector2.zero,
                Vector2.zero);
        }

        private void AddHeroCard(
            string kicker,
            string title,
            string description,
            Color accent)
        {
            var card = CreatePanel(content, $"{title} Kartı", Panel);
            var element = card.gameObject.AddComponent<LayoutElement>();
            element.preferredHeight = 330f;

            var accentBar = CreatePanel(card.transform, "Vurgu", accent);
            SetAnchoredRect(
                accentBar.rectTransform,
                new Vector2(0f, 0f),
                new Vector2(0f, 1f),
                new Vector2(12f, 0f),
                new Vector2(6f, 0f));

            var kickerText = CreateText(
                card.transform,
                kicker,
                20,
                Gold,
                TextAnchor.UpperLeft,
                FontStyle.Bold);
            SetAnchoredRect(
                kickerText.rectTransform,
                new Vector2(0f, 0.72f),
                new Vector2(1f, 1f),
                new Vector2(-52f, -18f),
                new Vector2(38f, -42f));

            var titleText = CreateText(
                card.transform,
                title,
                46,
                Ivory,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            SetAnchoredRect(
                titleText.rectTransform,
                new Vector2(0f, 0.35f),
                new Vector2(1f, 0.78f),
                new Vector2(-52f, -10f),
                new Vector2(38f, 6f));

            var descriptionText = CreateText(
                card.transform,
                description,
                25,
                Muted,
                TextAnchor.UpperLeft,
                FontStyle.Normal);
            SetAnchoredRect(
                descriptionText.rectTransform,
                new Vector2(0f, 0f),
                new Vector2(1f, 0.38f),
                new Vector2(-52f, -18f),
                new Vector2(38f, -5f));
        }

        private void AddSectionTitle(string title, string subtitle)
        {
            var container = new GameObject($"{title} Başlığı", typeof(RectTransform));
            container.transform.SetParent(content, false);
            var element = container.AddComponent<LayoutElement>();
            element.preferredHeight = 120f;

            screenTitle = CreateText(
                container.transform,
                title,
                27,
                Gold,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            SetAnchoredRect(
                screenTitle.rectTransform,
                new Vector2(0f, 0.45f),
                new Vector2(1f, 1f),
                Vector2.zero,
                Vector2.zero);

            var subtitleText = CreateText(
                container.transform,
                subtitle,
                20,
                Muted,
                TextAnchor.MiddleLeft,
                FontStyle.Normal);
            SetAnchoredRect(
                subtitleText.rectTransform,
                new Vector2(0f, 0f),
                new Vector2(1f, 0.48f),
                Vector2.zero,
                Vector2.zero);
        }

        private void AddJobCard(TimedJob job, string title, string emptyDescription)
        {
            var card = CreatePanel(content, title, new Color32(18, 28, 36, 255));
            var element = card.gameObject.AddComponent<LayoutElement>();
            element.preferredHeight = 178f;

            var titleText = CreateText(
                card.transform,
                title,
                22,
                Gold,
                TextAnchor.UpperLeft,
                FontStyle.Bold);
            SetAnchoredRect(
                titleText.rectTransform,
                new Vector2(0f, 0.58f),
                new Vector2(1f, 1f),
                new Vector2(-42f, -12f),
                new Vector2(28f, -24f));

            var description = job == null
                ? emptyDescription
                : $"{JobTitle(job)} · {job.SecondsLeft(GameService.Now):00} sn kaldı";
            var descriptionText = CreateText(
                card.transform,
                description,
                23,
                Ivory,
                TextAnchor.MiddleLeft,
                FontStyle.Normal);
            SetAnchoredRect(
                descriptionText.rectTransform,
                new Vector2(0f, 0.18f),
                new Vector2(1f, 0.66f),
                new Vector2(-42f, -5f),
                new Vector2(28f, -4f));
            activeJob = job;
            activeJobDescription = descriptionText;

            var track = CreatePanel(card.transform, "İlerleme Zemini", new Color32(42, 49, 54, 255));
            SetAnchoredRect(
                track.rectTransform,
                new Vector2(0f, 0f),
                new Vector2(1f, 0f),
                new Vector2(-32f, 12f),
                new Vector2(28f, 36f));

            var progress = CreatePanel(track.transform, "İlerleme", Gold);
            var amount = job?.Progress(GameService.Now) ?? 0f;
            progress.rectTransform.anchorMin = Vector2.zero;
            progress.rectTransform.anchorMax = new Vector2(amount, 1f);
            progress.rectTransform.offsetMin = Vector2.zero;
            progress.rectTransform.offsetMax = Vector2.zero;
            activeJobProgress = progress.rectTransform;
        }

        private void AddActionCard(
            string icon,
            string title,
            string description,
            string cost,
            string buttonLabel,
            bool interactable,
            UnityEngine.Events.UnityAction action)
        {
            var card = CreatePanel(content, $"{title} Kartı", Panel);
            var element = card.gameObject.AddComponent<LayoutElement>();
            element.preferredHeight = 255f;

            var iconText = CreateText(
                card.transform,
                icon,
                48,
                GoldBright,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            SetAnchoredRect(
                iconText.rectTransform,
                new Vector2(0f, 0.43f),
                new Vector2(0.18f, 1f),
                Vector2.zero,
                new Vector2(15f, -12f));

            var titleText = CreateText(
                card.transform,
                title,
                30,
                Ivory,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            SetAnchoredRect(
                titleText.rectTransform,
                new Vector2(0.18f, 0.65f),
                new Vector2(1f, 1f),
                new Vector2(-32f, -8f),
                new Vector2(12f, -14f));

            var descriptionText = CreateText(
                card.transform,
                description,
                21,
                Muted,
                TextAnchor.UpperLeft,
                FontStyle.Normal);
            SetAnchoredRect(
                descriptionText.rectTransform,
                new Vector2(0.18f, 0.27f),
                new Vector2(1f, 0.68f),
                new Vector2(-32f, -6f),
                new Vector2(12f, -8f));

            var costText = CreateText(
                card.transform,
                cost,
                18,
                GoldBright,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            costText.resizeTextForBestFit = true;
            costText.resizeTextMinSize = 13;
            costText.resizeTextMaxSize = 18;
            SetAnchoredRect(
                costText.rectTransform,
                new Vector2(0.03f, 0f),
                new Vector2(0.66f, 0.28f),
                new Vector2(-18f, -8f),
                new Vector2(18f, 3f));

            var button = CreateButton(
                card.transform,
                buttonLabel,
                action,
                interactable ? new Color32(133, 91, 36, 255) : new Color32(55, 58, 60, 255),
                20);
            button.interactable = interactable;
            SetAnchoredRect(
                button.GetComponent<RectTransform>(),
                new Vector2(0.68f, 0f),
                new Vector2(1f, 0.28f),
                new Vector2(-22f, -8f),
                new Vector2(8f, 3f));
        }

        private void HandleChanged()
        {
            RefreshHeader();
            if (ComputeScreenRevision() != renderedScreenRevision)
            {
                RenderCurrentScreen();
            }
        }

        private int ComputeScreenRevision()
        {
            if (game?.State == null)
            {
                return 0;
            }

            unchecked
            {
                var state = game.State;
                var hash = 17 * 31 + (int)currentScreen;
                switch (currentScreen)
                {
                    case ScreenId.City:
                        foreach (var building in state.buildings)
                        {
                            hash = hash * 31 + building.id.GetHashCode();
                            hash = hash * 31 + building.level;
                            hash = hash * 31 +
                                   (state.CanUpgradeBuilding(building.id) ? 1 : 0);
                        }

                        hash = AddJobRevision(hash, state.construction);
                        hash = AddJobRevision(hash, state.research);
                        hash = hash * 31 + state.TerritoriesControlled;
                        foreach (var research in state.researchStates)
                        {
                            hash = hash * 31 + research.id.GetHashCode();
                            hash = hash * 31 + research.level;
                        }
                        break;
                    case ScreenId.Army:
                        foreach (var unit in state.units)
                        {
                            hash = hash * 31 + unit.id.GetHashCode();
                            hash = hash * 31 + unit.count;
                            hash = hash * 31 +
                                   (state.CanTrainUnit(unit.id) ? 1 : 0);
                        }

                        hash = hash * 31 + state.GetBuilding("barracks").level;
                        hash = hash * 31 + state.wounded;
                        hash = hash * 31 + state.formationRevision;
                        hash = hash * 31 + state.FormationPower;
                        hash = AddJobRevision(hash, state.training);
                        break;
                    case ScreenId.Heroes:
                        foreach (var hero in state.heroes)
                        {
                            hash = hash * 31 + hero.id.GetHashCode();
                            hash = hash * 31 + hero.level;
                            hash = hash * 31 + hero.skillLevel;
                            hash = hash * 31 + (hero.assigned ? 1 : 0);
                            hash = hash * 31 + hero.stars;
                            hash = hash * 31 + hero.shards;
                            hash = hash * 31 + hero.weaponTier;
                            hash = hash * 31 + hero.armorTier;
                        }

                        hash = hash * 31 + (state.gold >= 700 ? 1 : 0);
                        break;
                    case ScreenId.Map:
                        state.EnsureDailyOrder(GameService.Now);
                        hash = hash * 31 + state.victories;
                        hash = hash * 31 + state.seasonPoints;
                        hash = hash * 31 + state.food;
                        hash = hash * 31 + state.campaignProgress;
                        hash = hash * 31 + state.claimedMissionMask;
                        hash = hash * 31 + state.dailyOrderDay;
                        hash = hash * 31 + state.dailyOrderIndex;
                        hash = hash * 31 + (state.dailyOrderClaimed ? 1 : 0);
                        hash = hash * 31 + state.dailyUnitsTrained;
                        hash = hash * 31 + state.dailyBuildingsUpgraded;
                        hash = hash * 31 + state.dailyBattles;
                        hash = hash * 31 + state.dailyKills;
                        hash = hash * 31 + state.units.Sum(item => item.count);
                        foreach (var stars in state.campaignBestStars)
                        {
                            hash = hash * 31 + stars;
                        }

                        foreach (var hero in state.heroes)
                        {
                            hash = hash * 31 + (hero.assigned ? 1 : 0);
                        }

                        hash = AddJobRevision(hash, state.expedition);
                        hash = AddJobRevision(hash, state.worldMarch);
                        hash = hash * 31 + state.worldNodeClaimedMask;
                        hash = hash * 31 + state.worldNodeScoutedMask;
                        foreach (var stars in state.worldNodeStars)
                        {
                            hash = hash * 31 + stars;
                        }
                        break;
                    case ScreenId.Alliance:
                        hash = hash * 31 + state.allianceLevel;
                        hash = hash * 31 + state.allianceContribution;
                        hash = hash * 31 + state.allianceWarPoints;
                        hash = hash * 31 + state.allianceRank;
                        hash = hash * 31 + state.allianceHelpTokens;
                        hash = hash * 31 + state.allianceRallyEndsAt.GetHashCode();
                        hash = hash * 31 + state.pvpRating;
                        hash = hash * 31 + state.pvpWins;
                        hash = hash * 31 + state.pvpLosses;
                        hash = hash * 31 + (state.pvpOpponent?.power ?? 0);
                        hash = hash * 31 + (state.allianceChat?.Length ?? 0);
                        break;
                }

                return hash;
            }
        }

        private static int AddJobRevision(int hash, TimedJob job)
        {
            unchecked
            {
                if (job == null)
                {
                    return hash * 31;
                }

                hash = hash * 31 + job.kind.GetHashCode();
                hash = hash * 31 + job.targetId.GetHashCode();
                hash = hash * 31 + job.quantity;
                hash = hash * 31 + job.endsAt.GetHashCode();
                return hash;
            }
        }

        private void RefreshHeader()
        {
            var state = game.State;
            resourceTexts[ResourceType.Food].text = $"ERZAK\n{state.food:N0}";
            resourceTexts[ResourceType.Wood].text = $"KERES.\n{state.wood:N0}";
            resourceTexts[ResourceType.Stone].text = $"TAŞ\n{state.stone:N0}";
            resourceTexts[ResourceType.Gold].text = $"ALTIN\n{state.gold:N0}";
            powerText.text = $"DEVLET GÜCÜ\n{state.Power:N0}";
            eventText.text = state.lastEvent;
        }

        private string JobTitle(TimedJob job)
        {
            return job.kind switch
            {
                "construction" => GameRules.Buildings.First(item => item.id == job.targetId).title,
                "training" => GameRules.Units.First(item => item.id == job.targetId).title,
                "expedition" => "Karacahisar yürüyüşü",
                "research" => ImperialRules.Research.First(item => item.id == job.targetId).title,
                "world_march" => ImperialRules.WorldNodes.First(item => item.id == job.targetId).title,
                _ => "Devam eden emir"
            };
        }

        private static string CostText(ResourceCost cost)
        {
            var parts = new List<string>();
            if (cost.food > 0) parts.Add($"{cost.food:N0} Erzak");
            if (cost.wood > 0) parts.Add($"{cost.wood:N0} Kereste");
            if (cost.stone > 0) parts.Add($"{cost.stone:N0} Taş");
            if (cost.gold > 0) parts.Add($"{cost.gold:N0} Altın");
            return string.Join(" · ", parts);
        }

        private Image CreatePanel(Transform parent, string name, Color color)
        {
            var panel = new GameObject(name, typeof(RectTransform), typeof(Image));
            panel.transform.SetParent(parent, false);
            var image = panel.GetComponent<Image>();
            image.color = color;
            image.raycastTarget = false;
            return image;
        }

        private Text CreateText(
            Transform parent,
            string value,
            int size,
            Color color,
            TextAnchor alignment,
            FontStyle style)
        {
            var textObject = new GameObject("Metin", typeof(RectTransform), typeof(Text));
            textObject.transform.SetParent(parent, false);
            var text = textObject.GetComponent<Text>();
            text.font = font;
            text.text = value;
            text.fontSize = size;
            text.color = color;
            text.alignment = alignment;
            text.fontStyle = style;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Truncate;
            text.raycastTarget = false;
            return text;
        }

        private Button CreateButton(
            Transform parent,
            string label,
            UnityEngine.Events.UnityAction action,
            Color color,
            int fontSize)
        {
            var buttonObject = new GameObject(
                $"{label} Düğmesi",
                typeof(RectTransform),
                typeof(Image),
                typeof(Button));
            buttonObject.transform.SetParent(parent, false);

            var image = buttonObject.GetComponent<Image>();
            image.color = color;
            var button = buttonObject.GetComponent<Button>();
            button.targetGraphic = image;
            if (action != null)
            {
                button.onClick.AddListener(() =>
                {
                    CihanAudioDirector.Instance?.PlayUiConfirm();
                    action();
                });
            }

            var text = CreateText(
                buttonObject.transform,
                label,
                fontSize,
                Ivory,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            Stretch(text.rectTransform, 8f, 8f, 5f, 5f);
            SetButtonColor(button, color);
            return button;
        }

        private static void SetButtonColor(Button button, Color normal)
        {
            var colors = button.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = new Color(1.08f, 1.08f, 1.08f, 1f);
            colors.pressedColor = new Color(0.82f, 0.82f, 0.82f, 1f);
            colors.selectedColor = colors.highlightedColor;
            colors.disabledColor = new Color(0.55f, 0.55f, 0.55f, 0.75f);
            colors.colorMultiplier = 1f;
            colors.fadeDuration = 0.12f;
            button.colors = colors;
            if (button.targetGraphic is Image image)
            {
                image.color = normal;
            }
        }

        private static void ClearChildren(Transform parent)
        {
            for (var index = parent.childCount - 1; index >= 0; index--)
            {
                var child = parent.GetChild(index);
                child.SetParent(null, false);
                Destroy(child.gameObject);
            }
        }

        private static void Stretch(
            RectTransform rect,
            float left = 0f,
            float right = 0f,
            float top = 0f,
            float bottom = 0f)
        {
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = new Vector2(left, bottom);
            rect.offsetMax = new Vector2(-right, -top);
        }

        private static void SetAnchoredRect(
            RectTransform rect,
            Vector2 anchorMin,
            Vector2 anchorMax,
            Vector2 sizeDelta,
            Vector2 anchoredPosition)
        {
            rect.anchorMin = anchorMin;
            rect.anchorMax = anchorMax;
            rect.sizeDelta = sizeDelta;
            rect.anchoredPosition = anchoredPosition;
        }
    }
}
