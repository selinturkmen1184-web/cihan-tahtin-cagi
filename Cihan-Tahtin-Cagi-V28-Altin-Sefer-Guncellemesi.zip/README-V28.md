# CİHAN V28 · Altın Sefer

V28, önceki koyu turkuaz ve kahverengi ağırlıklı görünümü kaldırır. Yeni sanat yönü telefonda okunabilirlik için lacivert, vermilion kırmızısı, fildişi ve sıcak altın üzerine kuruludur.

## Görsel değişiklikler

- Piyade, okçu, süvari, topçu ve komutan birlikleri 1024 × 1536 çözünürlükte yeniden renklendirildi.
- Birlik görselleri gerçek alfa kanallı PNG olarak hazırlandı.
- Savaş alanı açık gökyüzü, pale taş surlar ve üç belirgin ilerleme koridoruyla yenilendi.
- Dost rengi turkuazdan kraliyet lacivertine; düşman rengi daha temiz vermilion kırmızısına geçirildi.
- Dünya ışığı ve ortam ışığı aydınlatıldı; kahverengi ve koyu yeşil renk dökümü azaltıldı.
- Ana arayüz başlığı `V28 · ALTIN SEFER` olarak güncellendi.

## Sürüm

- Uygulama sürümü: `0.28.0`
- Android sürüm kodu: `280`
- iOS build numarası: `280`
- Android çıktı adı: `Cihan-Tahtin-Cagi-v28.apk`

## Yeni kaynaklar

- `cihan-battlefield-v28.png`
- `cihan-unit-infantry-v28.png`
- `cihan-unit-archer-v28.png`
- `cihan-unit-cavalry-v28.png`
- `cihan-unit-siege-v28.png`
- `cihan-unit-commander-v28.png`

V27 birlikleri geri dönüş kaynağı olarak projede korunmuştur.
