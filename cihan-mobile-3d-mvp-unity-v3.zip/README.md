# CİHAN: Tahtın Çağı — 3B Mobil Savaş MVP

Unity ile iOS ve Android için geliştirilen mobil 4X strateji oyununun ilk
oynanabilir temelidir. Proje; CİHAN'a ait özgün isim, sanat yönü ve oyun
kurallarıyla sıfırdan hazırlanmıştır.

## Bu sürümde

- Dikey mobil arayüz
- Erzak, kereste, taş ve altın üretimi
- Çevrimdışı kaynak birikimi
- Başkent ve geliştirilebilir binalar
- İnşa kuyruğu ve hızlandırılmış demo sayaçları
- Piyade, okçu, süvari ve kuşatma birliği eğitimi
- Üç komutan, iki kişilik sefer kadrosu ve yetenek geliştirme
- Yerel kayıt ve kaldığı yerden devam
- Dünya haritası ve hızlandırılmış sefer döngüsü
- Gerçek zamanlı izometrik 3B Karacahisar kuşatma alanı
- Zırhlı piyade mangaları, okçu birlikleri, atlı süvariler ve tekerlekli Şahi topları
- 3B kale, surlar, kuleler, sefer kampı, savaş alanı ve sancaklar
- Mobil ışıklandırma, metal/deri/taş malzemeler ve yumuşak gölgeler
- Otomatik hedef seçimi, yakın/menzilli saldırı ve sınıf avantajları
- Yürüme, saldırı, silah savurma, ok/top mermisi ve düşme animasyonları
- Can göstergesi, ölüm, takviye emirleri ve geri çekilme
- Zafer/yenilgi raporu, kayıp, yaralı ve ganimet sonucu
- EditMode oyun kuralı testleri

## Açılış

1. Unity Hub üzerinden bu klasörü proje olarak ekleyin.
2. Unity 6 LTS ile açın.
3. Unity ilk açılışta `Assets/Cihan/Scenes/Main.unity` sahnesini hazırlar.
4. Play düğmesine basın.

Arayüz ve oyun nesneleri çalışma anında kodla oluşturulur; bu nedenle prefab
veya elle sahne kurulumu gerektirmez.

`DÜNYA > Canlı Karacahisar Kuşatması > SAVAŞA GİR` yoluyla oynanabilir
savaş ekranı açılır. Alt sıradaki piyade, okçu ve süvari takviyeleri her
savaşta bir kez kullanılabilir.

Savaş sırasında:

- Tek parmakla sürükleme: kamerayı savaş alanında kaydırır.
- İki parmakla yakınlaştırma: kamerayı yakınlaştırır veya uzaklaştırır.
- Editörde fare tekerleği: kamera yakınlığını değiştirir.

## Doğrulama

Unity'den bağımsız saf oyun kuralları `Validation` projesiyle de sınanabilir:

```bash
dotnet run --project Validation/Cihan.DomainValidation.csproj --configuration Release
dotnet run --project Validation/Cihan.SyntaxValidation.csproj --configuration Release
```

Bu doğrulama kaynak üretimini, bina ve asker kuyruklarını, kahraman sınırını,
canlı orduların çarpışmasını, hasar/kayıp oluşmasını, savaş sonucunu ve tüm
Unity C# dosyalarının sözdizimini kapsar.

## Mobil paket

Unity içinden `Cihan > Mobil MVP Kurulumunu Yenile` menüsü çalıştırıldıktan
sonra:

- Android: `File > Build Profiles > Android`
- iOS: `File > Build Profiles > iOS`

Apple ve Google mağaza yayını için geliştirici hesapları, imzalama
sertifikaları, final ikonları ve mağaza metinleri ayrıca gereklidir.
