#!/bin/zsh
set -e

project_dir="$(cd "$(dirname "$0")" && pwd)"
export CIHAN_APK_OUTPUT="$project_dir/Builds/Cihan-Tahtin-Cagi-v7.apk"

exec /Applications/Unity/Unity.app/Contents/MacOS/Unity \
  -batchmode \
  -nographics \
  -quit \
  -projectPath "$project_dir" \
  -executeMethod Cihan.Editor.CihanAndroidBuilder.Build \
  -logFile /private/tmp/cihan-v7-build.log
