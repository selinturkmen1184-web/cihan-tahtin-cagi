# CİHAN Mobil Oyun Yol Haritası

## Aşama 1 — Temel oyun döngüsü

Durum: Oynanabilir prototip tamamlandı.

- Mobil Unity proje yapısı
- Başkent ekranı
- Dört temel kaynak
- Çevrimdışı üretim
- Bina geliştirme kuyruğu
- Dört asker sınıfı
- Asker eğitim kuyruğu
- Yerel kayıt
- Dünya haritası ve sefer sonucu

## Aşama 2 — Gerçek savaş sahnesi

Durum: Oynanabilir 2D mobil prototip tamamlandı.

- [x] Özgün 2D mobil kuşatma alanı
- [x] Piyade, okçu, süvari ve kuşatma birimlerinin hareketi
- [x] Hedef seçme ve otomatik saldırı
- [x] Birlik sınıfı avantajları
- [x] Komutan atama ve savaş bonusları
- [x] Savaş içi tek kullanımlık takviye emirleri
- [x] Yaralı ve hastane sonucu
- [x] Zafer/geri çekilme savaş raporu
- [ ] Final 3D asker modelleri, animasyon ve ses paketi

## Aşama 3 — Çevrim içi sunucu

- Oyuncu üyeliği
- Sunucu taraflı kalıcı kayıt
- PostgreSQL ve Redis
- Sunucu taraflı ekonomi ve sayaç doğrulaması
- Dünya haritası yürüyüşleri
- PvE ve asenkron PvP
- Yönetim ve canlı operasyon paneli
- Günlük veritabanı yedeği

## Aşama 4 — Sosyal ve canlı ürün

- İttifaklar ve roller
- İttifak sohbeti
- Ortak ralli ve takviye
- Sezonlar ve sıralama
- Bildirimler
- Mağaza ve uygulama içi satın alma
- Analitik, hata izleme ve hile koruması

## Projenin teslim ve sahiplik paketi

Mağaza yayınına geçerken aşağıdaki hesap ve üretim dosyaları proje sahibinin
kontrolünde tutulmalıdır:

- Unity projesinin tamamı ve Git deposu
- Sunucu kaynak kodu, API belgesi ve veritabanı migration dosyaları
- Lisanslı görsel, ses ve fontların kaynakları
- Android imzalama bilgilerinin sahipliği
- Apple/Google geliştirici hesaplarının sahipliği
