#!/bin/zsh
set -e

script_dir="$(cd "$(dirname "$0")" && pwd)"
project_dir="${CIHAN_IOS_PROJECT_DIR:-$script_dir}"
unity_app=/Applications/Unity/Unity.app
xcode_app=/Applications/Xcode.app
ios_support=/Applications/Unity/PlaybackEngines/iOSSupport

export CIHAN_IOS_XCODE_OUTPUT="${CIHAN_IOS_XCODE_OUTPUT:-/private/tmp/Cihan-Tahtin-Cagi-iOS-v8-Xcode}"
archive_path="${CIHAN_IOS_ARCHIVE_PATH:-/private/tmp/Cihan-Tahtin-Cagi-iOS-v8.xcarchive}"
ipa_dir="${CIHAN_IOS_IPA_DIR:-/private/tmp/Cihan-Tahtin-Cagi-iOS-v8-IPA}"
ios_log=/private/tmp/cihan-v8-ios-build.log

if [[ ! -d "$ios_support" ]]; then
  echo "EKSİK: Unity Hub > Installs > Unity 6000.0.0f1 > Add modules > iOS Build Support"
  exit 2
fi

if [[ "$CIHAN_IOS_XCODE_ONLY" != "1" ]]; then
  if [[ ! -d "$xcode_app" ]]; then
    echo "EKSİK: App Store üzerinden Xcode kurulmalı."
    exit 3
  fi

  if [[ -z "$CIHAN_APPLE_TEAM_ID" ]]; then
    echo "EKSİK: CIHAN_APPLE_TEAM_ID ayarlanmalı (Apple Developer Team ID)."
    exit 4
  fi

  export DEVELOPER_DIR="$xcode_app/Contents/Developer"
fi

"$unity_app/Contents/MacOS/Unity" \
  -batchmode \
  -nographics \
  -quit \
  -projectPath "$project_dir" \
  -executeMethod Cihan.Editor.CihanIOSBuilder.Build \
  -logFile "$ios_log"

if [[ ! -d "$CIHAN_IOS_XCODE_OUTPUT/Unity-iPhone.xcodeproj" ]]; then
  echo "HATA: Unity iOS Xcode projesi oluşturulamadı. Log: $ios_log"
  exit 5
fi

if [[ "$CIHAN_IOS_XCODE_ONLY" == "1" ]]; then
  echo "CİHAN iOS Xcode projesi hazır: $CIHAN_IOS_XCODE_OUTPUT"
  exit 0
fi

xcodebuild \
  -project "$CIHAN_IOS_XCODE_OUTPUT/Unity-iPhone.xcodeproj" \
  -scheme Unity-iPhone \
  -configuration Release \
  -destination 'generic/platform=iOS' \
  -archivePath "$archive_path" \
  DEVELOPMENT_TEAM="$CIHAN_APPLE_TEAM_ID" \
  CODE_SIGN_STYLE=Automatic \
  -allowProvisioningUpdates \
  archive

export_plist=/private/tmp/Cihan-Tahtin-Cagi-iOS-v8-ExportOptions.plist
cp "$script_dir/ios/ExportOptions.plist" "$export_plist"
/usr/libexec/PlistBuddy -c "Set :teamID $CIHAN_APPLE_TEAM_ID" "$export_plist"

xcodebuild \
  -exportArchive \
  -archivePath "$archive_path" \
  -exportPath "$ipa_dir" \
  -exportOptionsPlist "$export_plist" \
  -allowProvisioningUpdates

echo "CİHAN iPhone IPA hazır: $ipa_dir"
