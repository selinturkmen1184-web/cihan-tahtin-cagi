# CİHAN iPhone derleme notları

Hazırlanan iOS sürümü:

- Uygulama kimliği: `com.selinturkmen.cihan`
- Sürüm: `0.8.0`
- Build: `80`
- Minimum sistem: iOS 15
- Grafik altyapısı: Metal
- Unity betik altyapısı: IL2CPP
- Ekran: dikey

## Gerekli kurulumlar

1. Unity Hub içinde Unity `6000.0.0f1` kurulumuna **iOS Build Support** modülünü ekleyin.
2. App Store üzerinden Xcode'u kurun ve bir kez açarak lisansı kabul edin.
3. Xcode > Settings > Accounts bölümünde Apple hesabını ekleyin.
4. Apple Developer Team ID değerini belirleyin.

## Xcode projesi ve IPA oluşturma

```zsh
export CIHAN_APPLE_TEAM_ID="APPLE_TEAM_ID"
./build-ios-v8.sh
```

Çıktılar iCloud tarafından boşaltılmaması için `/private/tmp` altında oluşturulur.

TestFlight/App Store dağıtımı için ücretli Apple Developer Program üyeliği ve
App Store Connect üzerinde uygulama kaydı gerekir. Ücretsiz Apple hesabıyla
yalnızca bağlı kişisel iPhone üzerinde geliştirme kurulumu yapılabilir.
