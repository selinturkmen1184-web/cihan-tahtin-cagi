using System;
using System.Collections.Generic;
using Cihan.Domain;
using Cihan.Services;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Cihan.UI
{
    public sealed class CampaignStageMarker : MonoBehaviour
    {
        public int stageIndex;
    }

    public sealed class CihanCampaignWorld3D : MonoBehaviour,
        IPointerClickHandler,
        IBeginDragHandler,
        IDragHandler,
        IEndDragHandler,
        IScrollHandler
    {
        private const int MapLayer = 29;
        private static readonly Vector3 WorldOffset = new(5200f, 0f, 0f);
        private static readonly Vector3[] StagePositions =
        {
            new(-7.5f, 0f, -3.8f),
            new(0.2f, 0f, 2.1f),
            new(8.5f, 0f, 5.2f)
        };

        private readonly List<Material> materials = new();
        private readonly List<Transform> flags = new();
        private readonly List<Transform> smoke = new();
        private readonly List<Transform> trees = new();
        private readonly List<Transform> stageAnchors = new();

        private GameService game;
        private Action<int> selected;
        private GameObject worldRoot;
        private Camera mapCamera;
        private RenderTexture renderTexture;
        private Transform selectionRing;
        private Transform army;
        private Transform armyFlag;
        private Material grass;
        private Material darkGrass;
        private Material earth;
        private Material road;
        private Material water;
        private Material stone;
        private Material paleStone;
        private Material wood;
        private Material teal;
        private Material crimson;
        private Material gold;
        private Material white;
        private float yaw = 30f;
        private float pitch = 42f;
        private float zoom = 18.5f;
        private bool dragging;
        private int selectedStage;

        public void Configure(GameService service, Action<int> onSelected)
        {
            game = service;
            selected = onSelected;
            BuildMaterials();
            BuildWorld();
            BuildCamera();
            SelectStage(
                Mathf.Clamp(game.State.campaignProgress, 0, StagePositions.Length - 1),
                false);
        }

        private void BuildMaterials()
        {
            grass = CreateMaterial(new Color32(79, 96, 62, 255), 0f, 0.08f);
            darkGrass = CreateMaterial(new Color32(44, 68, 47, 255), 0f, 0.06f);
            earth = CreateMaterial(new Color32(116, 86, 54, 255), 0f, 0.07f);
            road = CreateMaterial(new Color32(163, 137, 88, 255), 0f, 0.12f);
            water = CreateMaterial(new Color32(42, 98, 121, 255), 0.05f, 0.52f);
            stone = CreateMaterial(new Color32(101, 104, 96, 255), 0f, 0.2f);
            paleStone = CreateMaterial(new Color32(174, 166, 142, 255), 0f, 0.22f);
            wood = CreateMaterial(new Color32(92, 58, 32, 255), 0f, 0.12f);
            teal = CreateMaterial(new Color32(40, 126, 112, 255), 0.08f, 0.3f);
            crimson = CreateMaterial(new Color32(139, 49, 43, 255), 0.08f, 0.28f);
            gold = CreateMaterial(new Color32(221, 175, 75, 255), 0.3f, 0.5f);
            white = CreateMaterial(new Color32(219, 215, 199, 255), 0f, 0.2f);
        }

        private void BuildWorld()
        {
            worldRoot = new GameObject("CİHAN · Canlı Batı Seferi Haritası");
            worldRoot.transform.position = WorldOffset;

            Box(
                "Batı Eyaleti",
                new Vector3(0f, -0.5f, 0f),
                new Vector3(31f, 1f, 23f),
                grass,
                worldRoot.transform);
            Box(
                "Kuzey Yaylası",
                new Vector3(5f, -0.12f, 7.7f),
                new Vector3(19f, 0.32f, 6.6f),
                darkGrass,
                worldRoot.transform);
            Box(
                "Güney Bozkırı",
                new Vector3(-6f, -0.14f, -7.5f),
                new Vector3(18f, 0.28f, 6.5f),
                earth,
                worldRoot.transform);
            BuildRiver();
            BuildRoads();
            BuildCapital();
            BuildStageFortresses();
            BuildForestsAndHills();
            BuildVillages();
            BuildArmy();
            BuildSelectionRing();
            SetLayerRecursively(worldRoot, MapLayer);
        }

        private void BuildCamera()
        {
            var cameraObject = new GameObject("Batı Seferi Kamerası");
            mapCamera = cameraObject.AddComponent<Camera>();
            mapCamera.orthographic = true;
            mapCamera.orthographicSize = zoom;
            mapCamera.clearFlags = CameraClearFlags.SolidColor;
            mapCamera.backgroundColor = new Color32(34, 52, 58, 255);
            mapCamera.nearClipPlane = 0.1f;
            mapCamera.farClipPlane = 160f;
            mapCamera.allowHDR = true;
            mapCamera.allowMSAA = true;
            mapCamera.cullingMask = 1 << MapLayer;

            renderTexture = new RenderTexture(
                1024,
                1024,
                24,
                RenderTextureFormat.ARGB32)
            {
                name = "CİHAN Canlı Sefer Haritası",
                antiAliasing = 4,
                filterMode = FilterMode.Bilinear
            };
            renderTexture.Create();
            mapCamera.targetTexture = renderTexture;

            var rawImage = GetComponent<RawImage>();
            rawImage.texture = renderTexture;
            rawImage.color = Color.white;
            rawImage.raycastTarget = true;

            var sunObject = new GameObject("Sefer Güneşi");
            sunObject.transform.SetParent(worldRoot.transform, false);
            sunObject.transform.rotation = Quaternion.Euler(50f, -42f, 0f);
            var sun = sunObject.AddComponent<Light>();
            sun.type = LightType.Directional;
            sun.color = new Color32(255, 224, 172, 255);
            sun.intensity = 1.25f;
            sun.shadows = LightShadows.Soft;
            sun.shadowStrength = 0.72f;
            sun.cullingMask = 1 << MapLayer;

            var fillObject = new GameObject("Sefer Dolgu Işığı");
            fillObject.transform.SetParent(worldRoot.transform, false);
            fillObject.transform.rotation = Quaternion.Euler(65f, 125f, 0f);
            var fill = fillObject.AddComponent<Light>();
            fill.type = LightType.Directional;
            fill.color = new Color32(108, 157, 174, 255);
            fill.intensity = 0.35f;
            fill.cullingMask = 1 << MapLayer;

            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Trilight;
            RenderSettings.ambientSkyColor = new Color32(105, 130, 139, 255);
            RenderSettings.ambientEquatorColor = new Color32(76, 83, 71, 255);
            RenderSettings.ambientGroundColor = new Color32(36, 40, 33, 255);
            RefreshCamera();
        }

        private void BuildRiver()
        {
            var riverRoot = new GameObject("Aksu Nehri").transform;
            riverRoot.SetParent(worldRoot.transform, false);
            var points = new[]
            {
                new Vector3(-14f, 0.03f, 7.2f),
                new Vector3(-8f, 0.03f, 4.8f),
                new Vector3(-3f, 0.03f, 1.5f),
                new Vector3(1f, 0.03f, -2f),
                new Vector3(7f, 0.03f, -6.2f),
                new Vector3(14f, 0.03f, -8.2f)
            };
            for (var index = 0; index < points.Length - 1; index++)
            {
                BoxBetween(
                    $"Nehir Kolu {index + 1}",
                    points[index],
                    points[index + 1],
                    1.65f,
                    0.12f,
                    water,
                    riverRoot);
            }

            BoxBetween(
                "Taş Köprü",
                new Vector3(-4.1f, 0.28f, 0.1f),
                new Vector3(-2.2f, 0.28f, 2.5f),
                0.9f,
                0.42f,
                paleStone,
                riverRoot);
        }

        private void BuildRoads()
        {
            var roadRoot = new GameObject("Sefer Yolları").transform;
            roadRoot.SetParent(worldRoot.transform, false);
            var capital = new Vector3(-12.3f, 0.12f, -8.2f);
            BoxBetween("Payitaht Yolu", capital, StagePositions[0], 0.72f, 0.16f, road, roadRoot);
            BoxBetween("Karacahisar Yolu", StagePositions[0], StagePositions[1], 0.72f, 0.16f, road, roadRoot);
            BoxBetween("Geçit Yolu", StagePositions[1], StagePositions[2], 0.72f, 0.16f, road, roadRoot);

            for (var index = 0; index < 18; index++)
            {
                var t = index / 17f;
                var point = BezierRoute(t);
                Cylinder(
                    $"Sefer Taşı {index + 1}",
                    point + Vector3.up * 0.18f,
                    new Vector3(0.12f, 0.2f, 0.12f),
                    index <= game.State.campaignProgress * 6 ? gold : stone,
                    roadRoot);
            }
        }

        private void BuildCapital()
        {
            var capital = new GameObject("CİHAN Payitahtı").transform;
            capital.SetParent(worldRoot.transform, false);
            capital.localPosition = new Vector3(-12.3f, 0f, -8.2f);

            Box("Payitaht Suru", new Vector3(0f, 0.8f, 0f), new Vector3(4.2f, 1.4f, 3.6f), stone, capital);
            Box("Payitaht İç Şehri", new Vector3(0f, 1.2f, 0f), new Vector3(3.1f, 1.5f, 2.6f), paleStone, capital);
            Cylinder("Payitaht Kubbesi", new Vector3(0f, 2.3f, 0f), new Vector3(1.35f, 0.55f, 1.35f), teal, capital);
            AddFlag(capital, new Vector3(0f, 4f, 0f), teal);
        }

        private void BuildStageFortresses()
        {
            for (var index = 0; index < StagePositions.Length; index++)
            {
                var anchor = new GameObject($"{index + 1}. Cephe Kalesi");
                anchor.transform.SetParent(worldRoot.transform, false);
                anchor.transform.localPosition = StagePositions[index];
                var marker = anchor.AddComponent<CampaignStageMarker>();
                marker.stageIndex = index;
                var collider = anchor.AddComponent<BoxCollider>();
                collider.center = new Vector3(0f, 1.5f, 0f);
                collider.size = new Vector3(5.5f, 5f, 5.5f);
                stageAnchors.Add(anchor.transform);

                var conquered = index < game.State.campaignProgress;
                var available = index == game.State.campaignProgress;
                var banner = conquered ? teal : available ? crimson : stone;
                var scale = 0.88f + index * 0.12f;
                Box("Hisar Kaidesi", new Vector3(0f, 0.65f, 0f), new Vector3(4.4f, 1.3f, 3.8f) * scale, stone, anchor.transform);
                Box("Hisar İç Kale", new Vector3(0f, 1.45f, 0f), new Vector3(3.1f, 1.65f, 2.7f) * scale, paleStone, anchor.transform);
                for (var tower = -1; tower <= 1; tower += 2)
                {
                    Cylinder(
                        "Hisar Kulesi",
                        new Vector3(tower * 1.75f * scale, 1.65f, 0f),
                        new Vector3(0.75f, 1.4f, 0.75f) * scale,
                        stone,
                        anchor.transform);
                    Cylinder(
                        "Kule Külahı",
                        new Vector3(tower * 1.75f * scale, 3.25f * scale, 0f),
                        new Vector3(0.9f, 0.36f, 0.9f) * scale,
                        banner,
                        anchor.transform);
                }

                Box("Hisar Kapısı", new Vector3(0f, 0.85f, -1.95f * scale), new Vector3(1.25f, 1.6f, 0.28f), wood, anchor.transform);
                AddFlag(anchor.transform, new Vector3(0f, 4.2f * scale, 0f), banner);
                AddSmoke(anchor.transform, new Vector3(1.1f, 3.2f * scale, 0.6f));
            }
        }

        private void BuildForestsAndHills()
        {
            var forest = new GameObject("Batı Ormanları").transform;
            forest.SetParent(worldRoot.transform, false);
            for (var index = 0; index < 34; index++)
            {
                var x = -13f + Mathf.Repeat(index * 4.73f, 26f);
                var z = index % 2 == 0
                    ? 8.3f + Mathf.Sin(index * 0.71f) * 1.5f
                    : -8.6f + Mathf.Cos(index * 0.83f) * 1.2f;
                var tree = new GameObject($"Çam {index + 1}").transform;
                tree.SetParent(forest, false);
                tree.localPosition = new Vector3(x, 0f, z);
                Cylinder("Gövde", new Vector3(0f, 0.65f, 0f), new Vector3(0.16f, 0.65f, 0.16f), wood, tree);
                Cylinder("Yaprak", new Vector3(0f, 1.55f, 0f), new Vector3(0.75f, 1.05f, 0.75f), darkGrass, tree, 7);
                trees.Add(tree);
            }

            var hillPositions = new[]
            {
                new Vector3(-12f, 0.2f, 3f),
                new Vector3(4f, 0.2f, 8f),
                new Vector3(12f, 0.2f, 0f),
                new Vector3(8f, 0.2f, -8f)
            };
            for (var index = 0; index < hillPositions.Length; index++)
            {
                Sphere(
                    $"Yayla {index + 1}",
                    hillPositions[index],
                    new Vector3(4.1f, 1.15f, 3.1f),
                    index % 2 == 0 ? darkGrass : earth,
                    worldRoot.transform);
            }
        }

        private void BuildVillages()
        {
            var villagePositions = new[]
            {
                new Vector3(-8.8f, 0f, 5.8f),
                new Vector3(4.7f, 0f, -4.8f),
                new Vector3(11.5f, 0f, 8.2f)
            };
            for (var villageIndex = 0; villageIndex < villagePositions.Length; villageIndex++)
            {
                var village = new GameObject($"Köy {villageIndex + 1}").transform;
                village.SetParent(worldRoot.transform, false);
                village.localPosition = villagePositions[villageIndex];
                for (var house = 0; house < 3; house++)
                {
                    var x = (house - 1) * 1.1f;
                    Box("Köy Evi", new Vector3(x, 0.42f, 0f), new Vector3(0.82f, 0.84f, 0.72f), paleStone, village);
                    Cylinder("Köy Çatısı", new Vector3(x, 1.05f, 0f), new Vector3(0.58f, 0.28f, 0.58f), crimson, village, 6);
                }
                AddSmoke(village, new Vector3(0.7f, 1.4f, 0f));
            }
        }

        private void BuildArmy()
        {
            army = new GameObject("Yürüyen CİHAN Ordusu").transform;
            army.SetParent(worldRoot.transform, false);
            for (var row = 0; row < 3; row++)
            {
                for (var column = 0; column < 3; column++)
                {
                    var soldier = new GameObject("Sefer Askeri").transform;
                    soldier.SetParent(army, false);
                    soldier.localPosition = new Vector3(
                        (column - 1) * 0.38f,
                        0f,
                        (row - 1) * 0.42f);
                    Capsule("Zırhlı Gövde", new Vector3(0f, 0.46f, 0f), new Vector3(0.22f, 0.34f, 0.2f), teal, soldier);
                    Sphere("Miğfer", new Vector3(0f, 0.92f, 0f), Vector3.one * 0.19f, stone, soldier);
                    Box("Mızrak", new Vector3(0.24f, 0.83f, 0f), new Vector3(0.045f, 1.1f, 0.045f), wood, soldier);
                }
            }

            Box("Ordu Sancak Direği", new Vector3(0f, 1.25f, 0f), new Vector3(0.07f, 2.5f, 0.07f), gold, army);
            armyFlag = Box("Ordu Sancağı", new Vector3(0.55f, 2.05f, 0f), new Vector3(1.05f, 0.62f, 0.08f), teal, army).transform;
            army.localScale = Vector3.one * 0.9f;
        }

        private void BuildSelectionRing()
        {
            var ring = Cylinder(
                "Seçili Cephe Mührü",
                StagePositions[0] + Vector3.up * 0.11f,
                new Vector3(3.2f, 0.05f, 3.2f),
                gold,
                worldRoot.transform,
                32);
            var collider = ring.GetComponent<Collider>();
            if (collider != null)
            {
                collider.enabled = false;
            }
            selectionRing = ring.transform;
        }

        private void Update()
        {
            if (mapCamera == null || game == null)
            {
                return;
            }

            if (!dragging && Input.touchCount == 0)
            {
                yaw += Time.unscaledDeltaTime * 0.28f;
            }

            var routeProgress = Mathf.Repeat(Time.unscaledTime * 0.035f, 1f);
            var reached = Mathf.Clamp(game.State.campaignProgress, 0, StagePositions.Length);
            var minT = Mathf.Clamp01(reached / 3f - 0.25f);
            var maxT = Mathf.Clamp01((reached + 1f) / 3f);
            var routeT = Mathf.Lerp(minT, maxT, routeProgress);
            var armyPosition = BezierRoute(routeT);
            var nextPosition = BezierRoute(Mathf.Clamp01(routeT + 0.012f));
            army.localPosition = armyPosition + Vector3.up * 0.1f;
            var direction = nextPosition - armyPosition;
            if (direction.sqrMagnitude > 0.001f)
            {
                army.localRotation = Quaternion.LookRotation(direction, Vector3.up);
            }
            army.localPosition += Vector3.up *
                                  (Mathf.Abs(Mathf.Sin(Time.unscaledTime * 7f)) * 0.06f);

            if (armyFlag != null)
            {
                var scale = armyFlag.localScale;
                scale.x = 1f + Mathf.Sin(Time.unscaledTime * 3.5f) * 0.1f;
                armyFlag.localScale = scale;
            }

            for (var index = 0; index < flags.Count; index++)
            {
                var scale = flags[index].localScale;
                scale.x = 1f + Mathf.Sin(Time.unscaledTime * 2.7f + index) * 0.08f;
                flags[index].localScale = scale;
            }

            for (var index = 0; index < smoke.Count; index++)
            {
                var puff = smoke[index];
                puff.localScale = Vector3.one *
                                  (0.72f + Mathf.Sin(Time.unscaledTime + index) * 0.08f);
            }

            if (selectionRing != null)
            {
                var pulse = 1f + Mathf.Sin(Time.unscaledTime * 3.4f) * 0.08f;
                selectionRing.localScale = new Vector3(3.2f, 0.05f, 3.2f) * pulse;
            }

            RefreshCamera();
        }

        private Vector3 BezierRoute(float t)
        {
            var start = new Vector3(-12.3f, 0.12f, -8.2f);
            if (t < 1f / 3f)
            {
                return Vector3.Lerp(start, StagePositions[0], t * 3f);
            }
            if (t < 2f / 3f)
            {
                return Vector3.Lerp(StagePositions[0], StagePositions[1], (t - 1f / 3f) * 3f);
            }
            return Vector3.Lerp(StagePositions[1], StagePositions[2], (t - 2f / 3f) * 3f);
        }

        private void RefreshCamera()
        {
            var yawRadians = yaw * Mathf.Deg2Rad;
            var pitchRadians = pitch * Mathf.Deg2Rad;
            var distance = 43f;
            var horizontal = Mathf.Cos(pitchRadians) * distance;
            var offset = new Vector3(
                Mathf.Sin(yawRadians) * horizontal,
                Mathf.Sin(pitchRadians) * distance,
                Mathf.Cos(yawRadians) * horizontal);
            var target = WorldOffset + new Vector3(0f, 0.7f, 0f);
            mapCamera.transform.position = target + offset;
            mapCamera.transform.LookAt(target);
            mapCamera.orthographicSize = zoom;
        }

        public void OnPointerClick(PointerEventData eventData)
        {
            if (eventData.dragging ||
                !RectTransformUtility.ScreenPointToLocalPointInRectangle(
                    (RectTransform)transform,
                    eventData.position,
                    eventData.pressEventCamera,
                    out var local))
            {
                return;
            }

            var rect = ((RectTransform)transform).rect;
            var viewport = new Vector3(
                Mathf.InverseLerp(rect.xMin, rect.xMax, local.x),
                Mathf.InverseLerp(rect.yMin, rect.yMax, local.y),
                0f);
            var ray = mapCamera.ViewportPointToRay(viewport);
            if (!Physics.Raycast(ray, out var hit, 160f, 1 << MapLayer))
            {
                return;
            }

            var marker = hit.collider.GetComponentInParent<CampaignStageMarker>();
            if (marker != null)
            {
                SelectStage(marker.stageIndex, true);
            }
        }

        public void OnBeginDrag(PointerEventData eventData)
        {
            dragging = true;
        }

        public void OnDrag(PointerEventData eventData)
        {
            yaw -= eventData.delta.x * 0.11f;
            pitch = Mathf.Clamp(pitch + eventData.delta.y * 0.035f, 32f, 54f);
        }

        public void OnEndDrag(PointerEventData eventData)
        {
            dragging = false;
        }

        public void OnScroll(PointerEventData eventData)
        {
            zoom = Mathf.Clamp(zoom - eventData.scrollDelta.y * 1.05f, 13f, 24f);
        }

        public void SelectStage(int stageIndex, bool notify)
        {
            selectedStage = Mathf.Clamp(stageIndex, 0, StagePositions.Length - 1);
            if (selectionRing != null)
            {
                selectionRing.localPosition =
                    StagePositions[selectedStage] + Vector3.up * 0.11f;
            }
            if (notify)
            {
                selected?.Invoke(selectedStage);
            }
        }

        private void AddFlag(Transform parent, Vector3 position, Material fabric)
        {
            Box("Sancak Direği", position, new Vector3(0.1f, 2.4f, 0.1f), gold, parent);
            var flag = Box(
                "Sancak",
                position + new Vector3(0.62f, 0.58f, 0f),
                new Vector3(1.2f, 0.7f, 0.08f),
                fabric,
                parent);
            flags.Add(flag.transform);
        }

        private void AddSmoke(Transform parent, Vector3 position)
        {
            for (var index = 0; index < 3; index++)
            {
                var puff = Sphere(
                    "Ocak Dumanı",
                    position + Vector3.up * index * 0.38f,
                    Vector3.one * (0.24f + index * 0.09f),
                    white,
                    parent);
                var collider = puff.GetComponent<Collider>();
                if (collider != null)
                {
                    collider.enabled = false;
                }
                smoke.Add(puff.transform);
            }
        }

        private Material CreateMaterial(Color color, float metallic, float smoothness)
        {
            var shader = Shader.Find("Universal Render Pipeline/Lit") ??
                         Shader.Find("Standard") ??
                         Shader.Find("Sprites/Default");
            var material = new Material(shader)
            {
                color = color
            };
            if (material.HasProperty("_BaseColor")) material.SetColor("_BaseColor", color);
            if (material.HasProperty("_Metallic")) material.SetFloat("_Metallic", metallic);
            if (material.HasProperty("_Smoothness")) material.SetFloat("_Smoothness", smoothness);
            materials.Add(material);
            return material;
        }

        private GameObject BoxBetween(
            string name,
            Vector3 start,
            Vector3 end,
            float width,
            float height,
            Material material,
            Transform parent)
        {
            var midpoint = (start + end) * 0.5f;
            var direction = end - start;
            var instance = Box(
                name,
                midpoint,
                new Vector3(width, height, direction.magnitude),
                material,
                parent);
            instance.transform.rotation = Quaternion.LookRotation(direction, Vector3.up);
            return instance;
        }

        private GameObject Box(
            string name,
            Vector3 position,
            Vector3 scale,
            Material material,
            Transform parent)
        {
            return Primitive(PrimitiveType.Cube, name, position, scale, material, parent);
        }

        private GameObject Cylinder(
            string name,
            Vector3 position,
            Vector3 scale,
            Material material,
            Transform parent,
            int sides = 20)
        {
            return Primitive(PrimitiveType.Cylinder, name, position, scale, material, parent);
        }

        private GameObject Sphere(
            string name,
            Vector3 position,
            Vector3 scale,
            Material material,
            Transform parent)
        {
            return Primitive(PrimitiveType.Sphere, name, position, scale, material, parent);
        }

        private GameObject Capsule(
            string name,
            Vector3 position,
            Vector3 scale,
            Material material,
            Transform parent)
        {
            return Primitive(PrimitiveType.Capsule, name, position, scale, material, parent);
        }

        private static GameObject Primitive(
            PrimitiveType type,
            string name,
            Vector3 position,
            Vector3 scale,
            Material material,
            Transform parent)
        {
            var instance = GameObject.CreatePrimitive(type);
            instance.name = name;
            instance.transform.SetParent(parent, false);
            instance.transform.localPosition = position;
            instance.transform.localScale = scale;
            var renderer = instance.GetComponent<Renderer>();
            renderer.sharedMaterial = material;
            renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.On;
            renderer.receiveShadows = true;
            return instance;
        }

        private static void SetLayerRecursively(GameObject root, int layer)
        {
            root.layer = layer;
            foreach (Transform child in root.transform)
            {
                SetLayerRecursively(child.gameObject, layer);
            }
        }

        private void OnDestroy()
        {
            if (mapCamera != null)
            {
                mapCamera.targetTexture = null;
                Destroy(mapCamera.gameObject);
            }
            if (renderTexture != null)
            {
                renderTexture.Release();
                Destroy(renderTexture);
            }
            if (worldRoot != null)
            {
                Destroy(worldRoot);
            }
            foreach (var material in materials)
            {
                if (material != null)
                {
                    Destroy(material);
                }
            }
        }
    }
}
