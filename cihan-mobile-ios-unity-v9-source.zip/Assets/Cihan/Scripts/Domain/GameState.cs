using System;
using System.Linq;

namespace Cihan.Domain
{
    public enum ResourceType
    {
        Food,
        Wood,
        Stone,
        Gold
    }

    [Serializable]
    public sealed class ResourceCost
    {
        public int food;
        public int wood;
        public int stone;
        public int gold;

        public ResourceCost(int food = 0, int wood = 0, int stone = 0, int gold = 0)
        {
            this.food = food;
            this.wood = wood;
            this.stone = stone;
            this.gold = gold;
        }
    }

    [Serializable]
    public sealed class BuildingState
    {
        public string id;
        public int level;

        public BuildingState(string id, int level)
        {
            this.id = id;
            this.level = level;
        }
    }

    [Serializable]
    public sealed class UnitState
    {
        public string id;
        public int count;

        public UnitState(string id, int count)
        {
            this.id = id;
            this.count = count;
        }
    }

    [Serializable]
    public sealed class HeroState
    {
        public string id;
        public int level;
        public int skillLevel;
        public bool assigned;

        public HeroState(string id, int level, int skillLevel, bool assigned)
        {
            this.id = id;
            this.level = level;
            this.skillLevel = skillLevel;
            this.assigned = assigned;
        }
    }

    [Serializable]
    public sealed class TimedJob
    {
        public string kind;
        public string targetId;
        public int quantity;
        public double startedAt;
        public double endsAt;

        public float Progress(double now)
        {
            var duration = Math.Max(0.001d, endsAt - startedAt);
            return (float)Math.Max(
                0d,
                Math.Min(1d, (now - startedAt) / duration));
        }

        public int SecondsLeft(double now)
        {
            return Math.Max(0, (int)Math.Ceiling(endsAt - now));
        }
    }

    public sealed class BuildingSpec
    {
        public readonly string id;
        public readonly string title;
        public readonly string icon;
        public readonly string description;
        public readonly ResourceCost baseCost;
        public readonly int baseDuration;

        public BuildingSpec(
            string id,
            string title,
            string icon,
            string description,
            ResourceCost baseCost,
            int baseDuration)
        {
            this.id = id;
            this.title = title;
            this.icon = icon;
            this.description = description;
            this.baseCost = baseCost;
            this.baseDuration = baseDuration;
        }
    }

    public sealed class UnitSpec
    {
        public readonly string id;
        public readonly string title;
        public readonly string icon;
        public readonly string description;
        public readonly ResourceCost cost;
        public readonly int quantity;
        public readonly int duration;
        public readonly int power;
        public readonly int requiredBarracksLevel;

        public UnitSpec(
            string id,
            string title,
            string icon,
            string description,
            ResourceCost cost,
            int quantity,
            int duration,
            int power,
            int requiredBarracksLevel)
        {
            this.id = id;
            this.title = title;
            this.icon = icon;
            this.description = description;
            this.cost = cost;
            this.quantity = quantity;
            this.duration = duration;
            this.power = power;
            this.requiredBarracksLevel = requiredBarracksLevel;
        }
    }

    public sealed class HeroSpec
    {
        public readonly string id;
        public readonly string name;
        public readonly string title;
        public readonly string icon;
        public readonly string bonus;

        public HeroSpec(
            string id,
            string name,
            string title,
            string icon,
            string bonus)
        {
            this.id = id;
            this.name = name;
            this.title = title;
            this.icon = icon;
            this.bonus = bonus;
        }
    }

    public sealed class CampaignSpec
    {
        public readonly string id;
        public readonly string region;
        public readonly string title;
        public readonly string icon;
        public readonly string description;
        public readonly int recommendedPower;
        public readonly int marchFood;
        public readonly int enemyTier;
        public readonly ResourceCost reward;

        public CampaignSpec(
            string id,
            string region,
            string title,
            string icon,
            string description,
            int recommendedPower,
            int marchFood,
            int enemyTier,
            ResourceCost reward)
        {
            this.id = id;
            this.region = region;
            this.title = title;
            this.icon = icon;
            this.description = description;
            this.recommendedPower = recommendedPower;
            this.marchFood = marchFood;
            this.enemyTier = enemyTier;
            this.reward = reward;
        }
    }

    public sealed class MissionSpec
    {
        public readonly string id;
        public readonly string title;
        public readonly string description;
        public readonly ResourceCost reward;
        public readonly int gloryReward;

        public MissionSpec(
            string id,
            string title,
            string description,
            ResourceCost reward,
            int gloryReward)
        {
            this.id = id;
            this.title = title;
            this.description = description;
            this.reward = reward;
            this.gloryReward = gloryReward;
        }
    }

    public static class GameRules
    {
        public const int SaveVersion = 2;
        public const int ResourceCapacity = 50000;
        public const int MaximumBuildingLevel = 20;
        public const double MaximumOfflineSeconds = 12d * 60d * 60d;

        public static readonly BuildingSpec[] Buildings =
        {
            new(
                "palace",
                "Cihan Sarayı",
                "♜",
                "Bütün yapıların seviye sınırını ve devlet gücünü artırır.",
                new ResourceCost(wood: 1500, stone: 1800, gold: 700),
                18),
            new(
                "farm",
                "Sultan Çiftliği",
                "●",
                "Halk ve ordu için sürekli erzak üretir.",
                new ResourceCost(wood: 720, stone: 340),
                9),
            new(
                "lumber",
                "Kereste Ocağı",
                "╱",
                "İnşa ve kuşatma araçları için kereste üretir.",
                new ResourceCost(food: 420, stone: 520),
                10),
            new(
                "quarry",
                "Taş Ocağı",
                "◆",
                "Surlar ve devlet yapıları için işlenmiş taş üretir.",
                new ResourceCost(food: 560, wood: 680),
                11),
            new(
                "barracks",
                "Yeniçeri Kışlası",
                "⚔",
                "Yeni birlikler eğitir ve ordu kapasitesini büyütür.",
                new ResourceCost(food: 900, wood: 840, stone: 520),
                13),
            new(
                "hospital",
                "Darüşşifa",
                "✚",
                "Savaşta yaralanan askerleri yeniden saflara döndürür.",
                new ResourceCost(wood: 730, stone: 680, gold: 330),
                12)
        };

        public static readonly UnitSpec[] Units =
        {
            new(
                "infantry",
                "Kapıkulu Piyadesi",
                "♟",
                "Ön hattı tutan dayanıklı kılıçlı birlik.",
                new ResourceCost(food: 620, gold: 160),
                40,
                9,
                3,
                1),
            new(
                "archer",
                "Serhat Okçuları",
                "➶",
                "Piyadeyi uzaktan zayıflatan menzilli birlik.",
                new ResourceCost(food: 520, wood: 380),
                40,
                10,
                3,
                2),
            new(
                "cavalry",
                "Sipahi Süvarileri",
                "♞",
                "Kanatları yaran hızlı ve yüksek hasarlı atlı birlik.",
                new ResourceCost(food: 840, gold: 340),
                24,
                12,
                6,
                3),
            new(
                "siege",
                "Şahi Topları",
                "◙",
                "Kalelere karşı kullanılan ağır kuşatma birliği.",
                new ResourceCost(wood: 760, stone: 680, gold: 420),
                8,
                15,
                12,
                4)
        };

        public static readonly HeroSpec[] Heroes =
        {
            new(
                "aybars",
                "Aybars",
                "Sınır Kurdu",
                "♞",
                "Piyade dayanıklılığı +%12"),
            new(
                "nizam",
                "Nizam",
                "Sessiz Akıl",
                "✦",
                "Okçu menzili +%10"),
            new(
                "leyla",
                "Leyla",
                "Elçi Kumandan",
                "⚑",
                "Takviye birlikleri +%15")
        };

        public static readonly CampaignSpec[] Campaign =
        {
            new(
                "karacahisar",
                "I. BÖLGE · BATI SINIRI",
                "Karacahisar Kuşatması",
                "♜",
                "Sınır kalesinin kapısını kır, kale beyini devir ve batı yolunu aç.",
                5200,
                240,
                0,
                new ResourceCost(food: 2400, stone: 700, gold: 900)),
            new(
                "inonu",
                "II. BÖLGE · İNÖNÜ GEÇİDİ",
                "Geçit Muharebesi",
                "⚔",
                "Dar geçitte pusu kuran ağır piyadeyi formasyon üstünlüğüyle aş.",
                7400,
                340,
                1,
                new ResourceCost(food: 3000, wood: 1100, gold: 1200)),
            new(
                "aksancak",
                "III. BÖLGE · UÇ HİSARI",
                "Ak Sancak Hisarı",
                "⚑",
                "Batı eyaletinin son hisarında seçkin muhafızları ve sancak beyini yen.",
                9800,
                480,
                2,
                new ResourceCost(food: 3800, stone: 1500, gold: 1750))
        };

        public static readonly MissionSpec[] Missions =
        {
            new(
                "palace_four",
                "Payitahtı Güçlendir",
                "Cihan Sarayı'nı seviye 4 yap.",
                new ResourceCost(wood: 900, stone: 700, gold: 250),
                90),
            new(
                "army_four_hundred",
                "Sancakları Doldur",
                "Toplam 400 askere ulaş.",
                new ResourceCost(food: 1800, gold: 400),
                110),
            new(
                "first_conquest",
                "İlk Fetih",
                "Batı Seferi'nde ilk kaleyi ele geçir.",
                new ResourceCost(stone: 900, gold: 600),
                160)
        };

        public static ResourceCost UpgradeCost(BuildingSpec spec, int currentLevel)
        {
            var multiplier = 1f + currentLevel * 0.42f;
            return new ResourceCost(
                RoundCost(spec.baseCost.food * multiplier),
                RoundCost(spec.baseCost.wood * multiplier),
                RoundCost(spec.baseCost.stone * multiplier),
                RoundCost(spec.baseCost.gold * multiplier));
        }

        public static int UpgradeDuration(BuildingSpec spec, int currentLevel)
        {
            return spec.baseDuration + Math.Max(0, currentLevel - 3);
        }

        public static int TrainingBatch(UnitSpec spec, int barracksLevel)
        {
            var bonus = Math.Max(0, barracksLevel - 1) * spec.quantity / 10;
            return spec.quantity + bonus;
        }

        public static int TrainingDuration(UnitSpec spec, int barracksLevel)
        {
            return Math.Max(5, spec.duration - Math.Max(0, barracksLevel - 1));
        }

        public static double ProductionPerMinute(string buildingId, int level)
        {
            return buildingId switch
            {
                "farm" => level * 54d,
                "lumber" => level * 42d,
                "quarry" => level * 33d,
                "palace" => level * 10.8d,
                _ => 0d
            };
        }

        private static int RoundCost(float value)
        {
            return (int)Math.Round(
                value / 10f,
                MidpointRounding.AwayFromZero) * 10;
        }
    }

    [Serializable]
    public sealed class GameState
    {
        public int version = GameRules.SaveVersion;
        public double lastUpdatedUnix;
        public int food;
        public int wood;
        public int stone;
        public int gold;
        public double foodFraction;
        public double woodFraction;
        public double stoneFraction;
        public double goldFraction;
        public BuildingState[] buildings;
        public UnitState[] units;
        public HeroState[] heroes;
        public TimedJob construction;
        public TimedJob training;
        public TimedJob expedition;
        public int wounded;
        public int seasonPoints;
        public int victories;
        public int campaignProgress;
        public int[] campaignBestStars;
        public int claimedMissionMask;
        public string lastEvent;

        public int Power
        {
            get
            {
                var buildingPower = buildings.Sum(item => item.level) * 170;
                var unitPower = units.Sum(item =>
                {
                    var spec = GameRules.Units.First(value => value.id == item.id);
                    return item.count * spec.power;
                });
                var heroPower = heroes.Sum(
                    item => item.level * 70 + item.skillLevel * 190);
                return buildingPower + unitPower + heroPower + seasonPoints / 2;
            }
        }

        public static GameState CreateNew(double now)
        {
            return new GameState
            {
                lastUpdatedUnix = now,
                food = 18400,
                wood = 11200,
                stone = 8600,
                gold = 5400,
                buildings = new[]
                {
                    new BuildingState("palace", 3),
                    new BuildingState("farm", 2),
                    new BuildingState("lumber", 2),
                    new BuildingState("quarry", 2),
                    new BuildingState("barracks", 2),
                    new BuildingState("hospital", 1)
                },
                units = new[]
                {
                    new UnitState("infantry", 180),
                    new UnitState("archer", 100),
                    new UnitState("cavalry", 48),
                    new UnitState("siege", 8)
                },
                heroes = new[]
                {
                    new HeroState("aybars", 8, 2, true),
                    new HeroState("nizam", 6, 1, true),
                    new HeroState("leyla", 5, 1, false)
                },
                wounded = 24,
                seasonPoints = 320,
                campaignProgress = 0,
                campaignBestStars = new int[GameRules.Campaign.Length],
                claimedMissionMask = 0,
                lastEvent = "Payitaht yeni bir güne hazır."
            };
        }

        public void EnsureCompatibility()
        {
            campaignProgress = Math.Max(
                0,
                Math.Min(GameRules.Campaign.Length, campaignProgress));
            if (campaignBestStars == null ||
                campaignBestStars.Length != GameRules.Campaign.Length)
            {
                var previous = campaignBestStars;
                campaignBestStars = new int[GameRules.Campaign.Length];
                if (previous != null)
                {
                    Array.Copy(
                        previous,
                        campaignBestStars,
                        Math.Min(previous.Length, campaignBestStars.Length));
                }
            }

            for (var index = 0; index < campaignBestStars.Length; index += 1)
            {
                campaignBestStars[index] = Math.Max(
                    0,
                    Math.Min(3, campaignBestStars[index]));
            }
        }

        public BuildingState GetBuilding(string id)
        {
            return buildings.First(item => item.id == id);
        }

        public UnitState GetUnit(string id)
        {
            return units.First(item => item.id == id);
        }

        public HeroState GetHero(string id)
        {
            return heroes.First(item => item.id == id);
        }

        public bool ToggleHeroAssignment(string heroId)
        {
            var hero = heroes.FirstOrDefault(item => item.id == heroId);
            if (hero == null)
            {
                return false;
            }

            if (!hero.assigned && heroes.Count(item => item.assigned) >= 2)
            {
                lastEvent = "Bir sefere en fazla iki kahraman atanabilir.";
                return false;
            }

            hero.assigned = !hero.assigned;
            var spec = GameRules.Heroes.First(item => item.id == heroId);
            lastEvent = hero.assigned
                ? $"{spec.name} sefer ordusuna atandı."
                : $"{spec.name} başkent görevine döndü.";
            return true;
        }

        public bool UpgradeHeroSkill(string heroId)
        {
            var hero = heroes.FirstOrDefault(item => item.id == heroId);
            if (hero == null || hero.skillLevel >= 5 || gold < 700)
            {
                return false;
            }

            gold -= 700;
            hero.skillLevel += 1;
            hero.level += 1;
            seasonPoints += 30;
            var spec = GameRules.Heroes.First(item => item.id == heroId);
            lastEvent = $"{spec.name} yeni bir komutanlık yeteneği kazandı.";
            return true;
        }

        public bool CanLaunchCampaign(int stageIndex)
        {
            EnsureCompatibility();
            if (stageIndex < 0 ||
                stageIndex >= GameRules.Campaign.Length ||
                stageIndex > campaignProgress)
            {
                return false;
            }

            var stage = GameRules.Campaign[stageIndex];
            return food >= stage.marchFood &&
                   units.Sum(item => item.count) >= 40 &&
                   heroes.Any(item => item.assigned);
        }

        public bool BeginCampaignBattle(int stageIndex)
        {
            if (!CanLaunchCampaign(stageIndex))
            {
                return false;
            }

            var stage = GameRules.Campaign[stageIndex];
            food -= stage.marchFood;
            lastEvent =
                $"{stage.title} için ordu yürüyüşe geçti. Savaş düzenini seç.";
            return true;
        }

        public int CampaignStars(int stageIndex)
        {
            EnsureCompatibility();
            return stageIndex >= 0 && stageIndex < campaignBestStars.Length
                ? campaignBestStars[stageIndex]
                : 0;
        }

        public void ApplyBattleResult(
            bool victory,
            int casualties,
            int kills,
            string campaignTargetId = null,
            int starRating = 0)
        {
            EnsureCompatibility();
            var remainingCasualties = Math.Max(0, casualties);
            foreach (var unit in units.OrderByDescending(item => item.count))
            {
                if (remainingCasualties <= 0)
                {
                    break;
                }

                var loss = Math.Min(unit.count, remainingCasualties);
                unit.count -= loss;
                remainingCasualties -= loss;
            }

            wounded += Math.Max(1, casualties / 2);
            if (victory)
            {
                victories += 1;
                seasonPoints += 220 + kills * 3;
                var stageIndex = Array.FindIndex(
                    GameRules.Campaign,
                    item => item.id == campaignTargetId);
                if (stageIndex >= 0)
                {
                    var stage = GameRules.Campaign[stageIndex];
                    campaignBestStars[stageIndex] = Math.Max(
                        campaignBestStars[stageIndex],
                        Math.Max(1, Math.Min(3, starRating)));
                    if (stageIndex == campaignProgress)
                    {
                        campaignProgress = Math.Min(
                            GameRules.Campaign.Length,
                            campaignProgress + 1);
                    }

                    AddReward(stage.reward);
                    lastEvent =
                        $"{stage.title} kazanıldı; yeni fetih emri Divan'a ulaştı.";
                }
                else
                {
                    AddReward(new ResourceCost(food: 2400, stone: 700, gold: 900));
                    lastEvent = "Canlı kuşatma kazanıldı; ganimet başkente ulaştı.";
                }
            }
            else
            {
                seasonPoints += Math.Max(20, kills);
                lastEvent = "Ordu geri çekildi. Yaralılar Darüşşifa'ya taşındı.";
            }
        }

        public bool IsMissionClaimed(int missionIndex)
        {
            return missionIndex >= 0 &&
                   missionIndex < GameRules.Missions.Length &&
                   (claimedMissionMask & (1 << missionIndex)) != 0;
        }

        public bool IsMissionComplete(int missionIndex)
        {
            if (missionIndex < 0 || missionIndex >= GameRules.Missions.Length)
            {
                return false;
            }

            return GameRules.Missions[missionIndex].id switch
            {
                "palace_four" => GetBuilding("palace").level >= 4,
                "army_four_hundred" => units.Sum(item => item.count) >= 400,
                "first_conquest" => campaignProgress >= 1,
                _ => false
            };
        }

        public string MissionProgress(int missionIndex)
        {
            if (missionIndex < 0 || missionIndex >= GameRules.Missions.Length)
            {
                return "0/0";
            }

            return GameRules.Missions[missionIndex].id switch
            {
                "palace_four" =>
                    $"{Math.Min(4, GetBuilding("palace").level)}/4 saray seviyesi",
                "army_four_hundred" =>
                    $"{Math.Min(400, units.Sum(item => item.count))}/400 asker",
                "first_conquest" =>
                    $"{Math.Min(1, campaignProgress)}/1 fetih",
                _ => "0/0"
            };
        }

        public bool ClaimMissionReward(int missionIndex)
        {
            if (!IsMissionComplete(missionIndex) || IsMissionClaimed(missionIndex))
            {
                return false;
            }

            var mission = GameRules.Missions[missionIndex];
            claimedMissionMask |= 1 << missionIndex;
            AddReward(mission.reward);
            seasonPoints += mission.gloryReward;
            lastEvent = $"{mission.title} emri tamamlandı; mükâfat hazinede.";
            return true;
        }

        public bool CanAfford(ResourceCost cost)
        {
            return food >= cost.food &&
                   wood >= cost.wood &&
                   stone >= cost.stone &&
                   gold >= cost.gold;
        }

        public bool CanUpgradeBuilding(string buildingId)
        {
            if (construction != null)
            {
                return false;
            }

            var spec = GameRules.Buildings.FirstOrDefault(item => item.id == buildingId);
            var building = buildings.FirstOrDefault(item => item.id == buildingId);
            if (spec == null ||
                building == null ||
                building.level >= GameRules.MaximumBuildingLevel)
            {
                return false;
            }

            if (buildingId != "palace" &&
                building.level >= GetBuilding("palace").level)
            {
                return false;
            }

            return CanAfford(GameRules.UpgradeCost(spec, building.level));
        }

        public string BuildingUpgradeStatus(string buildingId)
        {
            var building = GetBuilding(buildingId);
            if (building.level >= GameRules.MaximumBuildingLevel)
            {
                return "En yüksek seviyede";
            }

            if (buildingId != "palace" &&
                building.level >= GetBuilding("palace").level)
            {
                return $"Önce Cihan Sarayı seviye {building.level + 1} olmalı";
            }

            if (construction != null)
            {
                return "İnşa ustaları başka bir yapıda çalışıyor";
            }

            var spec = GameRules.Buildings.First(item => item.id == buildingId);
            return CanAfford(GameRules.UpgradeCost(spec, building.level))
                ? $"Seviye {building.level + 1} için hazır"
                : "Kaynak yetersiz";
        }

        public bool CanTrainUnit(string unitId)
        {
            if (training != null)
            {
                return false;
            }

            var spec = GameRules.Units.FirstOrDefault(item => item.id == unitId);
            return spec != null &&
                   GetBuilding("barracks").level >= spec.requiredBarracksLevel &&
                   CanAfford(spec.cost);
        }

        public string UnitTrainingStatus(string unitId)
        {
            var spec = GameRules.Units.First(item => item.id == unitId);
            var barracksLevel = GetBuilding("barracks").level;
            if (barracksLevel < spec.requiredBarracksLevel)
            {
                return $"Yeniçeri Kışlası seviye {spec.requiredBarracksLevel} gerekli";
            }

            if (training != null)
            {
                return "Kışlanın eğitim sırası dolu";
            }

            return CanAfford(spec.cost)
                ? $"{GameRules.TrainingBatch(spec, barracksLevel)} asker eğitime hazır"
                : "Kaynak yetersiz";
        }

        public bool TrySpend(ResourceCost cost)
        {
            if (!CanAfford(cost))
            {
                return false;
            }

            food -= cost.food;
            wood -= cost.wood;
            stone -= cost.stone;
            gold -= cost.gold;
            return true;
        }

        public bool BeginUpgrade(string buildingId, double now)
        {
            var spec = GameRules.Buildings.FirstOrDefault(item => item.id == buildingId);
            if (spec == null || !CanUpgradeBuilding(buildingId))
            {
                return false;
            }

            var building = GetBuilding(buildingId);
            var cost = GameRules.UpgradeCost(spec, building.level);
            if (!TrySpend(cost))
            {
                return false;
            }

            construction = new TimedJob
            {
                kind = "construction",
                targetId = buildingId,
                quantity = 1,
                startedAt = now,
                endsAt = now + GameRules.UpgradeDuration(spec, building.level)
            };
            lastEvent = $"{spec.title} geliştirilmeye başlandı.";
            return true;
        }

        public bool BeginTraining(string unitId, double now)
        {
            var spec = GameRules.Units.FirstOrDefault(item => item.id == unitId);
            if (spec == null || !CanTrainUnit(unitId) || !TrySpend(spec.cost))
            {
                return false;
            }

            var barracksLevel = GetBuilding("barracks").level;
            training = new TimedJob
            {
                kind = "training",
                targetId = unitId,
                quantity = GameRules.TrainingBatch(spec, barracksLevel),
                startedAt = now,
                endsAt = now + GameRules.TrainingDuration(spec, barracksLevel)
            };
            lastEvent =
                $"{training.quantity} {spec.title} eğitim kuyruğuna eklendi.";
            return true;
        }

        public bool BeginExpedition(double now)
        {
            if (expedition != null || food < 400)
            {
                return false;
            }

            food -= 400;
            expedition = new TimedJob
            {
                kind = "expedition",
                targetId = "karacahisar",
                quantity = 1,
                startedAt = now,
                endsAt = now + 12
            };
            lastEvent = "Ordu Karacahisar yönüne yürüyüşe geçti.";
            return true;
        }

        public void Advance(double now)
        {
            if (lastUpdatedUnix <= 0)
            {
                lastUpdatedUnix = now;
                return;
            }

            var elapsed = Math.Min(
                GameRules.MaximumOfflineSeconds,
                Math.Max(0d, now - lastUpdatedUnix));
            Produce(elapsed);
            lastUpdatedUnix = now;

            if (construction != null && now >= construction.endsAt)
            {
                var spec = GameRules.Buildings.FirstOrDefault(
                    item => item.id == construction.targetId);
                var building = buildings.FirstOrDefault(
                    item => item.id == construction.targetId);
                if (spec != null && building != null)
                {
                    building.level += construction.quantity;
                    seasonPoints += 60;
                    lastEvent = $"{spec.title} geliştirildi.";
                }
                else
                {
                    lastEvent = "Eski sürümden kalan yapı görevi temizlendi.";
                }

                construction = null;
            }

            if (training != null && now >= training.endsAt)
            {
                var spec = GameRules.Units.FirstOrDefault(
                    item => item.id == training.targetId);
                var unit = units.FirstOrDefault(
                    item => item.id == training.targetId);
                if (spec != null && unit != null)
                {
                    unit.count += training.quantity;
                    seasonPoints += 40;
                    lastEvent = $"{spec.title} orduya katıldı.";
                }
                else
                {
                    lastEvent = "Eski sürümden kalan asker eğitimi temizlendi.";
                }

                training = null;
            }

            if (expedition != null && now >= expedition.endsAt)
            {
                expedition = null;
                victories += 1;
                seasonPoints += 180;
                food = Math.Min(GameRules.ResourceCapacity, food + 2400);
                stone = Math.Min(GameRules.ResourceCapacity, stone + 700);
                gold = Math.Min(GameRules.ResourceCapacity, gold + 900);
                wounded += 18;
                lastEvent = "Karacahisar seferi kazanıldı; ganimet başkente ulaştı.";
            }
        }

        private void Produce(double elapsed)
        {
            var farmLevel = GetBuilding("farm").level;
            var lumberLevel = GetBuilding("lumber").level;
            var quarryLevel = GetBuilding("quarry").level;
            var palaceLevel = GetBuilding("palace").level;

            AddProduction(ref food, ref foodFraction, farmLevel * 0.9d * elapsed);
            AddProduction(ref wood, ref woodFraction, lumberLevel * 0.7d * elapsed);
            AddProduction(ref stone, ref stoneFraction, quarryLevel * 0.55d * elapsed);
            AddProduction(ref gold, ref goldFraction, palaceLevel * 0.18d * elapsed);
        }

        private void AddReward(ResourceCost reward)
        {
            food = Math.Min(GameRules.ResourceCapacity, food + reward.food);
            wood = Math.Min(GameRules.ResourceCapacity, wood + reward.wood);
            stone = Math.Min(GameRules.ResourceCapacity, stone + reward.stone);
            gold = Math.Min(GameRules.ResourceCapacity, gold + reward.gold);
        }

        private static void AddProduction(
            ref int resource,
            ref double fraction,
            double produced)
        {
            var total = fraction + produced;
            var whole = (int)Math.Floor(total);
            fraction = total - whole;
            resource = Math.Min(GameRules.ResourceCapacity, resource + whole);
        }
    }
}
