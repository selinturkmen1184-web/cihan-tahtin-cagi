using System;
using Cihan.Domain;
using UnityEngine;

namespace Cihan.Services
{
    public sealed class GameService : MonoBehaviour
    {
        public static GameService Instance { get; private set; }

        public GameState State { get; private set; }

        public event Action Changed;

        private float tickAccumulator;
        private float saveAccumulator;

        public static double Now =>
            DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() / 1000d;

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }

            Instance = this;
            DontDestroyOnLoad(gameObject);
            State = SaveService.LoadOrCreate(Now);
        }

        private void Start()
        {
            NotifyChanged();
        }

        private void Update()
        {
            tickAccumulator += Time.unscaledDeltaTime;
            saveAccumulator += Time.unscaledDeltaTime;

            if (tickAccumulator >= 0.5f)
            {
                tickAccumulator = 0f;
                State.Advance(Now);
                NotifyChanged();
            }

            if (saveAccumulator >= 3f)
            {
                saveAccumulator = 0f;
                SaveService.Save(State);
            }
        }

        public bool UpgradeBuilding(string id)
        {
            var accepted = State.BeginUpgrade(id, Now);
            ApplyActionResult(accepted, State.BuildingUpgradeStatus(id));
            return accepted;
        }

        public bool TrainUnit(string id)
        {
            var accepted = State.BeginTraining(id, Now);
            ApplyActionResult(accepted, State.UnitTrainingStatus(id));
            return accepted;
        }

        public bool BeginExpedition()
        {
            var accepted = State.BeginExpedition(Now);
            ApplyActionResult(accepted, "Sefer sırası dolu veya 400 erzak yetersiz.");
            return accepted;
        }

        public bool BeginCampaignBattle(int stageIndex)
        {
            var accepted = State.BeginCampaignBattle(stageIndex);
            ApplyActionResult(
                accepted,
                "Bu bölge henüz açık değil; ayrıca erzak, asker ve atanmış komutan gerekli.");
            return accepted;
        }

        public bool ClaimMissionReward(int missionIndex)
        {
            var accepted = State.ClaimMissionReward(missionIndex);
            ApplyActionResult(
                accepted,
                "Bu fetih emri henüz tamamlanmadı veya mükâfat daha önce alındı.");
            return accepted;
        }

        public bool ToggleHero(string id)
        {
            var accepted = State.ToggleHeroAssignment(id);
            ApplyActionResult(accepted, State.lastEvent);
            return accepted;
        }

        public bool UpgradeHero(string id)
        {
            var accepted = State.UpgradeHeroSkill(id);
            ApplyActionResult(
                accepted,
                "Yetenek için 700 altın gerekli veya yetenek en yüksek seviyede.");
            return accepted;
        }

        public void ApplyBattleResult(
            bool victory,
            int casualties,
            int kills,
            string campaignTargetId = null,
            int starRating = 0)
        {
            State.ApplyBattleResult(
                victory,
                casualties,
                kills,
                campaignTargetId,
                starRating);
            SaveService.Save(State);
            NotifyChanged();
        }

        public void ResetGame()
        {
            SaveService.Delete();
            State = GameState.CreateNew(Now);
            SaveService.Save(State);
            NotifyChanged();
        }

        public void SaveNow()
        {
            State.Advance(Now);
            SaveService.Save(State);
        }

        private void ApplyActionResult(bool accepted, string rejectedMessage)
        {
            if (!accepted)
            {
                State.lastEvent = rejectedMessage;
            }

            SaveService.Save(State);
            NotifyChanged();
        }

        private void NotifyChanged()
        {
            Changed?.Invoke();
        }

        private void OnApplicationPause(bool paused)
        {
            if (paused)
            {
                SaveNow();
            }
        }

        private void OnApplicationQuit()
        {
            SaveNow();
        }
    }
}
