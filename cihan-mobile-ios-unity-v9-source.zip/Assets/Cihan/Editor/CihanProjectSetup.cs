using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Cihan.Editor
{
    [InitializeOnLoad]
    public static class CihanProjectSetup
    {
        private const string MainScenePath = "Assets/Cihan/Scenes/Main.unity";
        private const string SetupSessionKey = "Cihan.MobileMvp.SetupCompleted";

        static CihanProjectSetup()
        {
            EditorApplication.delayCall += RunFirstSetup;
        }

        [MenuItem("Cihan/Mobil MVP Kurulumunu Yenile")]
        public static void ConfigureProject()
        {
            EnsureMainScene();
            ApplyPlayerSettings();
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            Debug.Log("CİHAN mobil MVP kurulumu hazır.");
        }

        private static void RunFirstSetup()
        {
            if (SessionState.GetBool(SetupSessionKey, false))
            {
                return;
            }

            SessionState.SetBool(SetupSessionKey, true);
            ConfigureProject();
        }

        private static void EnsureMainScene()
        {
            var sceneDirectory = Path.GetDirectoryName(MainScenePath);
            if (!string.IsNullOrWhiteSpace(sceneDirectory))
            {
                Directory.CreateDirectory(sceneDirectory);
            }

            if (!File.Exists(MainScenePath))
            {
                var scene = EditorSceneManager.NewScene(
                    NewSceneSetup.EmptyScene,
                    NewSceneMode.Single);
                scene.name = "Main";
                EditorSceneManager.SaveScene(scene, MainScenePath);
                EditorSceneManager.CloseScene(scene, true);
            }

            EditorBuildSettings.scenes = new[]
            {
                new EditorBuildSettingsScene(MainScenePath, true)
            };
        }

        private static void ApplyPlayerSettings()
        {
            PlayerSettings.companyName = "Selin Türkmen";
            PlayerSettings.productName = "CİHAN: Tahtın Çağı";
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.Portrait;
            PlayerSettings.colorSpace = ColorSpace.Linear;
            PlayerSettings.SetApplicationIdentifier(
                BuildTargetGroup.Android,
                "com.selinturkmen.cihan");
            PlayerSettings.SetApplicationIdentifier(
                BuildTargetGroup.iOS,
                "com.selinturkmen.cihan");
            PlayerSettings.Android.minSdkVersion =
                AndroidSdkVersions.AndroidApiLevel26;
            PlayerSettings.iOS.targetOSVersionString = "13.0";
            PlayerSettings.SetScriptingBackend(
                BuildTargetGroup.Android,
                ScriptingImplementation.Mono2x);
            PlayerSettings.SetScriptingBackend(
                BuildTargetGroup.iOS,
                ScriptingImplementation.IL2CPP);

            QualitySettings.vSyncCount = 0;
            Application.targetFrameRate = 60;
        }
    }
}
