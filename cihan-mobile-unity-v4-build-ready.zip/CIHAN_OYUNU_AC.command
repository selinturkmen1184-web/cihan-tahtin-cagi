#!/bin/zsh

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
UNITY_BIN=""

for candidate in \
  "/Applications/Unity/Unity.app/Contents/MacOS/Unity" \
  "/Applications/Unity/Hub/Editor/6000.0.0f1/Unity.app/Contents/MacOS/Unity" \
  "/Applications/Unity/Hub/Editor/6000.3.7f1/Unity.app/Contents/MacOS/Unity" \
  "$HOME/Applications/Unity/Hub/Editor/6000.0.0f1/Unity.app/Contents/MacOS/Unity"
do
  if [ -x "$candidate" ]; then
    UNITY_BIN="$candidate"
    break
  fi
done

if [ -z "$UNITY_BIN" ]; then
  echo "Unity 6 bulunamadı. Resmî kurulum sayfası açılıyor."
  open "https://unity.com/releases/editor/whats-new/6000.0.0f1"
  read "?Kurulumdan sonra tekrar deneyin. Kapatmak için Enter: "
  exit 1
fi

echo "CİHAN Unity projesi açılıyor..."
"$UNITY_BIN" -projectPath "$SCRIPT_DIR"
