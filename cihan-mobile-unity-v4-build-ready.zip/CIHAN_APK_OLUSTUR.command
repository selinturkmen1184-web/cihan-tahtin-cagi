#!/bin/zsh

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
UNITY_BIN=""

for candidate in \
  "/Applications/Unity/Hub/Editor/6000.0.0f1/Unity.app/Contents/MacOS/Unity" \
  "/Applications/Unity/Hub/Editor/6000.3.7f1/Unity.app/Contents/MacOS/Unity" \
  "$HOME/Applications/Unity/Hub/Editor/6000.0.0f1/Unity.app/Contents/MacOS/Unity"
do
  if [ -x "$candidate" ]; then
    UNITY_BIN="$candidate"
    break
  fi
done

if [ -z "$UNITY_BIN" ]; then
  echo "Unity 6 bulunamadı."
  echo "Unity Hub açılıyor. Unity 6 ile Android Build Support,"
  echo "Android SDK & NDK Tools ve OpenJDK modüllerini yükleyin."
  open "https://unity.com/releases/editor/whats-new/6000.0.0f1"
  echo
  read "?Kurulumdan sonra bu dosyaya tekrar çift tıklayın. Kapatmak için Enter: "
  exit 1
fi

OUTPUT_DIR="$SCRIPT_DIR/Builds"
OUTPUT_PATH="$OUTPUT_DIR/Cihan-Tahtin-Cagi-v4.apk"
mkdir -p "$OUTPUT_DIR"

echo "CİHAN Android APK derlemesi başlatılıyor..."
echo "Unity ilk açılışta lisans girişi isterse Unity Hub'da oturum açın."

CIHAN_APK_OUTPUT="$OUTPUT_PATH" "$UNITY_BIN" \
  -batchmode \
  -quit \
  -projectPath "$SCRIPT_DIR" \
  -executeMethod Cihan.Editor.CihanAndroidBuilder.Build \
  -logFile "$OUTPUT_DIR/Cihan-Android-Build.log"

if [ ! -f "$OUTPUT_PATH" ]; then
  echo "APK oluşmadı. Ayrıntılar:"
  echo "$OUTPUT_DIR/Cihan-Android-Build.log"
  read "?Kapatmak için Enter: "
  exit 1
fi

echo
echo "APK HAZIR:"
echo "$OUTPUT_PATH"
open -R "$OUTPUT_PATH"
read "?Kapatmak için Enter: "
