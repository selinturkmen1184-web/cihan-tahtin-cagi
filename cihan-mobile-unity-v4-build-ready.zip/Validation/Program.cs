using Cihan.Battle;
using Cihan.Domain;

const double now = 1000d;
var state = GameState.CreateNew(now);
var startingFood = state.food;
state.Advance(now + 60d);
Require(state.food > startingFood, "Kaynak üretimi ilerlemiyor.");

var farmLevel = state.GetBuilding("farm").level;
Require(state.BeginUpgrade("farm", now + 60d), "Bina geliştirilemiyor.");
state.Advance(now + 180d);
Require(
    state.GetBuilding("farm").level == farmLevel + 1,
    "Bina geliştirme tamamlanmıyor.");

var infantry = state.GetUnit("infantry").count;
var infantryBatch = GameRules.TrainingBatch(
    GameRules.Units.First(item => item.id == "infantry"),
    state.GetBuilding("barracks").level);
Require(state.BeginTraining("infantry", now + 180d), "Asker eğitilemiyor.");
state.Advance(now + 300d);
Require(
    state.GetUnit("infantry").count == infantry + infantryBatch,
    "Eğitilen asker orduya katılmıyor.");

Require(
    !state.BeginTraining("cavalry", now + 300d),
    "Kışla seviyesi yetersizken süvari eğitilebiliyor.");

var palaceLevel = state.GetBuilding("palace").level;
while (state.GetBuilding("farm").level < palaceLevel)
{
    Require(state.BeginUpgrade("farm", now + 300d), "Çiftlik saray seviyesine çıkarılamıyor.");
    state.Advance(now + 500d);
}

Require(
    !state.BeginUpgrade("farm", now + 500d),
    "Saray sınırı aşılabiliyor.");

Require(
    !state.ToggleHeroAssignment("leyla"),
    "İkiden fazla kahraman sefere atanabiliyor.");
Require(
    state.ToggleHeroAssignment("nizam"),
    "Kahraman ordudan çıkarılamıyor.");
Require(
    state.ToggleHeroAssignment("leyla"),
    "Kahraman sefere atanamıyor.");
var skillLevel = state.GetHero("aybars").skillLevel;
Require(state.UpgradeHeroSkill("aybars"), "Kahraman yeteneği geliştirilemiyor.");
Require(
    state.GetHero("aybars").skillLevel == skillLevel + 1,
    "Kahraman yetenek seviyesi artmıyor.");

var battle = BattleSimulation.Create(state);
for (var step = 0; step < 4000 && !battle.IsFinished; step += 1)
{
    battle.Step(0.02f);
}

Require(battle.Clashes > 0, "Ordular savaş alanında çarpışmıyor.");
Require(battle.IsFinished, "Canlı savaş bir sonuca ulaşmıyor.");
Require(
    battle.FriendlyKills + battle.FriendlyCasualties > 0,
    "Canlı savaşta asker kaybı oluşmuyor.");
state.ApplyBattleResult(
    battle.Victory,
    battle.FriendlyCasualties,
    battle.FriendlyKills);

var victories = state.victories;
Require(state.BeginExpedition(now + 300d), "Sefer başlatılamıyor.");
state.Advance(now + 420d);
Require(state.victories == victories + 1, "Sefer sonucu uygulanmıyor.");

Console.WriteLine(
    $"CİHAN domain doğrulaması geçti | Güç: {state.Power:N0} | " +
    $"Erzak: {state.food:N0} | Zafer: {state.victories} | " +
    $"Canlı savaş: {(battle.Victory ? "Zafer" : "Geri çekilme")} " +
    $"({battle.FriendlyKills}-{battle.FriendlyCasualties})");

static void Require(bool condition, string message)
{
    if (!condition)
    {
        throw new InvalidOperationException(message);
    }
}
