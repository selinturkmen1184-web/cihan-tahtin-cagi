using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;

var root = new DirectoryInfo(Directory.GetCurrentDirectory());
while (root != null &&
       !Directory.Exists(Path.Combine(root.FullName, "Assets", "Cihan")))
{
    root = root.Parent;
}

if (root == null)
{
    throw new DirectoryNotFoundException(
        "Assets/Cihan klasörünü içeren Unity proje kökü bulunamadı.");
}

var files = Directory
    .EnumerateFiles(
        Path.Combine(root.FullName, "Assets", "Cihan"),
        "*.cs",
        SearchOption.AllDirectories)
    .OrderBy(path => path)
    .ToArray();

var failures = new List<string>();
foreach (var file in files)
{
    var source = File.ReadAllText(file);
    var tree = CSharpSyntaxTree.ParseText(
        source,
        new CSharpParseOptions(LanguageVersion.CSharp9),
        file);
    foreach (var diagnostic in tree.GetDiagnostics()
                 .Where(item => item.Severity == DiagnosticSeverity.Error))
    {
        failures.Add(diagnostic.ToString());
    }
}

if (failures.Count > 0)
{
    Console.Error.WriteLine(string.Join(Environment.NewLine, failures));
    Environment.Exit(1);
}

Console.WriteLine(
    $"CİHAN C# sözdizimi doğrulaması geçti | {files.Length} kaynak dosyası");
