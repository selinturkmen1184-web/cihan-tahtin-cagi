using System;
using System.IO;
using Cihan.Domain;
using UnityEngine;

namespace Cihan.Services
{
    public static class SaveService
    {
        private const string SaveFileName = "cihan-save.json";

        public static string SavePath =>
            Path.Combine(Application.persistentDataPath, SaveFileName);

        public static GameState LoadOrCreate(double now)
        {
            if (!File.Exists(SavePath))
            {
                return GameState.CreateNew(now);
            }

            try
            {
                var json = File.ReadAllText(SavePath);
                var state = JsonUtility.FromJson<GameState>(json);
                if (state == null ||
                    state.version != GameRules.SaveVersion ||
                    state.buildings == null ||
                    state.units == null ||
                    state.heroes == null)
                {
                    return GameState.CreateNew(now);
                }

                state.Advance(now);
                return state;
            }
            catch (Exception exception)
            {
                Debug.LogWarning($"CİHAN kayıt dosyası okunamadı: {exception.Message}");
                return GameState.CreateNew(now);
            }
        }

        public static void Save(GameState state)
        {
            try
            {
                var directory = Path.GetDirectoryName(SavePath);
                if (!string.IsNullOrWhiteSpace(directory))
                {
                    Directory.CreateDirectory(directory);
                }

                var temporaryPath = SavePath + ".tmp";
                File.WriteAllText(temporaryPath, JsonUtility.ToJson(state, true));
                File.Copy(temporaryPath, SavePath, true);
                File.Delete(temporaryPath);
            }
            catch (Exception exception)
            {
                Debug.LogWarning($"CİHAN kaydı yazılamadı: {exception.Message}");
            }
        }

        public static void Delete()
        {
            if (File.Exists(SavePath))
            {
                File.Delete(SavePath);
            }
        }
    }
}
