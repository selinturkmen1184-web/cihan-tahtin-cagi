using System;
using System.Collections.Generic;
using System.Linq;
using Cihan.Domain;

namespace Cihan.Battle
{
    public enum BattleTeam
    {
        Friendly,
        Enemy
    }

    public enum BattleUnitKind
    {
        Infantry,
        Archer,
        Cavalry,
        Siege
    }

    public sealed class BattleUnit
    {
        public int id;
        public BattleTeam team;
        public BattleUnitKind kind;
        public float x;
        public float y;
        public float hp;
        public float maxHp;
        public float damage;
        public float speed;
        public float range;
        public float attackDelay;
        public float attackTimer;
        public int kills;

        public bool Alive => hp > 0f;
        public float HealthRatio => maxHp <= 0f ? 0f : Math.Max(0f, hp / maxHp);
    }

    public sealed class BattleSimulation
    {
        private const float MaximumDuration = 58f;
        private readonly List<BattleUnit> units = new();
        private int nextId = 1;

        public IReadOnlyList<BattleUnit> Units => units;
        public float Elapsed { get; private set; }
        public bool IsFinished { get; private set; }
        public bool Victory { get; private set; }
        public int FriendlyKills { get; private set; }
        public int FriendlyCasualties { get; private set; }
        public int Clashes { get; private set; }

        public int FriendlyAlive =>
            units.Count(item => item.team == BattleTeam.Friendly && item.Alive);

        public int EnemyAlive =>
            units.Count(item => item.team == BattleTeam.Enemy && item.Alive);

        public static BattleSimulation Create(GameState state)
        {
            var simulation = new BattleSimulation();
            var aybars = state.GetHero("aybars").assigned;
            var nizam = state.GetHero("nizam").assigned;
            var leyla = state.GetHero("leyla").assigned;

            simulation.SpawnFormation(
                BattleTeam.Friendly,
                BattleUnitKind.Infantry,
                aybars ? 9 : 8,
                0.22f,
                0.15f,
                aybars ? 1.12f : 1f,
                1f);
            simulation.SpawnFormation(
                BattleTeam.Friendly,
                BattleUnitKind.Archer,
                5,
                0.12f,
                0.23f,
                1f,
                nizam ? 1.10f : 1f);
            simulation.SpawnFormation(
                BattleTeam.Friendly,
                BattleUnitKind.Cavalry,
                3,
                0.18f,
                0.12f);
            simulation.SpawnFormation(
                BattleTeam.Friendly,
                BattleUnitKind.Siege,
                1,
                0.08f,
                0.50f);

            if (leyla)
            {
                simulation.SpawnFormation(
                    BattleTeam.Friendly,
                    BattleUnitKind.Infantry,
                    2,
                    0.15f,
                    0.70f);
            }

            simulation.SpawnFormation(
                BattleTeam.Enemy,
                BattleUnitKind.Infantry,
                9,
                0.78f,
                0.15f,
                1.04f);
            simulation.SpawnFormation(
                BattleTeam.Enemy,
                BattleUnitKind.Archer,
                5,
                0.88f,
                0.23f);
            simulation.SpawnFormation(
                BattleTeam.Enemy,
                BattleUnitKind.Cavalry,
                3,
                0.82f,
                0.12f);
            simulation.SpawnFormation(
                BattleTeam.Enemy,
                BattleUnitKind.Siege,
                1,
                0.92f,
                0.50f);

            return simulation;
        }

        public void Step(float deltaTime)
        {
            if (IsFinished || deltaTime <= 0f)
            {
                return;
            }

            var step = Math.Min(deltaTime, 0.05f);
            Elapsed += step;

            foreach (var unit in units.Where(item => item.Alive).ToArray())
            {
                unit.attackTimer = Math.Max(0f, unit.attackTimer - step);
                var target = FindNearestTarget(unit);
                if (target == null)
                {
                    continue;
                }

                var dx = target.x - unit.x;
                var dy = target.y - unit.y;
                var distance = (float)Math.Sqrt(dx * dx + dy * dy);
                if (distance > unit.range)
                {
                    var movement = Math.Min(unit.speed * step, distance - unit.range);
                    if (distance > 0.0001f)
                    {
                        unit.x += dx / distance * movement;
                        unit.y += dy / distance * movement;
                    }

                    continue;
                }

                if (unit.attackTimer > 0f)
                {
                    continue;
                }

                Clashes += 1;
                unit.attackTimer = unit.attackDelay;
                var wasAlive = target.Alive;
                target.hp = Math.Max(0f, target.hp - DamageAgainst(unit, target));
                if (wasAlive && !target.Alive)
                {
                    unit.kills += 1;
                    if (unit.team == BattleTeam.Friendly)
                    {
                        FriendlyKills += 1;
                    }
                    else
                    {
                        FriendlyCasualties += 1;
                    }
                }
            }

            EvaluateResult();
        }

        public bool DeployReinforcement(BattleUnitKind kind)
        {
            if (IsFinished)
            {
                return false;
            }

            var count = kind == BattleUnitKind.Cavalry ? 2 : 3;
            SpawnFormation(
                BattleTeam.Friendly,
                kind,
                count,
                0.04f,
                0.30f + (int)kind * 0.11f);
            return true;
        }

        public void Retreat()
        {
            if (IsFinished)
            {
                return;
            }

            Victory = false;
            IsFinished = true;
        }

        private void SpawnFormation(
            BattleTeam team,
            BattleUnitKind kind,
            int count,
            float x,
            float startY,
            float healthMultiplier = 1f,
            float rangeMultiplier = 1f)
        {
            for (var index = 0; index < count; index++)
            {
                var row = index / 5;
                var column = index % 5;
                var direction = team == BattleTeam.Friendly ? 1f : -1f;
                var baseStats = Stats(kind);
                var maxHealth = baseStats.health * healthMultiplier;
                units.Add(new BattleUnit
                {
                    id = nextId++,
                    team = team,
                    kind = kind,
                    x = x - direction * row * 0.035f,
                    y = Math.Min(0.88f, startY + column * 0.115f),
                    hp = maxHealth,
                    maxHp = maxHealth,
                    damage = baseStats.damage,
                    speed = baseStats.speed,
                    range = baseStats.range * rangeMultiplier,
                    attackDelay = baseStats.delay,
                    attackTimer = index * 0.035f
                });
            }
        }

        private BattleUnit FindNearestTarget(BattleUnit source)
        {
            BattleUnit selected = null;
            var nearestDistance = float.MaxValue;
            foreach (var target in units)
            {
                if (!target.Alive || target.team == source.team)
                {
                    continue;
                }

                var dx = target.x - source.x;
                var dy = target.y - source.y;
                var weightedDistance = dx * dx + dy * dy;
                if (weightedDistance < nearestDistance)
                {
                    nearestDistance = weightedDistance;
                    selected = target;
                }
            }

            return selected;
        }

        private static float DamageAgainst(BattleUnit attacker, BattleUnit target)
        {
            var multiplier = 1f;
            if (attacker.kind == BattleUnitKind.Cavalry &&
                target.kind == BattleUnitKind.Archer)
            {
                multiplier = 1.35f;
            }
            else if (attacker.kind == BattleUnitKind.Infantry &&
                     target.kind == BattleUnitKind.Cavalry)
            {
                multiplier = 1.18f;
            }
            else if (attacker.kind == BattleUnitKind.Archer &&
                     target.kind == BattleUnitKind.Infantry)
            {
                multiplier = 1.16f;
            }
            else if (attacker.kind == BattleUnitKind.Siege)
            {
                multiplier = 1.28f;
            }

            return attacker.damage * multiplier;
        }

        private void EvaluateResult()
        {
            var friendlyAlive = FriendlyAlive;
            var enemyAlive = EnemyAlive;
            if (friendlyAlive > 0 && enemyAlive > 0 && Elapsed < MaximumDuration)
            {
                return;
            }

            if (friendlyAlive == enemyAlive && friendlyAlive > 0)
            {
                var friendlyHealth = units
                    .Where(item => item.team == BattleTeam.Friendly && item.Alive)
                    .Sum(item => item.HealthRatio);
                var enemyHealth = units
                    .Where(item => item.team == BattleTeam.Enemy && item.Alive)
                    .Sum(item => item.HealthRatio);
                Victory = friendlyHealth >= enemyHealth;
            }
            else
            {
                Victory = friendlyAlive > enemyAlive;
            }

            IsFinished = true;
        }

        private static (
            float health,
            float damage,
            float speed,
            float range,
            float delay) Stats(BattleUnitKind kind)
        {
            return kind switch
            {
                BattleUnitKind.Infantry => (130f, 24f, 0.058f, 0.032f, 0.78f),
                BattleUnitKind.Archer => (82f, 21f, 0.043f, 0.185f, 0.96f),
                BattleUnitKind.Cavalry => (112f, 34f, 0.088f, 0.045f, 0.86f),
                BattleUnitKind.Siege => (175f, 52f, 0.025f, 0.255f, 1.65f),
                _ => throw new ArgumentOutOfRangeException(nameof(kind), kind, null)
            };
        }
    }
}
