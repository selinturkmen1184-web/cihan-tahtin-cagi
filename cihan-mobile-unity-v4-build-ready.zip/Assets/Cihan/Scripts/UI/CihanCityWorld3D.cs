using System;
using System.Collections.Generic;
using Cihan.Domain;
using Cihan.Services;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Cihan.UI
{
    public sealed class CityBuildingMarker : MonoBehaviour
    {
        public string buildingId;
    }

    public sealed class CihanCityWorld3D : MonoBehaviour,
        IPointerClickHandler,
        IBeginDragHandler,
        IDragHandler,
        IEndDragHandler,
        IScrollHandler
    {
        private const int CityLayer = 30;
        private static readonly Vector3 WorldOffset = new(2500f, 0f, 0f);

        private readonly Dictionary<string, Transform> buildingAnchors = new();
        private readonly List<Material> materials = new();
        private readonly List<Transform> flags = new();
        private readonly List<Transform> smokePuffs = new();
        private readonly List<Transform> citizens = new();

        private GameService game;
        private Action<string> selected;
        private GameObject worldRoot;
        private Camera cityCamera;
        private RenderTexture renderTexture;
        private Light sun;
        private Transform selectionDisc;
        private Transform scaffold;
        private Transform windmill;
        private Transform crane;
        private Material grass;
        private Material darkGrass;
        private Material road;
        private Material stone;
        private Material paleStone;
        private Material roof;
        private Material wood;
        private Material teal;
        private Material gold;
        private Material water;
        private Material soil;
        private Material white;
        private Material crimson;
        private float yaw = 42f;
        private float pitch = 34f;
        private float zoom = 24f;
        private bool dragging;
        private string selectedId = "palace";

        public void Configure(GameService service, Action<string> onSelected)
        {
            game = service;
            selected = onSelected;
            BuildMaterials();
            BuildWorld();
            BuildCamera();
            SelectBuilding(selectedId, true);
        }

        private void BuildMaterials()
        {
            grass = CreateMaterial(new Color32(74, 92, 63, 255), 0f, 0.08f);
            darkGrass = CreateMaterial(new Color32(47, 65, 48, 255), 0f, 0.06f);
            road = CreateMaterial(new Color32(126, 112, 85, 255), 0f, 0.1f);
            stone = CreateMaterial(new Color32(105, 110, 106, 255), 0f, 0.18f);
            paleStone = CreateMaterial(new Color32(176, 169, 146, 255), 0f, 0.2f);
            roof = CreateMaterial(new Color32(62, 88, 86, 255), 0.05f, 0.28f);
            wood = CreateMaterial(new Color32(105, 69, 39, 255), 0f, 0.14f);
            teal = CreateMaterial(new Color32(44, 126, 115, 255), 0.08f, 0.3f);
            gold = CreateMaterial(new Color32(218, 172, 73, 255), 0.32f, 0.48f);
            water = CreateMaterial(new Color32(45, 111, 127, 255), 0.08f, 0.5f);
            soil = CreateMaterial(new Color32(115, 79, 47, 255), 0f, 0.04f);
            white = CreateMaterial(new Color32(224, 220, 201, 255), 0f, 0.16f);
            crimson = CreateMaterial(new Color32(135, 45, 39, 255), 0.12f, 0.28f);
        }

        private void BuildWorld()
        {
            worldRoot = new GameObject("CİHAN · Yaşayan 3B Başkent");
            worldRoot.transform.position = WorldOffset;

            Box(
                "Şehir Zemini",
                new Vector3(0f, -0.35f, 0f),
                new Vector3(44f, 0.7f, 32f),
                grass,
                worldRoot.transform);
            Box(
                "Nehir",
                new Vector3(-18.4f, -0.05f, 0f),
                new Vector3(5.5f, 0.18f, 32f),
                water,
                worldRoot.transform);
            Box(
                "Ana Yol",
                new Vector3(1f, 0.04f, 0f),
                new Vector3(31f, 0.1f, 2.2f),
                road,
                worldRoot.transform);
            Box(
                "Divan Yolu",
                new Vector3(0f, 0.05f, 1f),
                new Vector3(2.2f, 0.11f, 24f),
                road,
                worldRoot.transform);
            BuildBridge();
            BuildWalls();
            BuildPalace();
            BuildFarm();
            BuildLumberYard();
            BuildQuarry();
            BuildBarracks();
            BuildHospital();
            BuildHouses();
            BuildPopulation();
            BuildSelectionDisc();
            BuildScaffold();
            SetLayerRecursively(worldRoot, CityLayer);
        }

        private void BuildCamera()
        {
            var cameraObject = new GameObject("Başkent Kamerası");
            cityCamera = cameraObject.AddComponent<Camera>();
            cityCamera.orthographic = true;
            cityCamera.orthographicSize = zoom;
            cityCamera.clearFlags = CameraClearFlags.SolidColor;
            cityCamera.backgroundColor = new Color32(15, 25, 29, 255);
            cityCamera.nearClipPlane = 0.1f;
            cityCamera.farClipPlane = 150f;
            cityCamera.allowHDR = true;
            cityCamera.allowMSAA = true;
            cityCamera.cullingMask = 1 << CityLayer;

            renderTexture = new RenderTexture(1024, 640, 24, RenderTextureFormat.ARGB32)
            {
                name = "CİHAN Başkent Render",
                antiAliasing = 4
            };
            renderTexture.Create();
            cityCamera.targetTexture = renderTexture;

            var rawImage = GetComponent<RawImage>();
            rawImage.texture = renderTexture;
            rawImage.color = Color.white;
            rawImage.raycastTarget = true;

            var lightObject = new GameObject("Başkent Güneşi");
            lightObject.transform.SetParent(worldRoot.transform, false);
            lightObject.transform.rotation = Quaternion.Euler(48f, -32f, 0f);
            sun = lightObject.AddComponent<Light>();
            sun.type = LightType.Directional;
            sun.color = new Color32(255, 225, 176, 255);
            sun.intensity = 1.2f;
            sun.shadows = LightShadows.Soft;
            sun.cullingMask = 1 << CityLayer;

            var fillObject = new GameObject("Gökyüzü Dolgu Işığı");
            fillObject.transform.SetParent(worldRoot.transform, false);
            fillObject.transform.localPosition = new Vector3(-8f, 14f, -10f);
            var fill = fillObject.AddComponent<Light>();
            fill.type = LightType.Point;
            fill.range = 50f;
            fill.intensity = 0.65f;
            fill.color = new Color32(118, 171, 181, 255);
            fill.cullingMask = 1 << CityLayer;

            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Trilight;
            RenderSettings.ambientSkyColor = new Color32(101, 125, 132, 255);
            RenderSettings.ambientEquatorColor = new Color32(72, 78, 72, 255);
            RenderSettings.ambientGroundColor = new Color32(35, 38, 34, 255);
            RefreshCamera();
        }

        private void BuildBridge()
        {
            Box(
                "Taş Köprü",
                new Vector3(-18.4f, 0.28f, 0f),
                new Vector3(6f, 0.55f, 3.2f),
                paleStone,
                worldRoot.transform);
            for (var index = -2; index <= 2; index++)
            {
                Box(
                    "Köprü Korkuluğu",
                    new Vector3(-18.4f + index * 1.25f, 0.9f, -1.45f),
                    new Vector3(0.18f, 1.1f, 0.18f),
                    stone,
                    worldRoot.transform);
                Box(
                    "Köprü Korkuluğu",
                    new Vector3(-18.4f + index * 1.25f, 0.9f, 1.45f),
                    new Vector3(0.18f, 1.1f, 0.18f),
                    stone,
                    worldRoot.transform);
            }
        }

        private void BuildWalls()
        {
            Box("Kuzey Suru", new Vector3(0f, 1.4f, 14f), new Vector3(32f, 3f, 1.2f), stone, worldRoot.transform);
            Box("Güney Suru Sol", new Vector3(-9.5f, 1.4f, -14f), new Vector3(13f, 3f, 1.2f), stone, worldRoot.transform);
            Box("Güney Suru Sağ", new Vector3(9.5f, 1.4f, -14f), new Vector3(13f, 3f, 1.2f), stone, worldRoot.transform);
            Box("Doğu Suru", new Vector3(15.5f, 1.4f, 0f), new Vector3(1.2f, 3f, 29f), stone, worldRoot.transform);
            Box("Batı Suru", new Vector3(-15.5f, 1.4f, 0f), new Vector3(1.2f, 3f, 29f), stone, worldRoot.transform);

            foreach (var position in new[]
                     {
                         new Vector3(-15.5f, 2.2f, -14f),
                         new Vector3(15.5f, 2.2f, -14f),
                         new Vector3(-15.5f, 2.2f, 14f),
                         new Vector3(15.5f, 2.2f, 14f),
                         new Vector3(-3.2f, 2.2f, -14f),
                         new Vector3(3.2f, 2.2f, -14f)
                     })
            {
                Cylinder("Sur Kulesi", position, new Vector3(2.5f, 2.3f, 2.5f), stone, worldRoot.transform);
                Cylinder("Kule Külahı", position + Vector3.up * 2.65f, new Vector3(2.8f, 0.45f, 2.8f), roof, worldRoot.transform);
            }

            Box("Şehir Kapısı", new Vector3(0f, 1.8f, -14.15f), new Vector3(5.2f, 3.8f, 0.5f), wood, worldRoot.transform);
            AddFlag(worldRoot.transform, new Vector3(0f, 6.2f, -14f), teal);
        }

        private Transform CreateBuildingAnchor(
            string id,
            Vector3 position,
            Vector3 colliderSize)
        {
            var anchor = new GameObject($"{id} Yapı Alanı");
            anchor.transform.SetParent(worldRoot.transform, false);
            anchor.transform.localPosition = position;
            var marker = anchor.AddComponent<CityBuildingMarker>();
            marker.buildingId = id;
            var collider = anchor.AddComponent<BoxCollider>();
            collider.center = new Vector3(0f, colliderSize.y * 0.5f, 0f);
            collider.size = colliderSize;
            buildingAnchors[id] = anchor.transform;
            return anchor.transform;
        }

        private void BuildPalace()
        {
            var level = game.State.GetBuilding("palace").level;
            var anchor = CreateBuildingAnchor("palace", Vector3.zero, new Vector3(8.5f, 7f, 7f));
            var scale = 1f + level * 0.035f;
            Box("Saray Gövdesi", new Vector3(0f, 1.65f, 0f), new Vector3(6.2f, 3.3f, 4.8f) * scale, paleStone, anchor);
            Box("Saray Girişi", new Vector3(0f, 1.25f, -2.55f), new Vector3(2.2f, 2.5f, 0.7f), teal, anchor);
            Cylinder("Saray Kubbesi", new Vector3(0f, 4.05f, 0f), new Vector3(3.4f, 1.25f, 3.4f) * scale, roof, anchor);
            Cylinder("Altın Alem", new Vector3(0f, 5.55f, 0f), new Vector3(0.22f, 1.25f, 0.22f), gold, anchor);
            Sphere("Alem", new Vector3(0f, 6.25f, 0f), Vector3.one * 0.42f, gold, anchor);

            foreach (var x in new[] { -3.6f, 3.6f })
            {
                Cylinder("Saray Kulesi", new Vector3(x, 2.3f, 0f), new Vector3(1.25f, 2.5f, 1.25f), paleStone, anchor);
                Cylinder("Kule Külahı", new Vector3(x, 4.95f, 0f), new Vector3(1.45f, 0.55f, 1.45f), roof, anchor);
                AddFlag(anchor, new Vector3(x, 6.1f, 0f), teal);
            }
        }

        private void BuildFarm()
        {
            var level = game.State.GetBuilding("farm").level;
            var anchor = CreateBuildingAnchor("farm", new Vector3(-10.5f, 0f, -7.5f), new Vector3(8f, 5f, 7f));
            for (var row = -1; row <= 1; row++)
            {
                Box("Ekin Tarlası", new Vector3(-0.9f, 0.12f, row * 1.55f), new Vector3(4.7f, 0.22f, 1.05f), soil, anchor);
                for (var crop = -2; crop <= 2; crop++)
                {
                    Box(
                        "Buğday",
                        new Vector3(-2.4f + crop * 0.78f, 0.42f, row * 1.55f),
                        new Vector3(0.12f, 0.7f + level * 0.04f, 0.12f),
                        gold,
                        anchor);
                }
            }

            Cylinder("Değirmen", new Vector3(2.2f, 1.7f, 0f), new Vector3(1.1f, 1.8f, 1.1f), paleStone, anchor);
            windmill = new GameObject("Değirmen Kanatları").transform;
            windmill.SetParent(anchor, false);
            windmill.localPosition = new Vector3(2.2f, 2.4f, -1.2f);
            Box("Kanat", Vector3.zero, new Vector3(0.28f, 4.3f, 0.18f), wood, windmill);
            Box("Kanat", Vector3.zero, new Vector3(4.3f, 0.28f, 0.18f), wood, windmill);
        }

        private void BuildLumberYard()
        {
            var anchor = CreateBuildingAnchor("lumber", new Vector3(10.5f, 0f, -7.2f), new Vector3(7f, 5f, 7f));
            Box("Kereste Binası", new Vector3(0f, 1.25f, 0f), new Vector3(4.4f, 2.5f, 3.6f), wood, anchor);
            Cylinder("Kereste Çatısı", new Vector3(0f, 2.85f, 0f), new Vector3(2.8f, 0.5f, 2.5f), roof, anchor);
            for (var index = 0; index < 5; index++)
            {
                var log = Cylinder(
                    "İşlenmiş Kütük",
                    new Vector3(-2.1f + index * 0.75f, 0.35f, -2.3f),
                    new Vector3(0.28f, 1.35f, 0.28f),
                    wood,
                    anchor);
                log.transform.rotation = Quaternion.Euler(0f, 0f, 90f);
            }

            AddSmoke(anchor, new Vector3(1.3f, 3.6f, 0.8f));
        }

        private void BuildQuarry()
        {
            var anchor = CreateBuildingAnchor("quarry", new Vector3(-10.5f, 0f, 7.2f), new Vector3(8f, 6f, 7f));
            Box("Taş Ocağı Çukuru", new Vector3(0f, 0.08f, 0f), new Vector3(6.2f, 0.16f, 4.6f), darkGrass, anchor);
            for (var index = 0; index < 8; index++)
            {
                var x = -2.4f + index % 4 * 1.55f;
                var z = -1.5f + index / 4 * 2.7f;
                Sphere("Kesme Taş", new Vector3(x, 0.48f, z), new Vector3(1.2f, 0.8f, 1f), stone, anchor);
            }

            Box("Vinç Direği", new Vector3(2.6f, 2f, 0f), new Vector3(0.32f, 4f, 0.32f), wood, anchor);
            crane = new GameObject("Taş Ocağı Vinci").transform;
            crane.SetParent(anchor, false);
            crane.localPosition = new Vector3(2.6f, 3.7f, 0f);
            Box("Vinç Kolu", new Vector3(-1.4f, 0f, 0f), new Vector3(3.2f, 0.28f, 0.28f), wood, crane);
            Box("Vinç Halatı", new Vector3(-2.8f, -1.1f, 0f), new Vector3(0.08f, 2.2f, 0.08f), gold, crane);
        }

        private void BuildBarracks()
        {
            var level = game.State.GetBuilding("barracks").level;
            var anchor = CreateBuildingAnchor("barracks", new Vector3(10.2f, 0f, 7f), new Vector3(8f, 6f, 7f));
            Box("Kışla", new Vector3(0f, 1.4f, 0f), new Vector3(6f, 2.8f, 4f), stone, anchor);
            Cylinder("Kışla Çatısı", new Vector3(0f, 3.15f, 0f), new Vector3(3.7f, 0.55f, 2.8f), roof, anchor);
            Box("Kışla Kapısı", new Vector3(0f, 1.15f, -2.08f), new Vector3(1.8f, 2.3f, 0.25f), wood, anchor);
            AddFlag(anchor, new Vector3(-2.4f, 5.1f, 0f), teal);
            AddFlag(anchor, new Vector3(2.4f, 5.1f, 0f), level >= 3 ? gold : teal);

            for (var index = 0; index < 3; index++)
            {
                Box(
                    "Eğitim Hedefi",
                    new Vector3(-2.2f + index * 2.2f, 0.95f, -3.1f),
                    new Vector3(0.8f, 1.8f, 0.2f),
                    wood,
                    anchor);
            }
        }

        private void BuildHospital()
        {
            var anchor = CreateBuildingAnchor("hospital", new Vector3(0f, 0f, 9f), new Vector3(8f, 6f, 6f));
            Box("Darüşşifa", new Vector3(0f, 1.35f, 0f), new Vector3(6f, 2.7f, 3.8f), white, anchor);
            Cylinder("Darüşşifa Kubbesi", new Vector3(0f, 3.15f, 0f), new Vector3(2.8f, 0.75f, 2.8f), teal, anchor);
            Box("Darüşşifa Kapısı", new Vector3(0f, 1.05f, -2f), new Vector3(1.5f, 2.1f, 0.2f), wood, anchor);
            Box("Şifa İşareti", new Vector3(0f, 2f, -2.15f), new Vector3(1.25f, 0.28f, 0.12f), crimson, anchor);
            Box("Şifa İşareti", new Vector3(0f, 2f, -2.15f), new Vector3(0.28f, 1.25f, 0.12f), crimson, anchor);
            AddSmoke(anchor, new Vector3(2f, 3.6f, 0.7f));
        }

        private void BuildHouses()
        {
            var positions = new[]
            {
                new Vector3(-6.5f, 0f, -8.5f),
                new Vector3(-5.8f, 0f, 7.8f),
                new Vector3(5.7f, 0f, -8.8f),
                new Vector3(6f, 0f, 9.6f),
                new Vector3(-7.3f, 0f, 3.3f),
                new Vector3(7.1f, 0f, 3f)
            };

            for (var index = 0; index < positions.Length; index++)
            {
                var house = new GameObject($"Hane {index + 1}").transform;
                house.SetParent(worldRoot.transform, false);
                house.localPosition = positions[index];
                Box("Hane", new Vector3(0f, 0.75f, 0f), new Vector3(2.5f, 1.5f, 2.2f), index % 2 == 0 ? paleStone : wood, house);
                Cylinder("Hane Çatısı", new Vector3(0f, 1.85f, 0f), new Vector3(1.65f, 0.42f, 1.55f), roof, house);
            }
        }

        private void BuildPopulation()
        {
            for (var index = 0; index < 7; index++)
            {
                var citizen = new GameObject($"Şehir Sakini {index + 1}").transform;
                citizen.SetParent(worldRoot.transform, false);
                citizen.localPosition = new Vector3(-8f + index * 2.4f, 0.45f, index % 2 == 0 ? -0.7f : 0.65f);
                Capsule("Kaftan", Vector3.zero, new Vector3(0.42f, 0.65f, 0.42f), index % 3 == 0 ? teal : crimson, citizen);
                Sphere("Baş", new Vector3(0f, 0.78f, 0f), Vector3.one * 0.28f, paleStone, citizen);
                citizens.Add(citizen);
            }
        }

        private void BuildSelectionDisc()
        {
            var disc = Cylinder(
                "Seçili Yapı Mührü",
                new Vector3(0f, 0.05f, 0f),
                new Vector3(4.3f, 0.05f, 4.3f),
                gold,
                worldRoot.transform);
            DisableCollider(disc);
            selectionDisc = disc.transform;
        }

        private void BuildScaffold()
        {
            scaffold = new GameObject("İnşa İskelesi").transform;
            scaffold.SetParent(worldRoot.transform, false);
            for (var x = -1; x <= 1; x += 2)
            {
                for (var z = -1; z <= 1; z += 2)
                {
                    var beam = Box(
                        "İskele Direği",
                        new Vector3(x * 2.5f, 2.3f, z * 2f),
                        new Vector3(0.22f, 4.6f, 0.22f),
                        wood,
                        scaffold);
                    DisableCollider(beam);
                }
            }

            for (var height = 1; height <= 3; height++)
            {
                var crossA = Box(
                    "İskele Yatay",
                    new Vector3(0f, height * 1.2f, -2f),
                    new Vector3(5.2f, 0.18f, 0.18f),
                    wood,
                    scaffold);
                var crossB = Box(
                    "İskele Yatay",
                    new Vector3(0f, height * 1.2f, 2f),
                    new Vector3(5.2f, 0.18f, 0.18f),
                    wood,
                    scaffold);
                DisableCollider(crossA);
                DisableCollider(crossB);
            }

            scaffold.gameObject.SetActive(false);
        }

        private void AddFlag(Transform parent, Vector3 position, Material fabric)
        {
            Box("Sancak Direği", position, new Vector3(0.12f, 2.4f, 0.12f), gold, parent);
            var flag = Box(
                "Cihan Sancağı",
                position + new Vector3(0.65f, 0.55f, 0f),
                new Vector3(1.25f, 0.72f, 0.08f),
                fabric,
                parent);
            flags.Add(flag.transform);
        }

        private void AddSmoke(Transform parent, Vector3 position)
        {
            for (var index = 0; index < 3; index++)
            {
                var puff = Sphere(
                    "Baca Dumanı",
                    position + Vector3.up * index * 0.48f,
                    Vector3.one * (0.35f + index * 0.12f),
                    white,
                    parent);
                DisableCollider(puff);
                smokePuffs.Add(puff.transform);
            }
        }

        private void Update()
        {
            if (cityCamera == null || game == null)
            {
                return;
            }

            if (!dragging && Input.touchCount == 0)
            {
                yaw += Time.unscaledDeltaTime * 0.8f;
            }

            if (Input.touchCount == 2 &&
                RectTransformUtility.RectangleContainsScreenPoint(
                    (RectTransform)transform,
                    Input.GetTouch(0).position) &&
                RectTransformUtility.RectangleContainsScreenPoint(
                    (RectTransform)transform,
                    Input.GetTouch(1).position))
            {
                var current = Vector2.Distance(
                    Input.GetTouch(0).position,
                    Input.GetTouch(1).position);
                var previous = Vector2.Distance(
                    Input.GetTouch(0).position - Input.GetTouch(0).deltaPosition,
                    Input.GetTouch(1).position - Input.GetTouch(1).deltaPosition);
                zoom = Mathf.Clamp(zoom - (current - previous) * 0.012f, 15f, 31f);
            }

            if (windmill != null)
            {
                windmill.Rotate(Vector3.forward, Time.unscaledDeltaTime * 38f, Space.Self);
            }

            if (crane != null)
            {
                crane.localRotation = Quaternion.Euler(
                    0f,
                    Mathf.Sin(Time.unscaledTime * 0.45f) * 12f,
                    0f);
            }

            for (var index = 0; index < flags.Count; index++)
            {
                var scale = flags[index].localScale;
                scale.x = 1f + Mathf.Sin(Time.unscaledTime * 2.4f + index) * 0.08f;
                flags[index].localScale = scale;
            }

            for (var index = 0; index < smokePuffs.Count; index++)
            {
                var puff = smokePuffs[index];
                var bob = Mathf.Sin(Time.unscaledTime * 1.1f + index * 1.7f) * 0.12f;
                puff.localPosition += Vector3.up * bob * Time.unscaledDeltaTime;
            }

            for (var index = 0; index < citizens.Count; index++)
            {
                var citizen = citizens[index];
                var position = citizen.localPosition;
                position.x += Time.unscaledDeltaTime * (0.45f + index * 0.025f);
                if (position.x > 10f)
                {
                    position.x = -10f;
                }

                citizen.localPosition = position;
                citizen.localRotation = Quaternion.Euler(0f, 90f, 0f);
            }

            SyncConstruction();
            RefreshCamera();
        }

        private void SyncConstruction()
        {
            var job = game.State.construction;
            if (job == null || !buildingAnchors.TryGetValue(job.targetId, out var anchor))
            {
                scaffold.gameObject.SetActive(false);
                return;
            }

            scaffold.gameObject.SetActive(true);
            scaffold.localPosition = anchor.localPosition;
            var pulse = 1f + Mathf.Sin(Time.unscaledTime * 3.2f) * 0.035f;
            scaffold.localScale = Vector3.one * pulse;
        }

        private void RefreshCamera()
        {
            var yawRadians = yaw * Mathf.Deg2Rad;
            var pitchRadians = pitch * Mathf.Deg2Rad;
            var distance = 48f;
            var horizontal = Mathf.Cos(pitchRadians) * distance;
            var offset = new Vector3(
                Mathf.Sin(yawRadians) * horizontal,
                Mathf.Sin(pitchRadians) * distance,
                Mathf.Cos(yawRadians) * horizontal);
            var target = WorldOffset + new Vector3(0f, 1.8f, 0f);
            cityCamera.transform.position = target + offset;
            cityCamera.transform.LookAt(target);
            cityCamera.orthographicSize = zoom;
        }

        public void OnPointerClick(PointerEventData eventData)
        {
            if (eventData.dragging ||
                !RectTransformUtility.ScreenPointToLocalPointInRectangle(
                    (RectTransform)transform,
                    eventData.position,
                    eventData.pressEventCamera,
                    out var local))
            {
                return;
            }

            var rect = ((RectTransform)transform).rect;
            var viewport = new Vector3(
                Mathf.InverseLerp(rect.xMin, rect.xMax, local.x),
                Mathf.InverseLerp(rect.yMin, rect.yMax, local.y),
                0f);
            var ray = cityCamera.ViewportPointToRay(viewport);
            if (!Physics.Raycast(ray, out var hit, 150f, 1 << CityLayer))
            {
                return;
            }

            var marker = hit.collider.GetComponentInParent<CityBuildingMarker>();
            if (marker != null)
            {
                SelectBuilding(marker.buildingId, true);
            }
        }

        public void OnBeginDrag(PointerEventData eventData)
        {
            dragging = true;
        }

        public void OnDrag(PointerEventData eventData)
        {
            yaw -= eventData.delta.x * 0.16f;
            pitch = Mathf.Clamp(pitch + eventData.delta.y * 0.04f, 25f, 48f);
        }

        public void OnEndDrag(PointerEventData eventData)
        {
            dragging = false;
        }

        public void OnScroll(PointerEventData eventData)
        {
            zoom = Mathf.Clamp(zoom - eventData.scrollDelta.y * 1.2f, 15f, 31f);
        }

        public void SelectBuilding(string buildingId, bool notify)
        {
            if (!buildingAnchors.TryGetValue(buildingId, out var anchor))
            {
                return;
            }

            selectedId = buildingId;
            selectionDisc.localPosition = anchor.localPosition + Vector3.up * 0.035f;
            if (notify)
            {
                selected?.Invoke(buildingId);
            }
        }

        private Material CreateMaterial(Color color, float metallic, float smoothness)
        {
            var shader = Shader.Find("Universal Render Pipeline/Lit") ??
                         Shader.Find("Standard") ??
                         Shader.Find("Sprites/Default");
            var material = new Material(shader)
            {
                color = color
            };
            if (material.HasProperty("_BaseColor")) material.SetColor("_BaseColor", color);
            if (material.HasProperty("_Metallic")) material.SetFloat("_Metallic", metallic);
            if (material.HasProperty("_Smoothness")) material.SetFloat("_Smoothness", smoothness);
            materials.Add(material);
            return material;
        }

        private GameObject Box(
            string name,
            Vector3 position,
            Vector3 scale,
            Material material,
            Transform parent)
        {
            return Primitive(PrimitiveType.Cube, name, position, scale, material, parent);
        }

        private GameObject Cylinder(
            string name,
            Vector3 position,
            Vector3 scale,
            Material material,
            Transform parent)
        {
            return Primitive(PrimitiveType.Cylinder, name, position, scale, material, parent);
        }

        private GameObject Sphere(
            string name,
            Vector3 position,
            Vector3 scale,
            Material material,
            Transform parent)
        {
            return Primitive(PrimitiveType.Sphere, name, position, scale, material, parent);
        }

        private GameObject Capsule(
            string name,
            Vector3 position,
            Vector3 scale,
            Material material,
            Transform parent)
        {
            return Primitive(PrimitiveType.Capsule, name, position, scale, material, parent);
        }

        private static GameObject Primitive(
            PrimitiveType type,
            string name,
            Vector3 position,
            Vector3 scale,
            Material material,
            Transform parent)
        {
            var instance = GameObject.CreatePrimitive(type);
            instance.name = name;
            instance.transform.SetParent(parent, false);
            instance.transform.localPosition = position;
            instance.transform.localScale = scale;
            var renderer = instance.GetComponent<Renderer>();
            renderer.sharedMaterial = material;
            renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.On;
            renderer.receiveShadows = true;
            return instance;
        }

        private static void DisableCollider(GameObject instance)
        {
            var collider = instance.GetComponent<Collider>();
            if (collider != null)
            {
                collider.enabled = false;
            }
        }

        private static void SetLayerRecursively(GameObject root, int layer)
        {
            root.layer = layer;
            foreach (Transform child in root.transform)
            {
                SetLayerRecursively(child.gameObject, layer);
            }
        }

        private void OnDestroy()
        {
            if (cityCamera != null)
            {
                cityCamera.targetTexture = null;
                Destroy(cityCamera.gameObject);
            }

            if (renderTexture != null)
            {
                renderTexture.Release();
                Destroy(renderTexture);
            }

            if (worldRoot != null)
            {
                Destroy(worldRoot);
            }

            foreach (var material in materials)
            {
                if (material != null)
                {
                    Destroy(material);
                }
            }
        }
    }
}
