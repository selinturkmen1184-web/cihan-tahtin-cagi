using System;
using System.Collections.Generic;
using System.Linq;
using Cihan.Domain;
using Cihan.Services;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Cihan.UI
{
    public static class MobileGameBootstrap
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        private static void Initialize()
        {
            if (UnityEngine.Object.FindFirstObjectByType<GameService>() != null)
            {
                return;
            }

            Application.targetFrameRate = 60;
            Screen.sleepTimeout = SleepTimeout.NeverSleep;
            var root = new GameObject("CİHAN · Mobil MVP");
            root.AddComponent<GameService>();
            root.AddComponent<CihanGameApp>();

            if (UnityEngine.Object.FindFirstObjectByType<EventSystem>() == null)
            {
                var eventSystem = new GameObject("EventSystem");
                eventSystem.AddComponent<EventSystem>();
                eventSystem.AddComponent<StandaloneInputModule>();
                UnityEngine.Object.DontDestroyOnLoad(eventSystem);
            }
        }
    }

    public sealed class SafeAreaFitter : MonoBehaviour
    {
        private Rect lastSafeArea;
        private Vector2Int lastScreenSize;

        private void Awake()
        {
            Apply();
        }

        private void Update()
        {
            var currentSize = new Vector2Int(Screen.width, Screen.height);
            if (lastSafeArea != Screen.safeArea || lastScreenSize != currentSize)
            {
                Apply();
            }
        }

        private void Apply()
        {
            var safeArea = Screen.safeArea;
            var rect = (RectTransform)transform;
            var screenWidth = Mathf.Max(1f, Screen.width);
            var screenHeight = Mathf.Max(1f, Screen.height);

            rect.anchorMin = new Vector2(
                safeArea.xMin / screenWidth,
                safeArea.yMin / screenHeight);
            rect.anchorMax = new Vector2(
                safeArea.xMax / screenWidth,
                safeArea.yMax / screenHeight);
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;

            lastSafeArea = safeArea;
            lastScreenSize = new Vector2Int(Screen.width, Screen.height);
        }
    }

    public sealed class CihanGameApp : MonoBehaviour
    {
        private enum ScreenId
        {
            City,
            Army,
            Heroes,
            Map
        }

        private static readonly Color32 Ink = new(7, 11, 16, 255);
        private static readonly Color32 Panel = new(15, 23, 31, 255);
        private static readonly Color32 PanelSoft = new(22, 32, 42, 255);
        private static readonly Color32 Gold = new(216, 173, 84, 255);
        private static readonly Color32 GoldBright = new(242, 217, 149, 255);
        private static readonly Color32 Ivory = new(243, 238, 226, 255);
        private static readonly Color32 Muted = new(151, 160, 166, 255);
        private static readonly Color32 Teal = new(62, 143, 131, 255);
        private static readonly Color32 Crimson = new(139, 52, 48, 255);

        private readonly Dictionary<ResourceType, Text> resourceTexts = new();
        private readonly Dictionary<ScreenId, Button> navigationButtons = new();

        private GameService game;
        private Font font;
        private RectTransform content;
        private Text powerText;
        private Text eventText;
        private Text screenTitle;
        private Text activeJobDescription;
        private RectTransform activeJobProgress;
        private TimedJob activeJob;
        private Text selectedBuildingText;
        private Button selectedBuildingButton;
        private ScreenId currentScreen;
        private int renderedScreenRevision;
        private string selectedCityBuildingId = "palace";

        private void Start()
        {
            game = GameService.Instance;
            font = LoadFont();
            BuildInterface();
            game.Changed += HandleChanged;
            ShowScreen(ScreenId.City);
        }

        private void OnDestroy()
        {
            if (game != null)
            {
                game.Changed -= HandleChanged;
            }
        }

        private void Update()
        {
            if (activeJob == null ||
                activeJobDescription == null ||
                activeJobProgress == null)
            {
                return;
            }

            activeJobDescription.text =
                $"{JobTitle(activeJob)} · {activeJob.SecondsLeft(GameService.Now):00} sn kaldı";
            activeJobProgress.anchorMax =
                new Vector2(activeJob.Progress(GameService.Now), 1f);
        }

        private static Font LoadFont()
        {
            var loaded = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            if (loaded == null)
            {
                loaded = Resources.GetBuiltinResource<Font>("Arial.ttf");
            }

            return loaded;
        }

        private void BuildInterface()
        {
            var canvasObject = new GameObject("Mobil Arayüz");
            canvasObject.transform.SetParent(transform, false);
            var canvas = canvasObject.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 10;

            var scaler = canvasObject.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1080, 1920);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0.5f;
            canvasObject.AddComponent<GraphicRaycaster>();

            var background = CreatePanel(canvasObject.transform, "Arka Plan", Ink);
            Stretch(background.rectTransform);

            var safeArea = CreatePanel(canvasObject.transform, "Güvenli Alan", Color.clear);
            Stretch(safeArea.rectTransform);
            safeArea.gameObject.AddComponent<SafeAreaFitter>();

            BuildHeader(safeArea.transform);
            BuildContent(safeArea.transform);
            BuildNavigation(safeArea.transform);
            BuildEventBar(safeArea.transform);
        }

        private void BuildHeader(Transform parent)
        {
            var header = CreatePanel(parent, "Hükümdarlık Başlığı", Panel);
            SetAnchoredRect(
                header.rectTransform,
                new Vector2(0f, 1f),
                new Vector2(1f, 1f),
                new Vector2(0f, 270f),
                new Vector2(0f, -135f));

            var brand = CreateText(
                header.transform,
                "CİHAN",
                52,
                Ivory,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            SetAnchoredRect(
                brand.rectTransform,
                new Vector2(0f, 1f),
                new Vector2(0.55f, 1f),
                new Vector2(-60f, 92f),
                new Vector2(48f, -56f));

            var subtitle = CreateText(
                header.transform,
                "TAHTIN ÇAĞI · MOBİL MVP",
                19,
                Gold,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            subtitle.resizeTextForBestFit = true;
            SetAnchoredRect(
                subtitle.rectTransform,
                new Vector2(0f, 1f),
                new Vector2(0.6f, 1f),
                new Vector2(-60f, 44f),
                new Vector2(48f, -111f));

            powerText = CreateText(
                header.transform,
                "GÜÇ 0",
                27,
                GoldBright,
                TextAnchor.MiddleRight,
                FontStyle.Bold);
            SetAnchoredRect(
                powerText.rectTransform,
                new Vector2(0.55f, 1f),
                new Vector2(1f, 1f),
                new Vector2(-60f, 78f),
                new Vector2(-48f, -68f));

            var resources = new GameObject("Kaynaklar", typeof(RectTransform));
            resources.transform.SetParent(header.transform, false);
            SetAnchoredRect(
                (RectTransform)resources.transform,
                new Vector2(0f, 0f),
                new Vector2(1f, 0f),
                new Vector2(-72f, 104f),
                new Vector2(36f, 60f));
            var layout = resources.AddComponent<HorizontalLayoutGroup>();
            layout.spacing = 10f;
            layout.childAlignment = TextAnchor.MiddleCenter;
            layout.childControlWidth = true;
            layout.childControlHeight = true;
            layout.childForceExpandWidth = true;
            layout.childForceExpandHeight = true;

            AddResourceCell(resources.transform, ResourceType.Food, "ERZAK", "●");
            AddResourceCell(resources.transform, ResourceType.Wood, "KERES.", "╱");
            AddResourceCell(resources.transform, ResourceType.Stone, "TAŞ", "◆");
            AddResourceCell(resources.transform, ResourceType.Gold, "ALTIN", "◉");
        }

        private void AddResourceCell(
            Transform parent,
            ResourceType type,
            string label,
            string icon)
        {
            var cell = CreatePanel(parent, $"{label} Kaynağı", PanelSoft);
            var layoutElement = cell.gameObject.AddComponent<LayoutElement>();
            layoutElement.flexibleWidth = 1f;

            var iconText = CreateText(
                cell.transform,
                icon,
                26,
                GoldBright,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            SetAnchoredRect(
                iconText.rectTransform,
                new Vector2(0f, 0f),
                new Vector2(0.3f, 1f),
                Vector2.zero,
                new Vector2(12f, 0f));

            var valueText = CreateText(
                cell.transform,
                $"{label}\n0",
                20,
                Ivory,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            valueText.resizeTextForBestFit = true;
            valueText.resizeTextMinSize = 12;
            valueText.resizeTextMaxSize = 20;
            SetAnchoredRect(
                valueText.rectTransform,
                new Vector2(0.28f, 0f),
                new Vector2(1f, 1f),
                new Vector2(-8f, 0f),
                new Vector2(2f, 0f));
            resourceTexts[type] = valueText;
        }

        private void BuildContent(Transform parent)
        {
            var viewport = CreatePanel(parent, "İçerik Alanı", Ink);
            viewport.raycastTarget = true;
            viewport.gameObject.AddComponent<Mask>().showMaskGraphic = false;
            SetAnchoredRect(
                viewport.rectTransform,
                new Vector2(0f, 0f),
                new Vector2(1f, 1f),
                new Vector2(-28f, -430f),
                new Vector2(14f, -282f));

            var scroll = viewport.gameObject.AddComponent<ScrollRect>();
            scroll.horizontal = false;
            scroll.vertical = true;
            scroll.movementType = ScrollRect.MovementType.Elastic;
            scroll.scrollSensitivity = 70f;
            scroll.viewport = viewport.rectTransform;

            var contentObject = new GameObject("Akış", typeof(RectTransform));
            contentObject.transform.SetParent(viewport.transform, false);
            content = (RectTransform)contentObject.transform;
            content.anchorMin = new Vector2(0f, 1f);
            content.anchorMax = new Vector2(1f, 1f);
            content.pivot = new Vector2(0.5f, 1f);
            content.offsetMin = Vector2.zero;
            content.offsetMax = Vector2.zero;

            var layout = contentObject.AddComponent<VerticalLayoutGroup>();
            layout.padding = new RectOffset(22, 22, 22, 38);
            layout.spacing = 18f;
            layout.childAlignment = TextAnchor.UpperCenter;
            layout.childControlWidth = true;
            layout.childControlHeight = false;
            layout.childForceExpandWidth = true;
            layout.childForceExpandHeight = false;

            var fitter = contentObject.AddComponent<ContentSizeFitter>();
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
            scroll.content = content;
        }

        private void BuildNavigation(Transform parent)
        {
            var navigation = CreatePanel(parent, "Alt Menü", Panel);
            SetAnchoredRect(
                navigation.rectTransform,
                new Vector2(0f, 0f),
                new Vector2(1f, 0f),
                new Vector2(0f, 150f),
                new Vector2(0f, 75f));

            var layout = navigation.gameObject.AddComponent<HorizontalLayoutGroup>();
            layout.padding = new RectOffset(18, 18, 12, 12);
            layout.spacing = 10f;
            layout.childAlignment = TextAnchor.MiddleCenter;
            layout.childControlWidth = true;
            layout.childControlHeight = true;
            layout.childForceExpandWidth = true;
            layout.childForceExpandHeight = true;

            AddNavigationButton(navigation.transform, ScreenId.City, "♜\nBAŞKENT");
            AddNavigationButton(navigation.transform, ScreenId.Army, "⚔\nORDU");
            AddNavigationButton(navigation.transform, ScreenId.Heroes, "✦\nKOMUTAN");
            AddNavigationButton(navigation.transform, ScreenId.Map, "⌖\nDÜNYA");
        }

        private void AddNavigationButton(Transform parent, ScreenId id, string label)
        {
            var button = CreateButton(
                parent,
                label,
                () => ShowScreen(id),
                PanelSoft,
                22);
            navigationButtons[id] = button;
        }

        private void BuildEventBar(Transform parent)
        {
            var bar = CreatePanel(parent, "Haberci", new Color32(21, 29, 36, 255));
            SetAnchoredRect(
                bar.rectTransform,
                new Vector2(0f, 0f),
                new Vector2(1f, 0f),
                new Vector2(0f, 110f),
                new Vector2(0f, 205f));

            eventText = CreateText(
                bar.transform,
                "Payitaht emre hazır.",
                21,
                GoldBright,
                TextAnchor.MiddleCenter,
                FontStyle.Italic);
            eventText.resizeTextForBestFit = true;
            eventText.resizeTextMinSize = 15;
            eventText.resizeTextMaxSize = 21;
            Stretch(eventText.rectTransform, 24f, 24f, 8f, 8f);
        }

        private void ShowScreen(ScreenId id)
        {
            currentScreen = id;
            RefreshHeader();
            foreach (var pair in navigationButtons)
            {
                SetButtonColor(
                    pair.Value,
                    pair.Key == id ? new Color32(102, 73, 33, 255) : PanelSoft);
            }

            RenderCurrentScreen();
        }

        private void RenderCurrentScreen()
        {
            ClearChildren(content);
            screenTitle = null;
            activeJob = null;
            activeJobDescription = null;
            activeJobProgress = null;
            selectedBuildingText = null;
            selectedBuildingButton = null;

            switch (currentScreen)
            {
                case ScreenId.City:
                    RenderCity();
                    break;
                case ScreenId.Army:
                    RenderArmy();
                    break;
                case ScreenId.Heroes:
                    RenderHeroes();
                    break;
                case ScreenId.Map:
                    RenderMap();
                    break;
            }

            LayoutRebuilder.ForceRebuildLayoutImmediate(content);
            renderedScreenRevision = ComputeScreenRevision();
        }

        private void RenderCity()
        {
            AddHeroCard(
                "PAYİTAHT · SABAH NÖBETİ",
                "Şehrini Büyüt",
                "Dokunulabilir başkentini yönet; üretimi büyüt, saray sınırını yükselt ve ordunu hazırla.",
                Gold);

            AddCityWorldCard();
            AddSectionTitle("BAŞKENT YAPILARI", "Her yükseltme üretimi ve devlet gücünü artırır.");
            AddJobCard(game.State.construction, "İNŞA KUYRUĞU", "Ustalar yeni emri bekliyor.");

            foreach (var spec in GameRules.Buildings)
            {
                var building = game.State.GetBuilding(spec.id);
                var cost = GameRules.UpgradeCost(spec, building.level);
                var canUpgrade = game.State.CanUpgradeBuilding(spec.id);
                var production = GameRules.ProductionPerMinute(spec.id, building.level);
                var productionText = production > 0d
                    ? $" · {production:N0}/dk üretim"
                    : string.Empty;
                AddActionCard(
                    spec.icon,
                    spec.title,
                    $"Seviye {building.level}{productionText} · {spec.description}",
                    $"{CostText(cost)} · {game.State.BuildingUpgradeStatus(spec.id)}",
                    "GELİŞTİR",
                    canUpgrade,
                    () =>
                    {
                        game.UpgradeBuilding(spec.id);
                        RenderCurrentScreen();
                    });
            }
        }

        private void RenderArmy()
        {
            AddHeroCard(
                "ORDUGÂH · SEFER HAZIRLIĞI",
                "Sancakları Doldur",
                "Dört birlik sınıfını dengeli eğit; her sınıf savaş alanında farklı bir rol üstlenir.",
                Teal);

            AddSectionTitle(
                "EĞİTİM VE BİRLİKLER",
                $"Toplam güç {game.State.Power:N0} · Yaralı {game.State.wounded:N0}");
            AddJobCard(game.State.training, "EĞİTİM KUYRUĞU", "Kışla yeni birlik emrini bekliyor.");

            foreach (var spec in GameRules.Units)
            {
                var unit = game.State.GetUnit(spec.id);
                var barracksLevel = game.State.GetBuilding("barracks").level;
                var batch = GameRules.TrainingBatch(spec, barracksLevel);
                var duration = GameRules.TrainingDuration(spec, barracksLevel);
                var canTrain = game.State.CanTrainUnit(spec.id);
                AddActionCard(
                    spec.icon,
                    spec.title,
                    $"{unit.count:N0} asker · Kışla {spec.requiredBarracksLevel} gerekir · {spec.description}",
                    $"{CostText(spec.cost)} · +{batch} · {duration} sn · {game.State.UnitTrainingStatus(spec.id)}",
                    barracksLevel >= spec.requiredBarracksLevel ? "EĞİT" : "KİLİTLİ",
                    canTrain,
                    () =>
                    {
                        game.TrainUnit(spec.id);
                        RenderCurrentScreen();
                    });
            }
        }

        private void RenderHeroes()
        {
            var assignedCount = game.State.heroes.Count(item => item.assigned);
            AddHeroCard(
                "DİVAN · KOMUTANLAR",
                "Sefer Meclisi",
                "İki kahramanı orduya ata; yeteneklerini geliştir ve savaş düzenini değiştir.",
                Gold);

            AddSectionTitle(
                "KOMUTAN KADROSU",
                $"{assignedCount}/2 kahraman sefer ordusunda · Her yetenek 700 altın");

            foreach (var spec in GameRules.Heroes)
            {
                AddHeroManagementCard(spec, game.State.GetHero(spec.id));
            }
        }

        private void RenderMap()
        {
            AddHeroCard(
                "BATI EYALETİ · DÜNYA HARİTASI",
                "Karacahisar Seferi",
                "Birlikleri canlı savaş alanına sür, takviyeleri yönet ve sınır kalesini ele geçir.",
                Crimson);

            AddSectionTitle(
                "SEFER DURUMU",
                $"{game.State.victories} zafer · {game.State.seasonPoints:N0} sezon şöhreti");

            var assignedHeroes = string.Join(
                " + ",
                game.State.heroes
                    .Where(item => item.assigned)
                    .Select(item =>
                        GameRules.Heroes.First(spec => spec.id == item.id).name));
            AddActionCard(
                "♜",
                "Canlı Karacahisar Kuşatması",
                "Piyade, okçu, süvari ve Şahi topları sahada yürür; hedef seçer ve saldırır.",
                $"Komutanlar: {assignedHeroes} · Takviye emirleri açık",
                "SAVAŞA GİR",
                game.State.units.Sum(item => item.count) >= 40,
                () => CihanBattleView.Show(
                    game,
                    () =>
                    {
                        RefreshHeader();
                        RenderCurrentScreen();
                    }));

            AddJobCard(
                game.State.expedition,
                "YÜRÜYÜŞ SIRASI",
                "Ordu Karacahisar seferi için hazır.");

            var expeditionAvailable =
                game.State.expedition == null && game.State.food >= 400;
            AddActionCard(
                "⚔",
                "Karacahisar Kalesi",
                "Önerilen güç 8.500 · Tahmini süre 12 saniye · Demo seferi",
                "400 Erzak · 2.400 Erzak + 700 Taş + 900 Altın",
                "SEFERE ÇIK",
                expeditionAvailable,
                () =>
                {
                    game.BeginExpedition();
                    RenderCurrentScreen();
                });

            AddActionCard(
                "◆",
                "Demir Madeni",
                "Kaynak bölgesi · Bir sonraki geliştirme aşamasında açılacak.",
                "1.100 Taş · 350 Altın",
                "KİLİTLİ",
                false,
                null);

            AddActionCard(
                "⚑",
                "Ak Sancak Hisarı",
                "İttifak merkezi · Canlı sunucu aşamasında açılacak.",
                "İttifak takviyesi",
                "KİLİTLİ",
                false,
                null);
        }

        private void AddCityWorldCard()
        {
            var card = CreatePanel(content, "Yaşayan 3B Başkent", Panel);
            var element = card.gameObject.AddComponent<LayoutElement>();
            element.preferredHeight = 660f;

            var cityImageObject = new GameObject(
                "Dokunulabilir Başkent Görünümü",
                typeof(RectTransform),
                typeof(RawImage));
            cityImageObject.transform.SetParent(card.transform, false);
            var cityImage = cityImageObject.GetComponent<RawImage>();
            cityImage.color = Color.white;
            cityImage.raycastTarget = true;
            SetAnchoredRect(
                cityImage.rectTransform,
                new Vector2(0.015f, 0.18f),
                new Vector2(0.985f, 0.985f),
                Vector2.zero,
                Vector2.zero);

            var instruction = CreateText(
                card.transform,
                "BİNAYA DOKUN · SÜRÜKLEYEREK DÖNDÜR · İKİ PARMAKLA YAKINLAŞTIR",
                18,
                GoldBright,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            instruction.resizeTextForBestFit = true;
            instruction.resizeTextMinSize = 12;
            SetAnchoredRect(
                instruction.rectTransform,
                new Vector2(0.04f, 0.88f),
                new Vector2(0.96f, 0.97f),
                Vector2.zero,
                Vector2.zero);

            selectedBuildingText = CreateText(
                card.transform,
                "Yapı seçiliyor…",
                20,
                Ivory,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            selectedBuildingText.resizeTextForBestFit = true;
            selectedBuildingText.resizeTextMinSize = 13;
            selectedBuildingText.resizeTextMaxSize = 20;
            SetAnchoredRect(
                selectedBuildingText.rectTransform,
                new Vector2(0.035f, 0.025f),
                new Vector2(0.68f, 0.17f),
                Vector2.zero,
                Vector2.zero);

            selectedBuildingButton = CreateButton(
                card.transform,
                "GELİŞTİR",
                () =>
                {
                    game.UpgradeBuilding(selectedCityBuildingId);
                    RenderCurrentScreen();
                },
                new Color32(133, 91, 36, 255),
                18);
            SetAnchoredRect(
                selectedBuildingButton.GetComponent<RectTransform>(),
                new Vector2(0.71f, 0.035f),
                new Vector2(0.965f, 0.155f),
                Vector2.zero,
                Vector2.zero);

            var world = cityImageObject.AddComponent<CihanCityWorld3D>();
            world.Configure(
                game,
                buildingId =>
                {
                    selectedCityBuildingId = buildingId;
                    UpdateSelectedBuildingPanel();
                });
            world.SelectBuilding(selectedCityBuildingId, true);
        }

        private void UpdateSelectedBuildingPanel()
        {
            if (selectedBuildingText == null || selectedBuildingButton == null)
            {
                return;
            }

            var spec = GameRules.Buildings.First(item => item.id == selectedCityBuildingId);
            var building = game.State.GetBuilding(selectedCityBuildingId);
            var production = GameRules.ProductionPerMinute(spec.id, building.level);
            var productionText = production > 0d
                ? $" · {production:N0}/dk"
                : string.Empty;
            selectedBuildingText.text =
                $"{spec.title} · SV {building.level}{productionText}\n" +
                game.State.BuildingUpgradeStatus(spec.id);

            var canUpgrade = game.State.CanUpgradeBuilding(spec.id);
            selectedBuildingButton.interactable = canUpgrade;
            var buttonText = selectedBuildingButton.GetComponentInChildren<Text>();
            if (buttonText != null)
            {
                buttonText.text = building.level >= GameRules.MaximumBuildingLevel
                    ? "TAMAMLANDI"
                    : "GELİŞTİR";
            }

            SetButtonColor(
                selectedBuildingButton,
                canUpgrade
                    ? new Color32(133, 91, 36, 255)
                    : new Color32(55, 58, 60, 255));
        }

        private void AddHeroManagementCard(HeroSpec spec, HeroState hero)
        {
            var card = CreatePanel(content, $"{spec.name} Komutan Kartı", Panel);
            var element = card.gameObject.AddComponent<LayoutElement>();
            element.preferredHeight = 310f;

            var color = hero.assigned ? Teal : new Color32(75, 79, 82, 255);
            var portrait = CreatePanel(card.transform, "Komutan Mührü", color);
            SetAnchoredRect(
                portrait.rectTransform,
                new Vector2(0.03f, 0.33f),
                new Vector2(0.23f, 0.94f),
                Vector2.zero,
                Vector2.zero);

            var icon = CreateText(
                portrait.transform,
                spec.icon,
                62,
                Ivory,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            Stretch(icon.rectTransform, 8f, 8f, 8f, 8f);

            var name = CreateText(
                card.transform,
                $"{spec.name} · {spec.title}",
                30,
                Ivory,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            SetAnchoredRect(
                name.rectTransform,
                new Vector2(0.27f, 0.72f),
                new Vector2(0.97f, 0.96f),
                Vector2.zero,
                Vector2.zero);

            var level = CreateText(
                card.transform,
                $"Seviye {hero.level} · Yetenek {hero.skillLevel}/5\n" +
                $"{spec.bonus}\n" +
                (hero.assigned ? "SEFER ORDUSUNDA" : "BAŞKENT GÖREVİNDE"),
                21,
                hero.assigned ? GoldBright : Muted,
                TextAnchor.UpperLeft,
                FontStyle.Normal);
            SetAnchoredRect(
                level.rectTransform,
                new Vector2(0.27f, 0.31f),
                new Vector2(0.97f, 0.73f),
                Vector2.zero,
                Vector2.zero);

            var assign = CreateButton(
                card.transform,
                hero.assigned ? "ORDUDAN ÇIKAR" : "ORDUYA ATA",
                () =>
                {
                    game.ToggleHero(spec.id);
                    RenderCurrentScreen();
                },
                hero.assigned
                    ? new Color32(55, 83, 79, 255)
                    : new Color32(92, 68, 38, 255),
                18);
            SetAnchoredRect(
                assign.GetComponent<RectTransform>(),
                new Vector2(0.03f, 0.04f),
                new Vector2(0.48f, 0.27f),
                Vector2.zero,
                Vector2.zero);

            var canUpgrade = hero.skillLevel < 5 && game.State.gold >= 700;
            var upgrade = CreateButton(
                card.transform,
                hero.skillLevel >= 5 ? "USTALIK TAMAM" : "YETENEĞİ GELİŞTİR",
                () =>
                {
                    game.UpgradeHero(spec.id);
                    RenderCurrentScreen();
                },
                canUpgrade
                    ? new Color32(133, 91, 36, 255)
                    : new Color32(55, 58, 60, 255),
                18);
            upgrade.interactable = canUpgrade;
            SetAnchoredRect(
                upgrade.GetComponent<RectTransform>(),
                new Vector2(0.51f, 0.04f),
                new Vector2(0.97f, 0.27f),
                Vector2.zero,
                Vector2.zero);
        }

        private void AddHeroCard(
            string kicker,
            string title,
            string description,
            Color accent)
        {
            var card = CreatePanel(content, $"{title} Kartı", Panel);
            var element = card.gameObject.AddComponent<LayoutElement>();
            element.preferredHeight = 330f;

            var accentBar = CreatePanel(card.transform, "Vurgu", accent);
            SetAnchoredRect(
                accentBar.rectTransform,
                new Vector2(0f, 0f),
                new Vector2(0f, 1f),
                new Vector2(12f, 0f),
                new Vector2(6f, 0f));

            var kickerText = CreateText(
                card.transform,
                kicker,
                20,
                Gold,
                TextAnchor.UpperLeft,
                FontStyle.Bold);
            SetAnchoredRect(
                kickerText.rectTransform,
                new Vector2(0f, 0.72f),
                new Vector2(1f, 1f),
                new Vector2(-52f, -18f),
                new Vector2(38f, -42f));

            var titleText = CreateText(
                card.transform,
                title,
                46,
                Ivory,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            SetAnchoredRect(
                titleText.rectTransform,
                new Vector2(0f, 0.35f),
                new Vector2(1f, 0.78f),
                new Vector2(-52f, -10f),
                new Vector2(38f, 6f));

            var descriptionText = CreateText(
                card.transform,
                description,
                25,
                Muted,
                TextAnchor.UpperLeft,
                FontStyle.Normal);
            SetAnchoredRect(
                descriptionText.rectTransform,
                new Vector2(0f, 0f),
                new Vector2(1f, 0.38f),
                new Vector2(-52f, -18f),
                new Vector2(38f, -5f));
        }

        private void AddSectionTitle(string title, string subtitle)
        {
            var container = new GameObject($"{title} Başlığı", typeof(RectTransform));
            container.transform.SetParent(content, false);
            var element = container.AddComponent<LayoutElement>();
            element.preferredHeight = 120f;

            screenTitle = CreateText(
                container.transform,
                title,
                27,
                Gold,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            SetAnchoredRect(
                screenTitle.rectTransform,
                new Vector2(0f, 0.45f),
                new Vector2(1f, 1f),
                Vector2.zero,
                Vector2.zero);

            var subtitleText = CreateText(
                container.transform,
                subtitle,
                20,
                Muted,
                TextAnchor.MiddleLeft,
                FontStyle.Normal);
            SetAnchoredRect(
                subtitleText.rectTransform,
                new Vector2(0f, 0f),
                new Vector2(1f, 0.48f),
                Vector2.zero,
                Vector2.zero);
        }

        private void AddJobCard(TimedJob job, string title, string emptyDescription)
        {
            var card = CreatePanel(content, title, new Color32(18, 28, 36, 255));
            var element = card.gameObject.AddComponent<LayoutElement>();
            element.preferredHeight = 178f;

            var titleText = CreateText(
                card.transform,
                title,
                22,
                Gold,
                TextAnchor.UpperLeft,
                FontStyle.Bold);
            SetAnchoredRect(
                titleText.rectTransform,
                new Vector2(0f, 0.58f),
                new Vector2(1f, 1f),
                new Vector2(-42f, -12f),
                new Vector2(28f, -24f));

            var description = job == null
                ? emptyDescription
                : $"{JobTitle(job)} · {job.SecondsLeft(GameService.Now):00} sn kaldı";
            var descriptionText = CreateText(
                card.transform,
                description,
                23,
                Ivory,
                TextAnchor.MiddleLeft,
                FontStyle.Normal);
            SetAnchoredRect(
                descriptionText.rectTransform,
                new Vector2(0f, 0.18f),
                new Vector2(1f, 0.66f),
                new Vector2(-42f, -5f),
                new Vector2(28f, -4f));
            activeJob = job;
            activeJobDescription = descriptionText;

            var track = CreatePanel(card.transform, "İlerleme Zemini", new Color32(42, 49, 54, 255));
            SetAnchoredRect(
                track.rectTransform,
                new Vector2(0f, 0f),
                new Vector2(1f, 0f),
                new Vector2(-32f, 12f),
                new Vector2(28f, 36f));

            var progress = CreatePanel(track.transform, "İlerleme", Gold);
            var amount = job?.Progress(GameService.Now) ?? 0f;
            progress.rectTransform.anchorMin = Vector2.zero;
            progress.rectTransform.anchorMax = new Vector2(amount, 1f);
            progress.rectTransform.offsetMin = Vector2.zero;
            progress.rectTransform.offsetMax = Vector2.zero;
            activeJobProgress = progress.rectTransform;
        }

        private void AddActionCard(
            string icon,
            string title,
            string description,
            string cost,
            string buttonLabel,
            bool interactable,
            UnityEngine.Events.UnityAction action)
        {
            var card = CreatePanel(content, $"{title} Kartı", Panel);
            var element = card.gameObject.AddComponent<LayoutElement>();
            element.preferredHeight = 255f;

            var iconText = CreateText(
                card.transform,
                icon,
                48,
                GoldBright,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            SetAnchoredRect(
                iconText.rectTransform,
                new Vector2(0f, 0.43f),
                new Vector2(0.18f, 1f),
                Vector2.zero,
                new Vector2(15f, -12f));

            var titleText = CreateText(
                card.transform,
                title,
                30,
                Ivory,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            SetAnchoredRect(
                titleText.rectTransform,
                new Vector2(0.18f, 0.65f),
                new Vector2(1f, 1f),
                new Vector2(-32f, -8f),
                new Vector2(12f, -14f));

            var descriptionText = CreateText(
                card.transform,
                description,
                21,
                Muted,
                TextAnchor.UpperLeft,
                FontStyle.Normal);
            SetAnchoredRect(
                descriptionText.rectTransform,
                new Vector2(0.18f, 0.27f),
                new Vector2(1f, 0.68f),
                new Vector2(-32f, -6f),
                new Vector2(12f, -8f));

            var costText = CreateText(
                card.transform,
                cost,
                18,
                GoldBright,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            costText.resizeTextForBestFit = true;
            costText.resizeTextMinSize = 13;
            costText.resizeTextMaxSize = 18;
            SetAnchoredRect(
                costText.rectTransform,
                new Vector2(0.03f, 0f),
                new Vector2(0.66f, 0.28f),
                new Vector2(-18f, -8f),
                new Vector2(18f, 3f));

            var button = CreateButton(
                card.transform,
                buttonLabel,
                action,
                interactable ? new Color32(133, 91, 36, 255) : new Color32(55, 58, 60, 255),
                20);
            button.interactable = interactable;
            SetAnchoredRect(
                button.GetComponent<RectTransform>(),
                new Vector2(0.68f, 0f),
                new Vector2(1f, 0.28f),
                new Vector2(-22f, -8f),
                new Vector2(8f, 3f));
        }

        private void HandleChanged()
        {
            RefreshHeader();
            if (ComputeScreenRevision() != renderedScreenRevision)
            {
                RenderCurrentScreen();
            }
        }

        private int ComputeScreenRevision()
        {
            if (game?.State == null)
            {
                return 0;
            }

            unchecked
            {
                var state = game.State;
                var hash = 17 * 31 + (int)currentScreen;
                switch (currentScreen)
                {
                    case ScreenId.City:
                        foreach (var building in state.buildings)
                        {
                            hash = hash * 31 + building.id.GetHashCode();
                            hash = hash * 31 + building.level;
                            hash = hash * 31 +
                                   (state.CanUpgradeBuilding(building.id) ? 1 : 0);
                        }

                        hash = AddJobRevision(hash, state.construction);
                        break;
                    case ScreenId.Army:
                        foreach (var unit in state.units)
                        {
                            hash = hash * 31 + unit.id.GetHashCode();
                            hash = hash * 31 + unit.count;
                            hash = hash * 31 +
                                   (state.CanTrainUnit(unit.id) ? 1 : 0);
                        }

                        hash = hash * 31 + state.GetBuilding("barracks").level;
                        hash = hash * 31 + state.wounded;
                        hash = AddJobRevision(hash, state.training);
                        break;
                    case ScreenId.Heroes:
                        foreach (var hero in state.heroes)
                        {
                            hash = hash * 31 + hero.id.GetHashCode();
                            hash = hash * 31 + hero.level;
                            hash = hash * 31 + hero.skillLevel;
                            hash = hash * 31 + (hero.assigned ? 1 : 0);
                        }

                        hash = hash * 31 + (state.gold >= 700 ? 1 : 0);
                        break;
                    case ScreenId.Map:
                        hash = hash * 31 + state.victories;
                        hash = hash * 31 + state.seasonPoints;
                        hash = hash * 31 + state.units.Sum(item => item.count);
                        foreach (var hero in state.heroes)
                        {
                            hash = hash * 31 + (hero.assigned ? 1 : 0);
                        }

                        hash = AddJobRevision(hash, state.expedition);
                        break;
                }

                return hash;
            }
        }

        private static int AddJobRevision(int hash, TimedJob job)
        {
            unchecked
            {
                if (job == null)
                {
                    return hash * 31;
                }

                hash = hash * 31 + job.kind.GetHashCode();
                hash = hash * 31 + job.targetId.GetHashCode();
                hash = hash * 31 + job.quantity;
                hash = hash * 31 + job.endsAt.GetHashCode();
                return hash;
            }
        }

        private void RefreshHeader()
        {
            var state = game.State;
            resourceTexts[ResourceType.Food].text = $"ERZAK\n{state.food:N0}";
            resourceTexts[ResourceType.Wood].text = $"KERES.\n{state.wood:N0}";
            resourceTexts[ResourceType.Stone].text = $"TAŞ\n{state.stone:N0}";
            resourceTexts[ResourceType.Gold].text = $"ALTIN\n{state.gold:N0}";
            powerText.text = $"DEVLET GÜCÜ\n{state.Power:N0}";
            eventText.text = state.lastEvent;
        }

        private string JobTitle(TimedJob job)
        {
            return job.kind switch
            {
                "construction" => GameRules.Buildings.First(item => item.id == job.targetId).title,
                "training" => GameRules.Units.First(item => item.id == job.targetId).title,
                "expedition" => "Karacahisar yürüyüşü",
                _ => "Devam eden emir"
            };
        }

        private static string CostText(ResourceCost cost)
        {
            var parts = new List<string>();
            if (cost.food > 0) parts.Add($"{cost.food:N0} Erzak");
            if (cost.wood > 0) parts.Add($"{cost.wood:N0} Kereste");
            if (cost.stone > 0) parts.Add($"{cost.stone:N0} Taş");
            if (cost.gold > 0) parts.Add($"{cost.gold:N0} Altın");
            return string.Join(" · ", parts);
        }

        private Image CreatePanel(Transform parent, string name, Color color)
        {
            var panel = new GameObject(name, typeof(RectTransform), typeof(Image));
            panel.transform.SetParent(parent, false);
            var image = panel.GetComponent<Image>();
            image.color = color;
            image.raycastTarget = false;
            return image;
        }

        private Text CreateText(
            Transform parent,
            string value,
            int size,
            Color color,
            TextAnchor alignment,
            FontStyle style)
        {
            var textObject = new GameObject("Metin", typeof(RectTransform), typeof(Text));
            textObject.transform.SetParent(parent, false);
            var text = textObject.GetComponent<Text>();
            text.font = font;
            text.text = value;
            text.fontSize = size;
            text.color = color;
            text.alignment = alignment;
            text.fontStyle = style;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Truncate;
            text.raycastTarget = false;
            return text;
        }

        private Button CreateButton(
            Transform parent,
            string label,
            UnityEngine.Events.UnityAction action,
            Color color,
            int fontSize)
        {
            var buttonObject = new GameObject(
                $"{label} Düğmesi",
                typeof(RectTransform),
                typeof(Image),
                typeof(Button));
            buttonObject.transform.SetParent(parent, false);

            var image = buttonObject.GetComponent<Image>();
            image.color = color;
            var button = buttonObject.GetComponent<Button>();
            button.targetGraphic = image;
            if (action != null)
            {
                button.onClick.AddListener(action);
            }

            var text = CreateText(
                buttonObject.transform,
                label,
                fontSize,
                Ivory,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            Stretch(text.rectTransform, 8f, 8f, 5f, 5f);
            SetButtonColor(button, color);
            return button;
        }

        private static void SetButtonColor(Button button, Color normal)
        {
            var colors = button.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = new Color(1.08f, 1.08f, 1.08f, 1f);
            colors.pressedColor = new Color(0.82f, 0.82f, 0.82f, 1f);
            colors.selectedColor = colors.highlightedColor;
            colors.disabledColor = new Color(0.55f, 0.55f, 0.55f, 0.75f);
            colors.colorMultiplier = 1f;
            colors.fadeDuration = 0.12f;
            button.colors = colors;
            if (button.targetGraphic is Image image)
            {
                image.color = normal;
            }
        }

        private static void ClearChildren(Transform parent)
        {
            for (var index = parent.childCount - 1; index >= 0; index--)
            {
                var child = parent.GetChild(index);
                child.SetParent(null, false);
                Destroy(child.gameObject);
            }
        }

        private static void Stretch(
            RectTransform rect,
            float left = 0f,
            float right = 0f,
            float top = 0f,
            float bottom = 0f)
        {
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = new Vector2(left, bottom);
            rect.offsetMax = new Vector2(-right, -top);
        }

        private static void SetAnchoredRect(
            RectTransform rect,
            Vector2 anchorMin,
            Vector2 anchorMax,
            Vector2 sizeDelta,
            Vector2 anchoredPosition)
        {
            rect.anchorMin = anchorMin;
            rect.anchorMax = anchorMax;
            rect.sizeDelta = sizeDelta;
            rect.anchoredPosition = anchoredPosition;
        }
    }
}
