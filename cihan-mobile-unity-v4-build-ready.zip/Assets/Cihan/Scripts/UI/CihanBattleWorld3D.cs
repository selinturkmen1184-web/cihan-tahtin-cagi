using System;
using System.Collections.Generic;
using Cihan.Battle;
using UnityEngine;
using UnityEngine.Rendering;

namespace Cihan.UI
{
    public sealed class CihanBattleWorld3D : MonoBehaviour
    {
        private sealed class Actor
        {
            public GameObject root;
            public Transform model;
            public Transform[] weapons;
            public Quaternion[] weaponRestRotations;
            public Vector3 lastWorldPosition;
            public float lastAttackTimer;
            public float phase;
            public bool fallen;
        }

        private sealed class TimedEffect
        {
            public GameObject root;
            public Vector3 velocity;
            public float life;
            public float duration;
        }

        private readonly Dictionary<int, Actor> actors = new();
        private readonly List<TimedEffect> effects = new();
        private readonly List<Material> materials = new();

        private BattleSimulation simulation;
        private GameObject worldRoot;
        private Camera battleCamera;
        private Vector3 cameraTarget = new(0.5f, 0.3f, 0.4f);
        private readonly Vector3 cameraOffset = new(-1.7f, 15.5f, -17.2f);
        private Material friendlyArmor;
        private Material friendlyCloth;
        private Material enemyArmor;
        private Material enemyCloth;
        private Material gold;
        private Material iron;
        private Material leather;
        private Material skin;
        private Material wood;
        private Material stone;
        private Material ground;
        private Material healthFlash;

        public void Initialize(BattleSimulation value, RenderTexture target)
        {
            simulation = value;
            worldRoot = new GameObject("CİHAN 3B Kuşatma Dünyası");
            BuildMaterials();
            BuildLighting(target);
            BuildEnvironment();
            Sync();
        }

        private void Update()
        {
            HandleCameraGesture();
        }

        public void Sync()
        {
            if (simulation == null || worldRoot == null)
            {
                return;
            }

            foreach (var unit in simulation.Units)
            {
                if (!actors.TryGetValue(unit.id, out var actor))
                {
                    actor = CreateActor(unit);
                    actors[unit.id] = actor;
                }

                UpdateActor(actor, unit);
            }

            UpdateEffects(Time.unscaledDeltaTime);
        }

        public bool TryGetViewportPosition(int unitId, out Vector2 position)
        {
            position = Vector2.zero;
            if (battleCamera == null || !actors.TryGetValue(unitId, out var actor))
            {
                return false;
            }

            var point = battleCamera.WorldToViewportPoint(
                actor.root.transform.position + Vector3.up * 1.65f);
            if (point.z <= 0f)
            {
                return false;
            }

            position = new Vector2(
                Mathf.Clamp01(point.x),
                Mathf.Clamp01(point.y));
            return true;
        }

        private void BuildMaterials()
        {
            friendlyArmor = CreateMaterial(
                new Color32(38, 126, 116, 255),
                0.55f,
                0.38f);
            friendlyCloth = CreateMaterial(
                new Color32(23, 66, 67, 255),
                0.05f,
                0.2f);
            enemyArmor = CreateMaterial(
                new Color32(145, 52, 45, 255),
                0.5f,
                0.32f);
            enemyCloth = CreateMaterial(
                new Color32(73, 26, 28, 255),
                0.04f,
                0.18f);
            gold = CreateMaterial(new Color32(217, 170, 75, 255), 0.72f, 0.55f);
            iron = CreateMaterial(new Color32(103, 111, 114, 255), 0.82f, 0.5f);
            leather = CreateMaterial(new Color32(77, 48, 30, 255), 0.03f, 0.16f);
            skin = CreateMaterial(new Color32(180, 127, 91, 255), 0.02f, 0.2f);
            wood = CreateMaterial(new Color32(82, 54, 31, 255), 0.02f, 0.12f);
            stone = CreateMaterial(new Color32(107, 101, 87, 255), 0.02f, 0.16f);
            ground = CreateMaterial(new Color32(95, 86, 56, 255), 0.01f, 0.08f);
            healthFlash = CreateMaterial(
                new Color32(255, 207, 100, 255),
                0.25f,
                0.65f);
        }

        private void BuildLighting(RenderTexture target)
        {
            var cameraObject = new GameObject("İzometrik Savaş Kamerası");
            cameraObject.transform.SetParent(worldRoot.transform, false);
            battleCamera = cameraObject.AddComponent<Camera>();
            battleCamera.targetTexture = target;
            battleCamera.clearFlags = CameraClearFlags.SolidColor;
            battleCamera.backgroundColor = new Color32(71, 72, 62, 255);
            battleCamera.fieldOfView = 40f;
            battleCamera.nearClipPlane = 0.15f;
            battleCamera.farClipPlane = 80f;
            battleCamera.allowHDR = false;
            battleCamera.allowMSAA = true;
            ApplyCameraTransform();

            var sunObject = new GameObject("Akşam Güneşi");
            sunObject.transform.SetParent(worldRoot.transform, false);
            var sun = sunObject.AddComponent<Light>();
            sun.type = LightType.Directional;
            sun.color = new Color32(255, 216, 159, 255);
            sun.intensity = 1.3f;
            sun.shadows = LightShadows.Soft;
            sun.shadowStrength = 0.78f;
            sun.cullingMask &= ~(1 << 30);
            sunObject.transform.rotation = Quaternion.Euler(43f, -38f, 0f);

            var fillObject = new GameObject("Soğuk Dolgu Işığı");
            fillObject.transform.SetParent(worldRoot.transform, false);
            var fill = fillObject.AddComponent<Light>();
            fill.type = LightType.Directional;
            fill.color = new Color32(112, 151, 171, 255);
            fill.intensity = 0.42f;
            fill.shadows = LightShadows.None;
            fill.cullingMask &= ~(1 << 30);
            fillObject.transform.rotation = Quaternion.Euler(58f, 132f, 0f);

            RenderSettings.ambientMode = AmbientMode.Trilight;
            RenderSettings.ambientSkyColor = new Color32(117, 120, 109, 255);
            RenderSettings.ambientEquatorColor = new Color32(81, 80, 68, 255);
            RenderSettings.ambientGroundColor = new Color32(43, 40, 31, 255);
        }

        private void HandleCameraGesture()
        {
            if (battleCamera == null)
            {
                return;
            }

            if (Input.touchCount == 1)
            {
                var touch = Input.GetTouch(0);
                var normalizedY = touch.position.y / Mathf.Max(1f, Screen.height);
                if (touch.phase == TouchPhase.Moved &&
                    normalizedY > 0.17f &&
                    normalizedY < 0.87f)
                {
                    cameraTarget.x = Mathf.Clamp(
                        cameraTarget.x - touch.deltaPosition.x * 0.006f,
                        -2.2f,
                        2.2f);
                    cameraTarget.z = Mathf.Clamp(
                        cameraTarget.z - touch.deltaPosition.y * 0.006f,
                        -2.1f,
                        2.1f);
                    ApplyCameraTransform();
                }
            }
            else if (Input.touchCount == 2)
            {
                var first = Input.GetTouch(0);
                var second = Input.GetTouch(1);
                var previousFirst = first.position - first.deltaPosition;
                var previousSecond = second.position - second.deltaPosition;
                var previousDistance = Vector2.Distance(previousFirst, previousSecond);
                var currentDistance = Vector2.Distance(first.position, second.position);
                battleCamera.fieldOfView = Mathf.Clamp(
                    battleCamera.fieldOfView -
                    (currentDistance - previousDistance) * 0.018f,
                    31f,
                    52f);
            }

            var wheel = Input.mouseScrollDelta.y;
            if (Mathf.Abs(wheel) > 0.01f)
            {
                battleCamera.fieldOfView = Mathf.Clamp(
                    battleCamera.fieldOfView - wheel * 2f,
                    31f,
                    52f);
            }
        }

        private void ApplyCameraTransform()
        {
            battleCamera.transform.position = cameraTarget + cameraOffset;
            battleCamera.transform.LookAt(cameraTarget);
        }

        private void BuildEnvironment()
        {
            var terrain = Primitive(
                "Kurumuş Savaş Ovası",
                PrimitiveType.Cube,
                worldRoot.transform,
                new Vector3(0f, -0.32f, 0f),
                new Vector3(21f, 0.55f, 13.5f),
                ground);
            terrain.transform.rotation = Quaternion.Euler(0f, -2f, 0f);

            for (var index = 0; index < 18; index += 1)
            {
                var z = -5.4f + index * 0.63f;
                var trench = Primitive(
                    $"Savunma Kazığı {index + 1}",
                    PrimitiveType.Cube,
                    worldRoot.transform,
                    new Vector3(5.55f + Mathf.Sin(index) * 0.12f, 0.06f, z),
                    new Vector3(0.1f, 0.48f, 0.1f),
                    wood);
                trench.transform.rotation = Quaternion.Euler(
                    index % 2 == 0 ? 18f : -18f,
                    0f,
                    index % 2 == 0 ? 21f : -21f);
            }

            BuildFortress();
            BuildCamp();
            BuildRocks();
        }

        private void BuildFortress()
        {
            var fortress = new GameObject("Karacahisar Kalesi");
            fortress.transform.SetParent(worldRoot.transform, false);
            fortress.transform.position = new Vector3(8.55f, 0f, 0.4f);

            Primitive(
                "Ana Sur",
                PrimitiveType.Cube,
                fortress.transform,
                new Vector3(0f, 1.15f, 0f),
                new Vector3(0.72f, 2.8f, 10.8f),
                stone);

            for (var z = -4.8f; z <= 4.8f; z += 1.2f)
            {
                Primitive(
                    "Sur Mazgalı",
                    PrimitiveType.Cube,
                    fortress.transform,
                    new Vector3(-0.02f, 2.82f, z),
                    new Vector3(0.88f, 0.42f, 0.52f),
                    stone);
            }

            BuildTower(fortress.transform, -4.95f, 1.25f);
            BuildTower(fortress.transform, 4.95f, 1.25f);
            BuildTower(fortress.transform, 0f, 1.55f);

            Primitive(
                "Kale Kapısı",
                PrimitiveType.Cube,
                fortress.transform,
                new Vector3(-0.42f, 0.72f, 0f),
                new Vector3(0.18f, 1.55f, 1.35f),
                wood);

            var flagPole = Primitive(
                "Hisar Sancağı Direği",
                PrimitiveType.Cylinder,
                fortress.transform,
                new Vector3(0f, 4.7f, 0f),
                new Vector3(0.07f, 1.5f, 0.07f),
                iron);
            flagPole.transform.rotation = Quaternion.identity;
            Primitive(
                "Hisar Sancağı",
                PrimitiveType.Cube,
                fortress.transform,
                new Vector3(-0.38f, 5.18f, 0f),
                new Vector3(0.75f, 0.52f, 0.06f),
                enemyArmor);
        }

        private void BuildTower(Transform parent, float z, float extraHeight)
        {
            Primitive(
                "Sur Kulesi",
                PrimitiveType.Cylinder,
                parent,
                new Vector3(-0.02f, 1.35f + extraHeight * 0.25f, z),
                new Vector3(1.45f, 1.4f + extraHeight * 0.22f, 1.45f),
                stone,
                8);
            Primitive(
                "Kule Tacı",
                PrimitiveType.Cylinder,
                parent,
                new Vector3(-0.02f, 3.04f + extraHeight * 0.25f, z),
                new Vector3(1.65f, 0.25f, 1.65f),
                stone,
                8);
        }

        private void BuildCamp()
        {
            var camp = new GameObject("CİHAN Sefer Kampı");
            camp.transform.SetParent(worldRoot.transform, false);
            camp.transform.position = new Vector3(-8.3f, 0f, -0.4f);

            for (var index = 0; index < 3; index += 1)
            {
                var tent = Primitive(
                    $"Sefer Çadırı {index + 1}",
                    PrimitiveType.Cylinder,
                    camp.transform,
                    new Vector3(0f, 0.58f, -3.1f + index * 3.1f),
                    new Vector3(1.2f, 0.7f, 1.2f),
                    friendlyCloth,
                    4);
                tent.transform.rotation = Quaternion.Euler(0f, 45f, 0f);
            }

            Primitive(
                "Ordu Sancağı Direği",
                PrimitiveType.Cylinder,
                camp.transform,
                new Vector3(0.3f, 1.65f, 0f),
                new Vector3(0.05f, 1.65f, 0.05f),
                wood);
            Primitive(
                "Ordu Sancağı",
                PrimitiveType.Cube,
                camp.transform,
                new Vector3(0.7f, 2.55f, 0f),
                new Vector3(0.82f, 0.58f, 0.06f),
                friendlyArmor);
        }

        private void BuildRocks()
        {
            for (var index = 0; index < 24; index += 1)
            {
                var angle = index * 1.91f;
                var x = Mathf.Lerp(-7.6f, 7.1f, Mathf.Repeat(index * 0.37f, 1f));
                var z = index % 2 == 0 ? -5.5f : 5.5f;
                var rock = Primitive(
                    $"Saha Taşı {index + 1}",
                    PrimitiveType.Sphere,
                    worldRoot.transform,
                    new Vector3(x, -0.02f, z + Mathf.Sin(angle) * 0.4f),
                    new Vector3(
                        0.28f + index % 3 * 0.08f,
                        0.16f,
                        0.22f + index % 4 * 0.05f),
                    stone);
                rock.transform.rotation = Quaternion.Euler(
                    index * 13f,
                    index * 29f,
                    index * 7f);
            }
        }

        private Actor CreateActor(BattleUnit unit)
        {
            var root = new GameObject(
                $"{TeamName(unit.team)} {KindName(unit.kind)} Mangası {unit.id}");
            root.transform.SetParent(worldRoot.transform, false);
            var model = new GameObject("Hareketli Manga").transform;
            model.SetParent(root.transform, false);

            var weapons = new List<Transform>();
            switch (unit.kind)
            {
                case BattleUnitKind.Infantry:
                    BuildInfantrySquad(model, unit.team, weapons);
                    break;
                case BattleUnitKind.Archer:
                    BuildArcherSquad(model, unit.team, weapons);
                    break;
                case BattleUnitKind.Cavalry:
                    BuildCavalrySquad(model, unit.team, weapons);
                    break;
                case BattleUnitKind.Siege:
                    BuildCannon(model, unit.team, weapons);
                    break;
            }

            var actor = new Actor
            {
                root = root,
                model = model,
                weapons = weapons.ToArray(),
                lastWorldPosition = WorldPosition(unit),
                lastAttackTimer = unit.attackTimer,
                phase = unit.id * 0.79f
            };
            actor.weaponRestRotations = new Quaternion[actor.weapons.Length];
            for (var index = 0; index < actor.weapons.Length; index += 1)
            {
                actor.weaponRestRotations[index] = actor.weapons[index].localRotation;
            }

            root.transform.position = actor.lastWorldPosition;
            root.transform.rotation = Quaternion.Euler(
                0f,
                unit.team == BattleTeam.Friendly ? 90f : -90f,
                0f);
            return actor;
        }

        private void BuildInfantrySquad(
            Transform parent,
            BattleTeam team,
            ICollection<Transform> weapons)
        {
            var offsets = new[]
            {
                new Vector3(0f, 0f, 0f),
                new Vector3(-0.42f, 0f, -0.38f),
                new Vector3(-0.42f, 0f, 0.38f)
            };
            foreach (var offset in offsets)
            {
                BuildSoldier(parent, team, offset, true, false, weapons);
            }
        }

        private void BuildArcherSquad(
            Transform parent,
            BattleTeam team,
            ICollection<Transform> weapons)
        {
            BuildSoldier(
                parent,
                team,
                new Vector3(0f, 0f, -0.25f),
                false,
                true,
                weapons);
            BuildSoldier(
                parent,
                team,
                new Vector3(-0.42f, 0f, 0.28f),
                false,
                true,
                weapons);
        }

        private void BuildSoldier(
            Transform parent,
            BattleTeam team,
            Vector3 offset,
            bool shield,
            bool bow,
            ICollection<Transform> weapons)
        {
            var primary = team == BattleTeam.Friendly ? friendlyArmor : enemyArmor;
            var cloth = team == BattleTeam.Friendly ? friendlyCloth : enemyCloth;
            var soldier = new GameObject(bow ? "Zırhlı Okçu" : "Zırhlı Piyade");
            soldier.transform.SetParent(parent, false);
            soldier.transform.localPosition = offset;
            soldier.transform.localScale = Vector3.one * 0.72f;

            Primitive(
                "Kaftan",
                PrimitiveType.Capsule,
                soldier.transform,
                new Vector3(0f, 0.88f, 0f),
                new Vector3(0.5f, 0.62f, 0.42f),
                cloth);
            Primitive(
                "Göğüs Zırhı",
                PrimitiveType.Cube,
                soldier.transform,
                new Vector3(0.03f, 1.12f, 0f),
                new Vector3(0.48f, 0.46f, 0.38f),
                primary);
            Primitive(
                "Baş",
                PrimitiveType.Sphere,
                soldier.transform,
                new Vector3(0f, 1.62f, 0f),
                new Vector3(0.32f, 0.34f, 0.32f),
                skin);
            Primitive(
                "Miğfer",
                PrimitiveType.Sphere,
                soldier.transform,
                new Vector3(0f, 1.75f, 0f),
                new Vector3(0.37f, 0.25f, 0.37f),
                iron);
            Primitive(
                "Miğfer Sorgucu",
                PrimitiveType.Cylinder,
                soldier.transform,
                new Vector3(0f, 1.97f, 0f),
                new Vector3(0.06f, 0.18f, 0.06f),
                gold);
            Primitive(
                "Sol Bacak",
                PrimitiveType.Cube,
                soldier.transform,
                new Vector3(-0.13f, 0.29f, 0f),
                new Vector3(0.15f, 0.55f, 0.18f),
                leather);
            Primitive(
                "Sağ Bacak",
                PrimitiveType.Cube,
                soldier.transform,
                new Vector3(0.13f, 0.29f, 0f),
                new Vector3(0.15f, 0.55f, 0.18f),
                leather);

            if (shield)
            {
                var shieldObject = Primitive(
                    "Kabartmalı Kalkan",
                    PrimitiveType.Cylinder,
                    soldier.transform,
                    new Vector3(0.1f, 1.05f, 0.38f),
                    new Vector3(0.48f, 0.07f, 0.48f),
                    primary,
                    12);
                shieldObject.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
                Primitive(
                    "Kalkan Göbeği",
                    PrimitiveType.Sphere,
                    shieldObject.transform,
                    new Vector3(0f, 0.15f, 0f),
                    new Vector3(0.32f, 0.18f, 0.32f),
                    gold);
            }

            if (bow)
            {
                var bowRoot = new GameObject("Yay").transform;
                bowRoot.SetParent(soldier.transform, false);
                bowRoot.localPosition = new Vector3(0.1f, 1.1f, 0.36f);
                Primitive(
                    "Yay Üst",
                    PrimitiveType.Cube,
                    bowRoot,
                    new Vector3(0f, 0.24f, 0f),
                    new Vector3(0.06f, 0.48f, 0.06f),
                    wood).transform.localRotation = Quaternion.Euler(0f, 0f, -18f);
                Primitive(
                    "Yay Alt",
                    PrimitiveType.Cube,
                    bowRoot,
                    new Vector3(0f, -0.24f, 0f),
                    new Vector3(0.06f, 0.48f, 0.06f),
                    wood).transform.localRotation = Quaternion.Euler(0f, 0f, 18f);
                weapons.Add(bowRoot);
            }
            else
            {
                var swordRoot = new GameObject("Kılıç Eli").transform;
                swordRoot.SetParent(soldier.transform, false);
                swordRoot.localPosition = new Vector3(0.04f, 1.1f, -0.34f);
                swordRoot.localRotation = Quaternion.Euler(0f, 0f, -18f);
                Primitive(
                    "Kılıç",
                    PrimitiveType.Cube,
                    swordRoot,
                    new Vector3(0f, 0.42f, 0f),
                    new Vector3(0.08f, 0.84f, 0.08f),
                    iron);
                Primitive(
                    "Kılıç Kabzası",
                    PrimitiveType.Cube,
                    swordRoot,
                    new Vector3(0f, -0.02f, 0f),
                    new Vector3(0.32f, 0.07f, 0.08f),
                    gold);
                weapons.Add(swordRoot);
            }
        }

        private void BuildCavalrySquad(
            Transform parent,
            BattleTeam team,
            ICollection<Transform> weapons)
        {
            var primary = team == BattleTeam.Friendly ? friendlyArmor : enemyArmor;
            var horse = new GameObject("Zırhlı Sipahi");
            horse.transform.SetParent(parent, false);
            horse.transform.localScale = Vector3.one * 0.78f;

            var body = Primitive(
                "At Gövdesi",
                PrimitiveType.Capsule,
                horse.transform,
                new Vector3(0f, 0.78f, 0f),
                new Vector3(0.62f, 0.88f, 0.62f),
                leather);
            body.transform.localRotation = Quaternion.Euler(0f, 0f, 90f);
            Primitive(
                "At Boynu",
                PrimitiveType.Capsule,
                horse.transform,
                new Vector3(0.56f, 1.08f, 0f),
                new Vector3(0.36f, 0.58f, 0.36f),
                leather).transform.localRotation = Quaternion.Euler(0f, 0f, -28f);
            Primitive(
                "At Başı",
                PrimitiveType.Capsule,
                horse.transform,
                new Vector3(0.82f, 1.34f, 0f),
                new Vector3(0.3f, 0.42f, 0.3f),
                leather).transform.localRotation = Quaternion.Euler(0f, 0f, 70f);

            var legOffsets = new[]
            {
                new Vector3(-0.42f, 0.32f, -0.24f),
                new Vector3(-0.42f, 0.32f, 0.24f),
                new Vector3(0.42f, 0.32f, -0.24f),
                new Vector3(0.42f, 0.32f, 0.24f)
            };
            foreach (var offset in legOffsets)
            {
                Primitive(
                    "At Bacağı",
                    PrimitiveType.Cube,
                    horse.transform,
                    offset,
                    new Vector3(0.14f, 0.64f, 0.14f),
                    leather);
            }

            Primitive(
                "At Zırhı",
                PrimitiveType.Cube,
                horse.transform,
                new Vector3(0f, 1.02f, 0f),
                new Vector3(0.92f, 0.24f, 0.64f),
                primary);

            var rider = new GameObject("Sipahi").transform;
            rider.SetParent(horse.transform, false);
            rider.localPosition = new Vector3(-0.1f, 1.02f, 0f);
            Primitive(
                "Sipahi Gövdesi",
                PrimitiveType.Capsule,
                rider,
                new Vector3(0f, 0.58f, 0f),
                new Vector3(0.46f, 0.62f, 0.4f),
                primary);
            Primitive(
                "Sipahi Başı",
                PrimitiveType.Sphere,
                rider,
                new Vector3(0f, 1.15f, 0f),
                new Vector3(0.31f, 0.32f, 0.31f),
                skin);
            Primitive(
                "Sipahi Miğferi",
                PrimitiveType.Sphere,
                rider,
                new Vector3(0f, 1.28f, 0f),
                new Vector3(0.36f, 0.24f, 0.36f),
                iron);

            var spear = new GameObject("Mızrak Eli").transform;
            spear.SetParent(rider, false);
            spear.localPosition = new Vector3(0.15f, 0.7f, -0.34f);
            spear.localRotation = Quaternion.Euler(0f, 0f, -62f);
            Primitive(
                "Mızrak",
                PrimitiveType.Cylinder,
                spear,
                new Vector3(0f, 0.75f, 0f),
                new Vector3(0.045f, 1.5f, 0.045f),
                wood);
            Primitive(
                "Mızrak Ucu",
                PrimitiveType.Cylinder,
                spear,
                new Vector3(0f, 2.22f, 0f),
                new Vector3(0.11f, 0.19f, 0.11f),
                iron,
                4);
            weapons.Add(spear);
        }

        private void BuildCannon(
            Transform parent,
            BattleTeam team,
            ICollection<Transform> weapons)
        {
            var primary = team == BattleTeam.Friendly ? friendlyArmor : enemyArmor;
            var cannon = new GameObject("Ağır Kuşatma Topu");
            cannon.transform.SetParent(parent, false);
            cannon.transform.localScale = Vector3.one * 0.84f;

            Primitive(
                "Top Arabası",
                PrimitiveType.Cube,
                cannon.transform,
                new Vector3(0f, 0.46f, 0f),
                new Vector3(1.15f, 0.32f, 0.78f),
                wood);

            foreach (var z in new[] { -0.48f, 0.48f })
            {
                var wheel = Primitive(
                    "Demir Çemberli Teker",
                    PrimitiveType.Cylinder,
                    cannon.transform,
                    new Vector3(-0.05f, 0.42f, z),
                    new Vector3(0.62f, 0.13f, 0.62f),
                    wood,
                    12);
                wheel.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
                Primitive(
                    "Teker Göbeği",
                    PrimitiveType.Cylinder,
                    wheel.transform,
                    Vector3.zero,
                    new Vector3(0.24f, 1.15f, 0.24f),
                    iron,
                    12);
            }

            var barrelPivot = new GameObject("Top Namlusu Yatağı").transform;
            barrelPivot.SetParent(cannon.transform, false);
            barrelPivot.localPosition = new Vector3(0.2f, 0.88f, 0f);
            barrelPivot.localRotation = Quaternion.Euler(0f, 0f, -78f);
            Primitive(
                "Şahi Namlusu",
                PrimitiveType.Cylinder,
                barrelPivot,
                new Vector3(0f, 0.86f, 0f),
                new Vector3(0.25f, 0.9f, 0.25f),
                iron,
                16);
            Primitive(
                "Namlu Ağzı",
                PrimitiveType.Cylinder,
                barrelPivot,
                new Vector3(0f, 1.78f, 0f),
                new Vector3(0.34f, 0.13f, 0.34f),
                gold,
                16);
            weapons.Add(barrelPivot);

            Primitive(
                "Topçu Sancağı",
                PrimitiveType.Cube,
                cannon.transform,
                new Vector3(-0.52f, 1.32f, 0f),
                new Vector3(0.08f, 1.15f, 0.08f),
                primary);
        }

        private void UpdateActor(Actor actor, BattleUnit unit)
        {
            var desired = WorldPosition(unit);
            var delta = desired - actor.lastWorldPosition;
            actor.root.transform.position = Vector3.Lerp(
                actor.root.transform.position,
                desired,
                1f - Mathf.Exp(-Time.unscaledDeltaTime * 10f));

            if (unit.Alive && delta.sqrMagnitude > 0.00001f)
            {
                var facing = Quaternion.LookRotation(delta.normalized, Vector3.up);
                actor.root.transform.rotation = Quaternion.Slerp(
                    actor.root.transform.rotation,
                    facing,
                    1f - Mathf.Exp(-Time.unscaledDeltaTime * 8f));
            }

            var moving = delta.sqrMagnitude > 0.000002f;
            var attacking = unit.attackTimer >
                            Mathf.Max(0f, unit.attackDelay - 0.16f);
            var attackStarted =
                unit.attackTimer > actor.lastAttackTimer + unit.attackDelay * 0.55f;

            if (unit.Alive)
            {
                var bob = moving
                    ? Mathf.Abs(Mathf.Sin(Time.unscaledTime * 10f + actor.phase)) * 0.09f
                    : Mathf.Sin(Time.unscaledTime * 2.2f + actor.phase) * 0.015f;
                actor.model.localPosition = new Vector3(0f, bob, 0f);
                actor.model.localRotation = Quaternion.Slerp(
                    actor.model.localRotation,
                    Quaternion.identity,
                    1f - Mathf.Exp(-Time.unscaledDeltaTime * 9f));

                for (var index = 0; index < actor.weapons.Length; index += 1)
                {
                    var strike = attacking
                        ? Quaternion.Euler(0f, 0f, -58f)
                        : Quaternion.identity;
                    actor.weapons[index].localRotation = Quaternion.Slerp(
                        actor.weapons[index].localRotation,
                        actor.weaponRestRotations[index] * strike,
                        1f - Mathf.Exp(-Time.unscaledDeltaTime * 18f));
                }

                if (attackStarted)
                {
                    SpawnAttackEffect(actor, unit);
                }
            }
            else if (!actor.fallen)
            {
                actor.fallen = true;
            }

            if (actor.fallen)
            {
                actor.model.localRotation = Quaternion.Slerp(
                    actor.model.localRotation,
                    Quaternion.Euler(0f, 0f, unit.team == BattleTeam.Friendly ? -78f : 78f),
                    1f - Mathf.Exp(-Time.unscaledDeltaTime * 5f));
                actor.model.localPosition = Vector3.Lerp(
                    actor.model.localPosition,
                    new Vector3(0f, -0.18f, 0f),
                    1f - Mathf.Exp(-Time.unscaledDeltaTime * 3f));
            }

            actor.lastWorldPosition = desired;
            actor.lastAttackTimer = unit.attackTimer;
        }

        private void SpawnAttackEffect(Actor actor, BattleUnit unit)
        {
            var direction = actor.root.transform.forward;
            var isProjectile =
                unit.kind == BattleUnitKind.Archer ||
                unit.kind == BattleUnitKind.Siege;
            var effect = Primitive(
                isProjectile ? "Mermi İzi" : "Kılıç Parıltısı",
                isProjectile ? PrimitiveType.Sphere : PrimitiveType.Cube,
                worldRoot.transform,
                actor.root.transform.position + Vector3.up * 1.05f + direction * 0.4f,
                isProjectile
                    ? new Vector3(0.14f, 0.14f, 0.14f)
                    : new Vector3(0.06f, 0.55f, 0.11f),
                healthFlash);
            effect.transform.rotation = actor.root.transform.rotation;
            effects.Add(new TimedEffect
            {
                root = effect,
                velocity = direction *
                           (unit.kind == BattleUnitKind.Siege ? 9.5f : 6.5f) +
                           Vector3.up * (unit.kind == BattleUnitKind.Siege ? 1.2f : 0.25f),
                life = isProjectile ? 0.56f : 0.18f,
                duration = isProjectile ? 0.56f : 0.18f
            });
        }

        private void UpdateEffects(float deltaTime)
        {
            for (var index = effects.Count - 1; index >= 0; index -= 1)
            {
                var effect = effects[index];
                effect.life -= deltaTime;
                if (effect.life <= 0f)
                {
                    if (effect.root != null)
                    {
                        Destroy(effect.root);
                    }

                    effects.RemoveAt(index);
                    continue;
                }

                effect.root.transform.position += effect.velocity * deltaTime;
                effect.velocity += Vector3.down * 3.5f * deltaTime;
                var ratio = Mathf.Clamp01(effect.life / effect.duration);
                effect.root.transform.localScale *= Mathf.Lerp(0.82f, 1f, ratio);
            }
        }

        private static Vector3 WorldPosition(BattleUnit unit)
        {
            return new Vector3(
                (unit.x - 0.5f) * 17.2f,
                0.06f,
                (unit.y - 0.5f) * 10.6f);
        }

        private Material CreateMaterial(Color color, float metallic, float smoothness)
        {
            var shader = Shader.Find("Standard");
            if (shader == null)
            {
                shader = Shader.Find("Mobile/Diffuse");
            }

            var material = new Material(shader)
            {
                color = color
            };
            if (material.HasProperty("_Metallic"))
            {
                material.SetFloat("_Metallic", metallic);
            }

            if (material.HasProperty("_Glossiness"))
            {
                material.SetFloat("_Glossiness", smoothness);
            }

            materials.Add(material);
            return material;
        }

        private static GameObject Primitive(
            string name,
            PrimitiveType type,
            Transform parent,
            Vector3 localPosition,
            Vector3 localScale,
            Material material,
            int ignoredSides = 0)
        {
            var value = GameObject.CreatePrimitive(type);
            value.name = name;
            value.transform.SetParent(parent, false);
            value.transform.localPosition = localPosition;
            value.transform.localScale = localScale;
            var collider = value.GetComponent<Collider>();
            if (collider != null)
            {
                Destroy(collider);
            }

            var renderer = value.GetComponent<MeshRenderer>();
            renderer.sharedMaterial = material;
            renderer.shadowCastingMode = ShadowCastingMode.On;
            renderer.receiveShadows = true;
            return value;
        }

        private static string TeamName(BattleTeam team)
        {
            return team == BattleTeam.Friendly ? "CİHAN" : "HİSAR";
        }

        private static string KindName(BattleUnitKind kind)
        {
            return kind switch
            {
                BattleUnitKind.Infantry => "Piyade",
                BattleUnitKind.Archer => "Okçu",
                BattleUnitKind.Cavalry => "Süvari",
                BattleUnitKind.Siege => "Şahi Topu",
                _ => "Birlik"
            };
        }

        private void OnDestroy()
        {
            if (worldRoot != null)
            {
                Destroy(worldRoot);
            }

            foreach (var material in materials)
            {
                if (material != null)
                {
                    Destroy(material);
                }
            }
        }
    }
}
