using System;
using System.Collections.Generic;
using Cihan.Battle;
using Cihan.Services;
using UnityEngine;
using UnityEngine.UI;

namespace Cihan.UI
{
    public sealed class CihanBattleView : MonoBehaviour
    {
        private sealed class UnitVisual
        {
            public RectTransform rect;
            public Image health;
        }

        private static readonly Color32 Ink = new(7, 11, 16, 255);
        private static readonly Color32 Panel = new(13, 21, 29, 245);
        private static readonly Color32 Gold = new(216, 173, 84, 255);
        private static readonly Color32 Ivory = new(243, 238, 226, 255);
        private static readonly Color32 Muted = new(158, 164, 168, 255);
        private static readonly Color32 FriendlyBright = new(83, 199, 181, 255);
        private static readonly Color32 EnemyBright = new(229, 91, 75, 255);

        private readonly Dictionary<int, UnitVisual> visuals = new();
        private readonly HashSet<BattleUnitKind> deployed = new();

        private GameService game;
        private Action closed;
        private BattleSimulation simulation;
        private Font font;
        private RectTransform unitLayer;
        private Text timerText;
        private Text friendlyText;
        private Text enemyText;
        private Text battleMessage;
        private GameObject resultOverlay;
        private RenderTexture battleRender;
        private CihanBattleWorld3D battleWorld;
        private bool resultShown;
        private bool resultApplied;

        public static void Show(GameService game, Action onClosed)
        {
            if (FindFirstObjectByType<CihanBattleView>() != null)
            {
                return;
            }

            var root = new GameObject("CİHAN · Canlı Kuşatma");
            var view = root.AddComponent<CihanBattleView>();
            view.game = game;
            view.closed = onClosed;
        }

        private void Start()
        {
            font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            if (font == null)
            {
                font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            }

            simulation = BattleSimulation.Create(game.State);
            BuildInterface();
            SyncUnitVisuals();
        }

        private void Update()
        {
            if (simulation == null || resultShown)
            {
                return;
            }

            simulation.Step(Time.unscaledDeltaTime);
            SyncUnitVisuals();
            RefreshHud();

            if (simulation.IsFinished)
            {
                ShowResult();
            }
        }

        private void BuildInterface()
        {
            var canvas = gameObject.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 100;

            var scaler = gameObject.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1080, 1920);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0.5f;
            gameObject.AddComponent<GraphicRaycaster>();

            var blackout = CreatePanel(transform, "Savaş Zemini", Ink);
            Stretch(blackout.rectTransform);

            var safeArea = CreatePanel(transform, "Güvenli Alan", Color.clear);
            Stretch(safeArea.rectTransform);
            safeArea.gameObject.AddComponent<SafeAreaFitter>();

            BuildBattlefield(safeArea.transform);
            BuildHeader(safeArea.transform);
            BuildCommands(safeArea.transform);
        }

        private void BuildBattlefield(Transform parent)
        {
            var arena = new GameObject(
                "Kuşatma Meydanı",
                typeof(RectTransform),
                typeof(RawImage),
                typeof(Mask));
            arena.transform.SetParent(parent, false);
            var arenaRect = (RectTransform)arena.transform;
            arenaRect.anchorMin = Vector2.zero;
            arenaRect.anchorMax = Vector2.one;
            arenaRect.offsetMin = new Vector2(22f, 310f);
            arenaRect.offsetMax = new Vector2(-22f, -235f);

            var background = arena.GetComponent<RawImage>();
            battleRender = new RenderTexture(
                720,
                1080,
                24,
                RenderTextureFormat.ARGB32)
            {
                name = "CİHAN 3B Savaş Görüntüsü",
                antiAliasing = 2,
                filterMode = FilterMode.Bilinear
            };
            battleRender.Create();
            background.texture = battleRender;
            background.color = Color.white;
            background.raycastTarget = false;
            arena.GetComponent<Mask>().showMaskGraphic = true;

            battleWorld = gameObject.AddComponent<CihanBattleWorld3D>();
            battleWorld.Initialize(simulation, battleRender);

            var shade = CreatePanel(
                arena.transform,
                "Okunabilirlik Gölgesi",
                new Color32(7, 12, 15, 28));
            Stretch(shade.rectTransform);

            var layer = new GameObject("Hareketli Birlikler", typeof(RectTransform));
            layer.transform.SetParent(arena.transform, false);
            unitLayer = (RectTransform)layer.transform;
            Stretch(unitLayer, 12f, 12f, 12f, 12f);

            battleMessage = CreateText(
                arena.transform,
                "ORDULAR İLERLİYOR",
                28,
                Ivory,
                TextAnchor.UpperCenter,
                FontStyle.Bold);
            battleMessage.rectTransform.anchorMin = new Vector2(0f, 1f);
            battleMessage.rectTransform.anchorMax = new Vector2(1f, 1f);
            battleMessage.rectTransform.sizeDelta = new Vector2(0f, 72f);
            battleMessage.rectTransform.anchoredPosition = new Vector2(0f, -42f);
        }

        private void BuildHeader(Transform parent)
        {
            var header = CreatePanel(parent, "Savaş Başlığı", Panel);
            header.rectTransform.anchorMin = new Vector2(0f, 1f);
            header.rectTransform.anchorMax = new Vector2(1f, 1f);
            header.rectTransform.sizeDelta = new Vector2(0f, 215f);
            header.rectTransform.anchoredPosition = new Vector2(0f, -107.5f);

            var title = CreateText(
                header.transform,
                "KARACAHİSAR KUŞATMASI",
                34,
                Gold,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            title.rectTransform.anchorMin = new Vector2(0f, 0.55f);
            title.rectTransform.anchorMax = new Vector2(1f, 1f);
            title.rectTransform.offsetMin = new Vector2(30f, 0f);
            title.rectTransform.offsetMax = new Vector2(-30f, -8f);

            friendlyText = CreateText(
                header.transform,
                "CİHAN 0",
                25,
                FriendlyBright,
                TextAnchor.MiddleLeft,
                FontStyle.Bold);
            SetHudRect(friendlyText.rectTransform, 0f, 0.34f, 32f);

            timerText = CreateText(
                header.transform,
                "00:00",
                27,
                Ivory,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            SetHudRect(timerText.rectTransform, 0.34f, 0.66f, 0f);

            enemyText = CreateText(
                header.transform,
                "HİSAR 0",
                25,
                EnemyBright,
                TextAnchor.MiddleRight,
                FontStyle.Bold);
            SetHudRect(enemyText.rectTransform, 0.66f, 1f, -32f);
        }

        private void BuildCommands(Transform parent)
        {
            var commands = CreatePanel(parent, "Savaş Emirleri", Panel);
            commands.rectTransform.anchorMin = new Vector2(0f, 0f);
            commands.rectTransform.anchorMax = new Vector2(1f, 0f);
            commands.rectTransform.sizeDelta = new Vector2(0f, 285f);
            commands.rectTransform.anchoredPosition = new Vector2(0f, 142.5f);

            var label = CreateText(
                commands.transform,
                "TEK KULLANIMLIK TAKVİYELER",
                20,
                Muted,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            label.rectTransform.anchorMin = new Vector2(0f, 0.72f);
            label.rectTransform.anchorMax = new Vector2(1f, 1f);
            label.rectTransform.offsetMin = new Vector2(20f, 0f);
            label.rectTransform.offsetMax = new Vector2(-20f, -8f);

            var row = new GameObject("Emir Düğmeleri", typeof(RectTransform));
            row.transform.SetParent(commands.transform, false);
            var rowRect = (RectTransform)row.transform;
            rowRect.anchorMin = new Vector2(0f, 0.25f);
            rowRect.anchorMax = new Vector2(1f, 0.72f);
            rowRect.offsetMin = new Vector2(24f, 10f);
            rowRect.offsetMax = new Vector2(-24f, -6f);
            var layout = row.AddComponent<HorizontalLayoutGroup>();
            layout.spacing = 12f;
            layout.childControlWidth = true;
            layout.childControlHeight = true;
            layout.childForceExpandWidth = true;
            layout.childForceExpandHeight = true;

            AddReinforcementButton(
                row.transform,
                BattleUnitKind.Infantry,
                "♟\nPİYADE");
            AddReinforcementButton(
                row.transform,
                BattleUnitKind.Archer,
                "➶\nOKÇU");
            AddReinforcementButton(
                row.transform,
                BattleUnitKind.Cavalry,
                "♞\nSÜVARİ");

            var retreat = CreateButton(
                commands.transform,
                "SANCAĞI KORU · GERİ ÇEKİL",
                () =>
                {
                    simulation.Retreat();
                    ShowResult();
                },
                new Color32(78, 48, 44, 255),
                19);
            retreat.GetComponent<RectTransform>().anchorMin = new Vector2(0.16f, 0.02f);
            retreat.GetComponent<RectTransform>().anchorMax = new Vector2(0.84f, 0.24f);
            retreat.GetComponent<RectTransform>().offsetMin = new Vector2(0f, 4f);
            retreat.GetComponent<RectTransform>().offsetMax = new Vector2(0f, -4f);
        }

        private void AddReinforcementButton(
            Transform parent,
            BattleUnitKind kind,
            string label)
        {
            Button button = null;
            button = CreateButton(
                parent,
                label,
                () =>
                {
                    if (!deployed.Add(kind))
                    {
                        return;
                    }

                    simulation.DeployReinforcement(kind);
                    button.interactable = false;
                    battleMessage.text = $"{KindTitle(kind)} TAKVİYESİ SAHAYA GİRDİ";
                    SyncUnitVisuals();
                },
                new Color32(40, 76, 73, 255),
                18);
        }

        private void SyncUnitVisuals()
        {
            battleWorld?.Sync();
            foreach (var unit in simulation.Units)
            {
                if (!visuals.TryGetValue(unit.id, out var visual))
                {
                    visual = CreateUnitVisual(unit);
                    visuals[unit.id] = visual;
                }

                if (battleWorld != null &&
                    battleWorld.TryGetViewportPosition(unit.id, out var viewport))
                {
                    visual.rect.anchorMin = viewport;
                    visual.rect.anchorMax = viewport;
                    visual.rect.anchoredPosition = Vector2.zero;
                }

                visual.health.rectTransform.anchorMax =
                    new Vector2(unit.HealthRatio, 1f);
                visual.rect.gameObject.SetActive(unit.Alive);
            }
        }

        private UnitVisual CreateUnitVisual(BattleUnit unit)
        {
            var root = new GameObject(
                $"{KindTitle(unit.kind)} Manga Canı {unit.id}",
                typeof(RectTransform),
                typeof(Image));
            root.transform.SetParent(unitLayer, false);
            var rect = (RectTransform)root.transform;
            rect.sizeDelta = unit.kind == BattleUnitKind.Siege
                ? new Vector2(64f, 12f)
                : new Vector2(48f, 10f);

            var healthTrack = root.GetComponent<Image>();
            healthTrack.color = new Color32(18, 20, 21, 235);
            healthTrack.raycastTarget = false;

            var health = CreatePanel(
                root.transform,
                "Can",
                unit.team == BattleTeam.Friendly ? FriendlyBright : EnemyBright);
            health.rectTransform.anchorMin = Vector2.zero;
            health.rectTransform.anchorMax = Vector2.one;
            health.rectTransform.offsetMin = Vector2.zero;
            health.rectTransform.offsetMax = Vector2.zero;

            return new UnitVisual
            {
                rect = rect,
                health = health
            };
        }

        private void RefreshHud()
        {
            timerText.text =
                $"{(int)simulation.Elapsed / 60:00}:{(int)simulation.Elapsed % 60:00}";
            friendlyText.text = $"CİHAN  {simulation.FriendlyAlive}";
            enemyText.text = $"{simulation.EnemyAlive}  HİSAR";
            if (simulation.Clashes > 0 && simulation.Clashes < 8)
            {
                battleMessage.text = "HATLAR ÇARPIŞTI";
            }
            else if (simulation.Clashes >= 8)
            {
                battleMessage.text =
                    $"ÇARPIŞMA {simulation.Clashes:N0} · DÜŞMAN KAYBI {simulation.FriendlyKills}";
            }
        }

        private void ShowResult()
        {
            if (resultShown)
            {
                return;
            }

            resultShown = true;
            resultOverlay = CreatePanel(
                transform,
                "Savaş Sonucu",
                new Color32(5, 9, 12, 244)).gameObject;
            var resultRect = (RectTransform)resultOverlay.transform;
            Stretch(resultRect);
            resultOverlay.transform.SetAsLastSibling();

            var resultTitle = CreateText(
                resultOverlay.transform,
                simulation.Victory ? "ZAFER" : "GERİ ÇEKİLME",
                72,
                simulation.Victory ? Gold : EnemyBright,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            resultTitle.rectTransform.anchorMin = new Vector2(0.08f, 0.58f);
            resultTitle.rectTransform.anchorMax = new Vector2(0.92f, 0.78f);
            resultTitle.rectTransform.offsetMin = Vector2.zero;
            resultTitle.rectTransform.offsetMax = Vector2.zero;

            var report = CreateText(
                resultOverlay.transform,
                $"Karacahisar önlerinde savaş sona erdi.\n\n" +
                $"Düşman kaybı  {simulation.FriendlyKills}\n" +
                $"CİHAN kaybı  {simulation.FriendlyCasualties}\n" +
                $"Savaş süresi  {simulation.Elapsed:0.0} sn\n\n" +
                (simulation.Victory
                    ? "2.400 erzak · 700 taş · 900 altın"
                    : "Yaralılar Darüşşifa'ya taşınacak."),
                27,
                Ivory,
                TextAnchor.MiddleCenter,
                FontStyle.Normal);
            report.rectTransform.anchorMin = new Vector2(0.08f, 0.30f);
            report.rectTransform.anchorMax = new Vector2(0.92f, 0.60f);
            report.rectTransform.offsetMin = Vector2.zero;
            report.rectTransform.offsetMax = Vector2.zero;

            var collect = CreateButton(
                resultOverlay.transform,
                simulation.Victory ? "GANİMETİ BAŞKENTE TAŞI" : "ORDUYU TOPARLA",
                CompleteBattle,
                simulation.Victory
                    ? new Color32(133, 91, 36, 255)
                    : new Color32(71, 79, 83, 255),
                25);
            collect.GetComponent<RectTransform>().anchorMin = new Vector2(0.12f, 0.14f);
            collect.GetComponent<RectTransform>().anchorMax = new Vector2(0.88f, 0.25f);
            collect.GetComponent<RectTransform>().offsetMin = Vector2.zero;
            collect.GetComponent<RectTransform>().offsetMax = Vector2.zero;
        }

        private void CompleteBattle()
        {
            if (resultApplied)
            {
                return;
            }

            resultApplied = true;
            game.ApplyBattleResult(
                simulation.Victory,
                simulation.FriendlyCasualties,
                simulation.FriendlyKills);
            closed?.Invoke();
            Destroy(gameObject);
        }

        private void OnDestroy()
        {
            if (battleRender != null)
            {
                battleRender.Release();
                Destroy(battleRender);
            }
        }

        private Image CreatePanel(Transform parent, string name, Color color)
        {
            var panel = new GameObject(name, typeof(RectTransform), typeof(Image));
            panel.transform.SetParent(parent, false);
            var image = panel.GetComponent<Image>();
            image.color = color;
            image.raycastTarget = false;
            return image;
        }

        private Text CreateText(
            Transform parent,
            string value,
            int size,
            Color color,
            TextAnchor alignment,
            FontStyle style)
        {
            var textObject = new GameObject("Metin", typeof(RectTransform), typeof(Text));
            textObject.transform.SetParent(parent, false);
            var text = textObject.GetComponent<Text>();
            text.font = font;
            text.text = value;
            text.fontSize = size;
            text.color = color;
            text.alignment = alignment;
            text.fontStyle = style;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Truncate;
            text.raycastTarget = false;
            return text;
        }

        private Button CreateButton(
            Transform parent,
            string label,
            UnityEngine.Events.UnityAction action,
            Color color,
            int fontSize)
        {
            var buttonObject = new GameObject(
                $"{label} Düğmesi",
                typeof(RectTransform),
                typeof(Image),
                typeof(Button));
            buttonObject.transform.SetParent(parent, false);
            var image = buttonObject.GetComponent<Image>();
            image.color = color;
            var button = buttonObject.GetComponent<Button>();
            button.targetGraphic = image;
            button.onClick.AddListener(action);

            var text = CreateText(
                buttonObject.transform,
                label,
                fontSize,
                Ivory,
                TextAnchor.MiddleCenter,
                FontStyle.Bold);
            Stretch(text.rectTransform, 8f, 8f, 4f, 4f);
            return button;
        }

        private static void SetHudRect(
            RectTransform rect,
            float anchorMinX,
            float anchorMaxX,
            float horizontalOffset)
        {
            rect.anchorMin = new Vector2(anchorMinX, 0f);
            rect.anchorMax = new Vector2(anchorMaxX, 0.58f);
            rect.offsetMin = new Vector2(horizontalOffset, 0f);
            rect.offsetMax = new Vector2(horizontalOffset, 0f);
        }

        private static string KindTitle(BattleUnitKind kind)
        {
            return kind switch
            {
                BattleUnitKind.Infantry => "PİYADE",
                BattleUnitKind.Archer => "OKÇU",
                BattleUnitKind.Cavalry => "SÜVARİ",
                BattleUnitKind.Siege => "ŞAHİ TOPU",
                _ => "BİRLİK"
            };
        }

        private static void Stretch(
            RectTransform rect,
            float left = 0f,
            float right = 0f,
            float top = 0f,
            float bottom = 0f)
        {
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = new Vector2(left, bottom);
            rect.offsetMax = new Vector2(-right, -top);
        }
    }
}
