using System.Linq;
using Cihan.Battle;
using Cihan.Domain;
using NUnit.Framework;

namespace Cihan.Tests
{
    public sealed class GameStateTests
    {
        [Test]
        public void ResourcesContinueProducingWhileTimeAdvances()
        {
            const double now = 1000d;
            var state = GameState.CreateNew(now);
            var initialFood = state.food;
            var initialWood = state.wood;

            state.Advance(now + 60d);

            Assert.That(state.food, Is.GreaterThan(initialFood));
            Assert.That(state.wood, Is.GreaterThan(initialWood));
        }

        [Test]
        public void BuildingUpgradeSpendsResourcesAndCompletes()
        {
            const double now = 2000d;
            var state = GameState.CreateNew(now);
            var initialLevel = state.GetBuilding("farm").level;
            var initialWood = state.wood;

            Assert.That(state.BeginUpgrade("farm", now), Is.True);
            Assert.That(state.wood, Is.LessThan(initialWood));
            Assert.That(state.construction, Is.Not.Null);

            state.Advance(now + 120d);

            Assert.That(state.GetBuilding("farm").level, Is.EqualTo(initialLevel + 1));
            Assert.That(state.construction, Is.Null);
        }

        [Test]
        public void TrainedUnitsJoinTheArmy()
        {
            const double now = 3000d;
            var state = GameState.CreateNew(now);
            var initialCount = state.GetUnit("infantry").count;
            var expectedBatch = GameRules.TrainingBatch(
                GameRules.Units.First(item => item.id == "infantry"),
                state.GetBuilding("barracks").level);

            Assert.That(state.BeginTraining("infantry", now), Is.True);
            state.Advance(now + 120d);

            Assert.That(
                state.GetUnit("infantry").count,
                Is.EqualTo(initialCount + expectedBatch));
            Assert.That(state.training, Is.Null);
        }

        [Test]
        public void BarracksLevelUnlocksAdvancedUnits()
        {
            const double now = 3500d;
            var state = GameState.CreateNew(now);

            Assert.That(state.GetBuilding("barracks").level, Is.EqualTo(2));
            Assert.That(state.BeginTraining("cavalry", now), Is.False);
            Assert.That(state.BeginTraining("siege", now), Is.False);
        }

        [Test]
        public void PalaceLevelLimitsOtherBuildings()
        {
            const double now = 3750d;
            var state = GameState.CreateNew(now);
            state.GetBuilding("farm").level = state.GetBuilding("palace").level;

            Assert.That(state.BeginUpgrade("farm", now), Is.False);
            Assert.That(state.BeginUpgrade("palace", now), Is.True);
        }

        [Test]
        public void ExpeditionReturnsWithRewards()
        {
            const double now = 4000d;
            var state = GameState.CreateNew(now);
            var initialGold = state.gold;

            Assert.That(state.BeginExpedition(now), Is.True);
            state.Advance(now + 120d);

            Assert.That(state.victories, Is.EqualTo(1));
            Assert.That(state.gold, Is.GreaterThan(initialGold));
            Assert.That(state.expedition, Is.Null);
        }

        [Test]
        public void HeroAssignmentIsLimitedToTwoCommanders()
        {
            var state = GameState.CreateNew(5000d);

            Assert.That(state.ToggleHeroAssignment("leyla"), Is.False);
            Assert.That(state.ToggleHeroAssignment("nizam"), Is.True);
            Assert.That(state.ToggleHeroAssignment("leyla"), Is.True);
            Assert.That(
                state.heroes.Count(item => item.assigned),
                Is.EqualTo(2));
        }

        [Test]
        public void LiveBattleMovesArmiesIntoCombatAndFinishes()
        {
            var state = GameState.CreateNew(6000d);
            var battle = BattleSimulation.Create(state);

            for (var step = 0; step < 4000 && !battle.IsFinished; step += 1)
            {
                battle.Step(0.02f);
            }

            Assert.That(battle.Clashes, Is.GreaterThan(0));
            Assert.That(battle.IsFinished, Is.True);
            Assert.That(
                battle.FriendlyKills + battle.FriendlyCasualties,
                Is.GreaterThan(0));
        }
    }
}
