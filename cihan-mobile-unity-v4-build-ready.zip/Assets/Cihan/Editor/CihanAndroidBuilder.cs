using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace Cihan.Editor
{
    public static class CihanAndroidBuilder
    {
        private const string DefaultApkName = "Cihan-Tahtin-Cagi-v4.apk";

        [MenuItem("Cihan/Android APK Oluştur")]
        public static void BuildFromMenu()
        {
            Build();
        }

        public static void Build()
        {
            CihanProjectSetup.ConfigureProject();

            if (!BuildPipeline.IsBuildTargetSupported(
                    BuildTargetGroup.Android,
                    BuildTarget.Android))
            {
                throw new BuildFailedException(
                    "Unity Android Build Support modülü kurulu değil.");
            }

            if (!EditorUserBuildSettings.SwitchActiveBuildTarget(
                    BuildTargetGroup.Android,
                    BuildTarget.Android))
            {
                throw new BuildFailedException(
                    "Unity Android hedef platformuna geçemedi.");
            }

            ApplyAndroidSettings();

            var outputPath = ResolveOutputPath();
            var outputDirectory = Path.GetDirectoryName(outputPath);
            if (!string.IsNullOrWhiteSpace(outputDirectory))
            {
                Directory.CreateDirectory(outputDirectory);
            }

            var scenes = EditorBuildSettings.scenes
                .Where(scene => scene.enabled)
                .Select(scene => scene.path)
                .ToArray();
            if (scenes.Length == 0)
            {
                throw new BuildFailedException(
                    "APK için etkin bir Unity sahnesi bulunamadı.");
            }

            var report = BuildPipeline.BuildPlayer(
                new BuildPlayerOptions
                {
                    scenes = scenes,
                    locationPathName = outputPath,
                    target = BuildTarget.Android,
                    targetGroup = BuildTargetGroup.Android,
                    options = BuildOptions.None
                });

            if (report.summary.result != BuildResult.Succeeded)
            {
                throw new BuildFailedException(
                    $"CİHAN APK derlemesi başarısız: {report.summary.result}");
            }

            Debug.Log(
                $"CİHAN APK hazır: {outputPath} " +
                $"({report.summary.totalSize / 1024f / 1024f:N1} MB)");
        }

        private static void ApplyAndroidSettings()
        {
            PlayerSettings.companyName = "Selin Türkmen";
            PlayerSettings.productName = "CİHAN: Tahtın Çağı";
            PlayerSettings.bundleVersion = "0.4.1";
            PlayerSettings.SetApplicationIdentifier(
                BuildTargetGroup.Android,
                "com.selinturkmen.cihan");
            PlayerSettings.Android.bundleVersionCode = 41;
            PlayerSettings.Android.minSdkVersion =
                AndroidSdkVersions.AndroidApiLevel26;
            PlayerSettings.Android.targetSdkVersion =
                AndroidSdkVersions.AndroidApiLevelAuto;
            PlayerSettings.Android.targetArchitectures =
                AndroidArchitecture.ARM64;
            PlayerSettings.SetScriptingBackend(
                BuildTargetGroup.Android,
                ScriptingImplementation.IL2CPP);

            EditorUserBuildSettings.buildAppBundle = false;
            EditorUserBuildSettings.exportAsGoogleAndroidProject = false;
        }

        private static string ResolveOutputPath()
        {
            var environmentPath =
                Environment.GetEnvironmentVariable("CIHAN_APK_OUTPUT");
            if (!string.IsNullOrWhiteSpace(environmentPath))
            {
                return Path.GetFullPath(environmentPath);
            }

            var projectRoot = Directory.GetParent(Application.dataPath)?.FullName;
            if (string.IsNullOrWhiteSpace(projectRoot))
            {
                throw new BuildFailedException(
                    "Unity proje klasörü belirlenemedi.");
            }

            return Path.Combine(projectRoot, "Builds", DefaultApkName);
        }
    }
}
