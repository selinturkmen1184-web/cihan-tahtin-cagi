using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace Cihan.Editor
{
    public static class CihanIOSBuilder
    {
        private const string DefaultOutputName =
            "Cihan-Tahtin-Cagi-iOS-v8-Xcode";

        [MenuItem("Cihan/iOS Xcode Projesi Oluştur")]
        public static void BuildFromMenu()
        {
            Build();
        }

        public static void Build()
        {
            CihanProjectSetup.ConfigureProject();

            if (!BuildPipeline.IsBuildTargetSupported(
                    BuildTargetGroup.iOS,
                    BuildTarget.iOS))
            {
                throw new BuildFailedException(
                    "Unity iOS Build Support modülü kurulu değil.");
            }

            if (!EditorUserBuildSettings.SwitchActiveBuildTarget(
                    BuildTargetGroup.iOS,
                    BuildTarget.iOS))
            {
                throw new BuildFailedException(
                    "Unity iOS hedef platformuna geçemedi.");
            }

            ApplyIOSSettings();

            var outputPath = ResolveOutputPath();
            Directory.CreateDirectory(outputPath);

            var scenes = EditorBuildSettings.scenes
                .Where(scene => scene.enabled)
                .Select(scene => scene.path)
                .ToArray();
            if (scenes.Length == 0)
            {
                throw new BuildFailedException(
                    "iOS için etkin bir Unity sahnesi bulunamadı.");
            }

            var report = BuildPipeline.BuildPlayer(
                new BuildPlayerOptions
                {
                    scenes = scenes,
                    locationPathName = outputPath,
                    target = BuildTarget.iOS,
                    targetGroup = BuildTargetGroup.iOS,
                    options = BuildOptions.None
                });

            if (report.summary.result != BuildResult.Succeeded)
            {
                throw new BuildFailedException(
                    $"CİHAN iOS projesi oluşturulamadı: " +
                    report.summary.result);
            }

            Debug.Log(
                $"CİHAN iOS Xcode projesi hazır: {outputPath} " +
                $"({report.summary.totalSize / 1024f / 1024f:N1} MB)");
        }

        private static void ApplyIOSSettings()
        {
            PlayerSettings.companyName = "Selin Türkmen";
            PlayerSettings.productName = "CİHAN: Tahtın Çağı";
            PlayerSettings.bundleVersion = "0.8.0";
            PlayerSettings.SetApplicationIdentifier(
                BuildTargetGroup.iOS,
                "com.selinturkmen.cihan");
            PlayerSettings.SetScriptingBackend(
                BuildTargetGroup.iOS,
                ScriptingImplementation.IL2CPP);
            PlayerSettings.SetManagedStrippingLevel(
                NamedBuildTarget.iOS,
                ManagedStrippingLevel.Low);
            PlayerSettings.SetApiCompatibilityLevel(
                NamedBuildTarget.iOS,
                ApiCompatibilityLevel.NET_Standard);

            PlayerSettings.iOS.buildNumber = "80";
            PlayerSettings.iOS.targetOSVersionString = "15.0";
            PlayerSettings.iOS.targetDevice = iOSTargetDevice.iPhoneAndiPad;
            PlayerSettings.iOS.sdkVersion = iOSSdkVersion.DeviceSDK;
            PlayerSettings.iOS.requiresFullScreen = true;
            PlayerSettings.iOS.requiresPersistentWiFi = false;
            PlayerSettings.iOS.hideHomeButton = false;

            PlayerSettings.defaultInterfaceOrientation =
                UIOrientation.Portrait;
            PlayerSettings.allowedAutorotateToPortrait = true;
            PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
            PlayerSettings.allowedAutorotateToLandscapeLeft = false;
            PlayerSettings.allowedAutorotateToLandscapeRight = false;

            var teamId = Environment.GetEnvironmentVariable(
                "CIHAN_APPLE_TEAM_ID");
            if (!string.IsNullOrWhiteSpace(teamId))
            {
                PlayerSettings.iOS.appleDeveloperTeamID = teamId.Trim();
                PlayerSettings.iOS.appleEnableAutomaticSigning = true;
            }
            else
            {
                PlayerSettings.iOS.appleEnableAutomaticSigning = false;
            }
        }

        private static string ResolveOutputPath()
        {
            var environmentPath = Environment.GetEnvironmentVariable(
                "CIHAN_IOS_XCODE_OUTPUT");
            if (!string.IsNullOrWhiteSpace(environmentPath))
            {
                return Path.GetFullPath(environmentPath);
            }

            return Path.Combine("/private/tmp", DefaultOutputName);
        }
    }
}
